package com.geovideos.app.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.geovideos.app.data.VideoItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch




data class PlaybackCoreState(
    val connecting: Boolean = true,
    val resolving: Boolean = false,
    val currentVideoId: String = "",
    val isPlaying: Boolean = false,
    val videoWidth: Int = 0,
    val videoHeight: Int = 0,
    val playbackState: Int = Player.STATE_IDLE,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val error: String? = null
)

data class PlaybackProgressState(
    val currentVideoId: String = "",
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val bufferedPercentage: Int = 0
)

data class PlaybackUiState(
    val connecting: Boolean = true,
    val resolving: Boolean = false,
    val currentVideoId: String = "",
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val bufferedPercentage: Int = 0,
    val videoWidth: Int = 0,
    val videoHeight: Int = 0,
    val playbackState: Int = Player.STATE_IDLE,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val error: String? = null
)

class GeoPlayerConnection private constructor(context: Context) {
    private val appContext = context.applicationContext
    private val playerPreferences = appContext.getSharedPreferences("geo_player_preferences", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val controllerFuture = MediaController.Builder(
        appContext,
        SessionToken(appContext, ComponentName(appContext, PlaybackService::class.java))
    ).buildAsync()

    private val _controller = MutableStateFlow<MediaController?>(null)
    val controller: StateFlow<MediaController?> = _controller.asStateFlow()

    private val _preferredQualityHeight = MutableStateFlow<Int?>(
        playerPreferences.getInt(KEY_PREFERRED_QUALITY, 0).takeIf { it > 0 }
    )
    val preferredQualityHeight: StateFlow<Int?> = _preferredQualityHeight.asStateFlow()

    private val _state = MutableStateFlow(PlaybackUiState())
    val state: StateFlow<PlaybackUiState> = _state.asStateFlow()

    val coreState: StateFlow<PlaybackCoreState> = _state
        .map { playback ->
            PlaybackCoreState(
                connecting = playback.connecting,
                resolving = playback.resolving,
                currentVideoId = playback.currentVideoId,
                isPlaying = playback.isPlaying,
                videoWidth = playback.videoWidth,
                videoHeight = playback.videoHeight,
                playbackState = playback.playbackState,
                repeatMode = playback.repeatMode,
                error = playback.error
            )
        }
        .distinctUntilChanged()
        .stateIn(scope, SharingStarted.Eagerly, PlaybackCoreState())

    val progressState: StateFlow<PlaybackProgressState> = _state
        .map { playback ->
            PlaybackProgressState(
                currentVideoId = playback.currentVideoId,
                positionMs = playback.positionMs,
                durationMs = playback.durationMs,
                bufferedPercentage = playback.bufferedPercentage
            )
        }
        .distinctUntilChanged()
        .stateIn(scope, SharingStarted.Eagerly, PlaybackProgressState())

    private val _endedEvents = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val endedEvents: SharedFlow<String> = _endedEvents.asSharedFlow()

    private var currentVideo: VideoItem? = null
    private var resolveJob: Job? = null
    private var requestSerial: Long = 0L
    private val pendingControllerActions = ArrayList<(MediaController) -> Unit>()

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = updateFrom(player)

        override fun onPlaybackStateChanged(playbackState: Int) {
            val player = _controller.value ?: return
            if (playbackState == Player.STATE_ENDED && player.repeatMode != Player.REPEAT_MODE_ONE) {
                val mediaId = player.currentMediaItem?.mediaId.orEmpty()
                if (mediaId.isNotBlank()) _endedEvents.tryEmit(mediaId)
            }
            updateFrom(player)
        }

        override fun onPlayerError(error: PlaybackException) {
            _state.update {
                it.copy(
                    resolving = false,
                    error = friendlyPlaybackError(error.localizedMessage)
                )
            }
        }
    }

    init {
        controllerFuture.addListener(
            {
                runCatching { controllerFuture.get() }
                    .onSuccess { mediaController ->
                        mediaController.addListener(listener)
                        _controller.value = mediaController
                        _state.update { it.copy(connecting = false) }
                        val queued = synchronized(pendingControllerActions) {
                            pendingControllerActions.toList().also { pendingControllerActions.clear() }
                        }
                        queued.forEach { it(mediaController) }
                        updateFrom(mediaController)
                    }
                    .onFailure { error ->
                        _state.update {
                            it.copy(
                                connecting = false,
                                resolving = false,
                                error = friendlyPlaybackError(error.message)
                            )
                        }
                    }
            },
            ContextCompat.getMainExecutor(appContext)
        )

        scope.launch {
            while (isActive) {
                _controller.value?.let(::updateFrom)
                delay(2_500L)
            }
        }
    }

    fun open(
        video: VideoItem,
        autoplay: Boolean,
        dataSaver: Boolean,
        repeat: Boolean = false
    ) {
        openInternal(
            video = video,
            autoplay = autoplay,
            dataSaver = dataSaver,
            repeat = repeat,
            preferredHeight = _preferredQualityHeight.value,
            forceReload = false
        )
    }

    private fun openInternal(
        video: VideoItem,
        autoplay: Boolean,
        dataSaver: Boolean,
        repeat: Boolean,
        preferredHeight: Int?,
        forceReload: Boolean
    ) {
        val controllerNow = _controller.value
        if (
            !forceReload &&
            currentVideo?.id == video.id &&
            controllerNow?.currentMediaItem?.mediaId == video.id &&
            controllerNow.mediaItemCount > 0
        ) {
            controllerNow.repeatMode = if (repeat) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
            if (autoplay && controllerNow.playbackState == Player.STATE_IDLE) controllerNow.prepare()
            if (autoplay && controllerNow.playbackState == Player.STATE_ENDED) {
                controllerNow.seekTo(0L)
                controllerNow.play()
            }
            return
        }

        controllerNow?.pause()
        currentVideo = video
        _preferredQualityHeight.value = preferredHeight
        playerPreferences.edit().putInt(KEY_PREFERRED_QUALITY, preferredHeight ?: 0).apply()
        resolveJob?.cancel()
        requestSerial += 1L
        val requestId = requestSerial
        _state.value = PlaybackUiState(
            connecting = controllerNow == null,
            resolving = true,
            currentVideoId = video.id,
            positionMs = video.resumePositionMs,
            durationMs = video.durationMs
        )

        resolveJob = scope.launch {
            try {
                val resolved = StreamResolver.resolve(
                    video = video,
                    dataSaver = dataSaver,
                    preferredHeight = preferredHeight,
                    preferProgressive = repeat && preferredHeight == null
                )
                if (requestId != requestSerial || currentVideo?.id != video.id) return@launch
                withController { controller ->
                    if (requestId != requestSerial || currentVideo?.id != video.id) return@withController
                    val metadata = MediaMetadata.Builder()
                        .setTitle(video.title)
                        .setArtist(video.channelTitle)
                        .setArtworkUri(video.thumbnailUrl.takeIf { it.isNotBlank() }?.let(Uri::parse))
                        .build()
                    val trackBuilder = controller.trackSelectionParameters
                        .buildUpon()
                        .clearVideoSizeConstraints()
                    if (!resolved.hasSeparateAudio) {
                        preferredHeight?.takeIf { it > 0 }?.let { exactHeight ->
                            trackBuilder
                                .setMinVideoSize(0, exactHeight)
                                .setMaxVideoSize(Int.MAX_VALUE, exactHeight)
                        }
                    }
                    controller.setTrackSelectionParameters(trackBuilder.build())
                    controller.repeatMode = if (repeat) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF

                    if (resolved.hasSeparateAudio) {
                        PlaybackService.playResolved(
                            context = appContext,
                            videoId = video.id,
                            title = video.title,
                            artist = video.channelTitle,
                            artwork = video.thumbnailUrl,
                            resolved = resolved,
                            positionMs = video.resumePositionMs,
                            autoplay = autoplay,
                            repeat = repeat
                        )
                    } else {
                        val item = MediaItem.Builder()
                            .setMediaId(video.id)
                            .setUri(resolved.uri)
                            .setMimeType(resolved.mimeType)
                            .setMediaMetadata(metadata)
                            .build()
                        controller.setMediaItem(item, video.resumePositionMs.coerceAtLeast(0L))
                        controller.prepare()
                        controller.playWhenReady = autoplay
                    }
                    _state.update { it.copy(resolving = false, error = null) }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                if (requestId != requestSerial || currentVideo?.id != video.id) return@launch
                _state.update {
                    it.copy(
                        resolving = false,
                        error = friendlyPlaybackError(error.message)
                    )
                }
            }
        }
    }

    internal suspend fun streamOptions(
        video: VideoItem,
        includeDownloadSizes: Boolean = true
    ): StreamOptions = StreamResolver.options(video, includeDownloadSizes)

    suspend fun isVerifiedShort(video: VideoItem): Boolean = StreamResolver.isVerifiedShort(video)

    fun selectQuality(video: VideoItem, height: Int?, dataSaver: Boolean) {
        val controllerNow = _controller.value
        val position = controllerNow?.currentPosition
            ?.takeIf { it >= 0L }
            ?: video.resumePositionMs
        val shouldPlay = controllerNow?.playWhenReady ?: true
        val repeat = controllerNow?.repeatMode == Player.REPEAT_MODE_ONE
        openInternal(
            video = video.copy(resumePositionMs = position),
            autoplay = shouldPlay,
            dataSaver = dataSaver,
            repeat = repeat,
            preferredHeight = height,
            forceReload = true
        )
    }


    fun retryShort(video: VideoItem, dataSaver: Boolean) {
        openInternal(
            video = video.copy(resumePositionMs = 0L),
            autoplay = true,
            dataSaver = dataSaver,
            repeat = true,
            preferredHeight = _preferredQualityHeight.value,
            forceReload = true
        )
    }

    fun play() = withController { it.play() }
    fun pause() = withController { it.pause() }
    fun seekTo(positionMs: Long) = withController { it.seekTo(positionMs.coerceAtLeast(0L)) }
    fun setMuted(muted: Boolean) = withController { it.volume = if (muted) 0f else 1f }
    fun setSpeed(speed: Float) = withController { it.setPlaybackSpeed(speed.coerceIn(0.25f, 2f)) }
    fun setMaxVideoHeight(height: Int) = withController { controller ->
        val builder = controller.trackSelectionParameters
            .buildUpon()
            .clearVideoSizeConstraints()
        if (height > 0) {
            builder
                .setMinVideoSize(0, height)
                .setMaxVideoSize(Int.MAX_VALUE, height)
        }
        controller.setTrackSelectionParameters(builder.build())
    }
    fun preload(videos: List<VideoItem>, dataSaver: Boolean) {
        if (videos.isEmpty()) return
        scope.launch { StreamResolver.preload(videos, dataSaver) }
    }
    fun setRepeat(enabled: Boolean) = withController {
        it.repeatMode = if (enabled) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
    }

    fun stop() {
        requestSerial += 1L
        resolveJob?.cancel()
        currentVideo = null
        // Keep the user's quality preference when closing or leaving Shorts.
        // The next video reuses it, matching DayliTube/YouTube behavior.
        withController {
            it.stop()
            it.clearMediaItems()
        }
        _state.value = PlaybackUiState(connecting = _controller.value == null)
    }

    private fun withController(action: (MediaController) -> Unit) {
        val ready = _controller.value
        if (ready != null) {
            action(ready)
        } else {
            synchronized(pendingControllerActions) { pendingControllerActions.add(action) }
        }
    }

    private fun friendlyPlaybackError(rawMessage: String?): String {
        val message = rawMessage.orEmpty()
        return when {
            message.contains("unable to resolve host", ignoreCase = true) ||
                message.contains("no address associated with hostname", ignoreCase = true) ||
                message.contains("youtubei.googleapis.com", ignoreCase = true) ->
                "No se pudo conectar con el servicio de video. Revisa tu conexión y pulsa Reintentar."
            message.contains("timeout", ignoreCase = true) ->
                "La conexión tardó demasiado. Pulsa Reintentar."
            message.isBlank() -> "No se pudo reproducir el video. Pulsa Reintentar."
            else -> "No se pudo reproducir el video. Pulsa Reintentar."
        }
    }

    private fun updateFrom(player: Player) {
        _state.update {
            it.copy(
                connecting = false,
                currentVideoId = player.currentMediaItem?.mediaId.orEmpty().ifBlank { it.currentVideoId },
                isPlaying = player.isPlaying,
                positionMs = player.currentPosition.coerceAtLeast(0L),
                durationMs = player.duration.takeIf { duration -> duration > 0L } ?: it.durationMs,
                bufferedPercentage = player.bufferedPercentage.coerceIn(0, 100),
                videoWidth = player.videoSize.width.coerceAtLeast(0),
                videoHeight = player.videoSize.height.coerceAtLeast(0),
                playbackState = player.playbackState,
                repeatMode = player.repeatMode,
                error = player.playerError?.localizedMessage ?: it.error
            )
        }
    }

    private fun release() {
        resolveJob?.cancel()
        _controller.value?.removeListener(listener)
        MediaController.releaseFuture(controllerFuture)
        scope.cancel()
    }

    companion object {
        private const val KEY_PREFERRED_QUALITY = "preferred_quality_height"

        @Volatile
        private var instance: GeoPlayerConnection? = null

        fun get(context: Context): GeoPlayerConnection =
            instance ?: synchronized(this) {
                instance ?: GeoPlayerConnection(context).also { instance = it }
            }
    }
}
