package com.geovideos.app.ui

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.bumptech.glide.Glide
import com.geovideos.app.data.VideoItem

@Composable
internal fun RecyclerHomeFeed(
    modifier: Modifier,
    videos: List<VideoItem>,
    shorts: List<VideoItem>,
    mixVideo: VideoItem?,
    loading: Boolean,
    refreshing: Boolean,
    loadingMore: Boolean,
    canLoadMore: Boolean,
    watchLaterIds: Set<String>,
    onRefresh: () -> Unit,
    onLoadMore: () -> Unit,
    onPlay: (VideoItem) -> Unit,
    onOpenShort: (VideoItem) -> Unit,
    onWatchLater: (VideoItem) -> Unit,
    scrollToTopSignal: Long,
    onAtTopChanged: (Boolean) -> Unit
) {
    var recyclerViewRef by remember { mutableStateOf<RecyclerView?>(null) }
    val adapter = remember {
        HomeFeedAdapter(
            onPlay = onPlay,
            onOpenShort = onOpenShort,
            onWatchLater = onWatchLater
        )
    }

    LaunchedEffect(scrollToTopSignal) {
        if (scrollToTopSignal > 0L) recyclerViewRef?.scrollHomeToTop()
    }

    AndroidView(
        modifier = modifier,
        factory = { context ->
            SwipeRefreshLayout(context).apply {
                setColorSchemeColors(0xFF9D6CFF.toInt())
                setProgressBackgroundColorSchemeColor(0xFF1D1B22.toInt())
                setOnRefreshListener { onRefresh() }
                addView(
                    RecyclerView(context).apply {
                        recyclerViewRef = this
                        val runtime = HomeFeedRuntime(onAtTopChanged)
                        tag = runtime
                        layoutManager = LinearLayoutManager(context).apply {
                            initialPrefetchItemCount = 4
                        }
                        this.adapter = adapter
                        itemAnimator = null
                        setHasFixedSize(false)
                        setItemViewCacheSize(4)
                        recycledViewPool.setMaxRecycledViews(HomeFeedAdapter.TYPE_VIDEO, 8)
                        overScrollMode = View.OVER_SCROLL_NEVER
                        isNestedScrollingEnabled = true

                        addOnScrollListener(object : RecyclerView.OnScrollListener() {
                            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                                runtime.onAtTopChanged(!recyclerView.canScrollVertically(-1))
                                if (dy <= 0) return
                                val manager = recyclerView.layoutManager as? LinearLayoutManager ?: return
                                val lastVisible = manager.findLastVisibleItemPosition()
                                val total = recyclerView.adapter?.itemCount ?: 0
                                val feedAdapter = recyclerView.adapter as? HomeFeedAdapter ?: return
                                if (
                                    feedAdapter.canLoadMore &&
                                    !feedAdapter.loadingMore &&
                                    total > 0 &&
                                    lastVisible >= total - 4
                                ) {
                                    feedAdapter.loadingMore = true
                                    feedAdapter.onLoadMore()
                                }
                            }

                            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                                runtime.onAtTopChanged(!recyclerView.canScrollVertically(-1))
                            }
                        })
                        post { runtime.onAtTopChanged(!canScrollVertically(-1)) }
                    },
                    ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
            }
        },
        update = { swipeRefresh ->
            swipeRefresh.isRefreshing = refreshing
            swipeRefresh.setOnRefreshListener { onRefresh() }
            val recyclerView = swipeRefresh.getChildAt(0) as RecyclerView
            recyclerViewRef = recyclerView
            (recyclerView.tag as? HomeFeedRuntime)?.onAtTopChanged = onAtTopChanged
            onAtTopChanged(!recyclerView.canScrollVertically(-1))
            val homeAdapter = recyclerView.adapter as HomeFeedAdapter
            homeAdapter.onPlay = onPlay
            homeAdapter.onOpenShort = onOpenShort
            homeAdapter.onWatchLater = onWatchLater
            homeAdapter.onLoadMore = onLoadMore
            homeAdapter.canLoadMore = canLoadMore
            homeAdapter.loadingMore = loadingMore
            homeAdapter.submitFeed(
                videos = videos,
                shorts = shorts,
                mixVideo = mixVideo,
                watchLaterIds = watchLaterIds,
                loading = loading,
                loadingMore = loadingMore
            )
        }
    )
}


private class HomeFeedRuntime(
    var onAtTopChanged: (Boolean) -> Unit
)

private fun RecyclerView.scrollHomeToTop() {
    val manager = layoutManager as? LinearLayoutManager ?: return
    val first = manager.findFirstVisibleItemPosition().coerceAtLeast(0)
    if (first > 12) scrollToPosition(8)
    post { smoothScrollToPosition(0) }
}

private sealed interface HomeFeedRow {
    val stableId: Long

    data class Shorts(val videos: List<VideoItem>) : HomeFeedRow {
        override val stableId: Long = Long.MIN_VALUE + 10
    }

    data class Mix(val video: VideoItem) : HomeFeedRow {
        override val stableId: Long = Long.MIN_VALUE + 11
    }

    data class Video(val video: VideoItem, val saved: Boolean) : HomeFeedRow {
        override val stableId: Long = video.id.hashCode().toLong()
    }

    data object Loading : HomeFeedRow {
        override val stableId: Long = Long.MIN_VALUE + 20
    }

    data object Empty : HomeFeedRow {
        override val stableId: Long = Long.MIN_VALUE + 30
    }
}

private object HomeFeedDiff : DiffUtil.ItemCallback<HomeFeedRow>() {
    override fun areItemsTheSame(oldItem: HomeFeedRow, newItem: HomeFeedRow): Boolean =
        oldItem.stableId == newItem.stableId

    override fun areContentsTheSame(oldItem: HomeFeedRow, newItem: HomeFeedRow): Boolean =
        oldItem == newItem
}

private class HomeFeedAdapter(
    var onPlay: (VideoItem) -> Unit,
    var onOpenShort: (VideoItem) -> Unit,
    var onWatchLater: (VideoItem) -> Unit
) : ListAdapter<HomeFeedRow, RecyclerView.ViewHolder>(HomeFeedDiff) {

    var onLoadMore: () -> Unit = {}
    var canLoadMore: Boolean = false
    var loadingMore: Boolean = false

    init {
        setHasStableIds(true)
    }

    fun submitFeed(
        videos: List<VideoItem>,
        shorts: List<VideoItem>,
        mixVideo: VideoItem?,
        watchLaterIds: Set<String>,
        loading: Boolean,
        loadingMore: Boolean
    ) {
        val rows = buildList {
            if (shorts.isNotEmpty()) add(HomeFeedRow.Shorts(shorts.take(12)))
            val firstVideo = videos.firstOrNull()
            firstVideo?.let { add(HomeFeedRow.Video(it, it.id in watchLaterIds)) }
            mixVideo?.let { add(HomeFeedRow.Mix(it)) }
            videos.drop(if (firstVideo == null) 0 else 1).forEach { video ->
                add(HomeFeedRow.Video(video, video.id in watchLaterIds))
            }
            when {
                loadingMore -> add(HomeFeedRow.Loading)
                loading && videos.isEmpty() && shorts.isEmpty() && mixVideo == null -> add(HomeFeedRow.Loading)
                videos.isEmpty() && shorts.isEmpty() && mixVideo == null -> add(HomeFeedRow.Empty)
            }
        }
        this.loadingMore = loadingMore
        submitList(rows)
    }

    override fun getItemId(position: Int): Long = getItem(position).stableId

    override fun getItemViewType(position: Int): Int = when (getItem(position)) {
        is HomeFeedRow.Shorts -> TYPE_SHORTS
        is HomeFeedRow.Mix -> TYPE_MIX
        is HomeFeedRow.Video -> TYPE_VIDEO
        HomeFeedRow.Loading -> TYPE_LOADING
        HomeFeedRow.Empty -> TYPE_EMPTY
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder = when (viewType) {
        TYPE_SHORTS -> ShortsShelfHolder(parent.context, onOpenShort)
        TYPE_MIX -> MixHolder(parent.context, onPlay)
        TYPE_VIDEO -> VideoHolder(parent.context, onPlay, onWatchLater)
        TYPE_LOADING -> LoadingHolder(parent.context)
        else -> EmptyHolder(parent.context)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = getItem(position)) {
            is HomeFeedRow.Shorts -> (holder as ShortsShelfHolder).bind(row.videos, onOpenShort)
            is HomeFeedRow.Mix -> (holder as MixHolder).bind(row.video, onPlay)
            is HomeFeedRow.Video -> (holder as VideoHolder).bind(row.video, row.saved, onPlay, onWatchLater)
            HomeFeedRow.Loading -> Unit
            HomeFeedRow.Empty -> Unit
        }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        when (holder) {
            is VideoHolder -> holder.recycle()
            is MixHolder -> holder.recycle()
            is ShortsShelfHolder -> holder.recycle()
        }
    }

    companion object {
        const val TYPE_SHORTS = 1
        const val TYPE_MIX = 2
        const val TYPE_VIDEO = 3
        const val TYPE_LOADING = 4
        const val TYPE_EMPTY = 5
    }
}


private class MixHolder(
    context: Context,
    onPlay: (VideoItem) -> Unit
) : RecyclerView.ViewHolder(MixCardView(context)) {
    private val card = itemView as MixCardView
    private var current: VideoItem? = null

    init { card.setOnClickListener { current?.let(onPlay) } }

    fun bind(video: VideoItem, onPlay: (VideoItem) -> Unit) {
        current = video
        card.setOnClickListener { onPlay(video) }
        card.title.text = "Mix: ${video.title}"
        card.subtitle.text = buildString {
            append(video.channelTitle.ifBlank { "Selección automática" })
            append(" y más")
        }
        loadClearThumbnail(card.image, video.thumbnailUrl, 720, 405)
    }

    fun recycle() {
        current = null
        Glide.with(card.image).clear(card.image)
        card.setOnClickListener(null)
    }
}

private class VideoHolder(
    context: Context,
    onPlay: (VideoItem) -> Unit,
    onWatchLater: (VideoItem) -> Unit
) : RecyclerView.ViewHolder(VideoCardView(context)) {
    private val card = itemView as VideoCardView
    private var current: VideoItem? = null

    init {
        card.setOnClickListener { current?.let(onPlay) }
        card.moreButton.setOnClickListener { current?.let(onWatchLater) }
    }

    fun bind(
        video: VideoItem,
        saved: Boolean,
        onPlay: (VideoItem) -> Unit,
        onWatchLater: (VideoItem) -> Unit
    ) {
        current = video
        card.setOnClickListener { onPlay(video) }
        card.moreButton.setOnClickListener { onWatchLater(video) }
        card.titleView.text = video.title
        card.channelView.text = buildString {
            append(video.channelTitle)
            val published = formatRecyclerPublished(video.publishedAt)
            if (published.isNotBlank()) {
                append(" · ")
                append(published)
            }
        }
        card.moreButton.text = if (saved) "✓" else "⋮"
        card.liveBadge.visibility = if (video.isLive) View.VISIBLE else View.GONE
        card.durationBadge.text = formatRecyclerDuration(video.durationMs)
        card.durationBadge.visibility = if (video.durationMs > 0L && !video.isLive) View.VISIBLE else View.GONE

        loadClearThumbnail(card.thumbnail, video.thumbnailUrl, 640, 360)

        if (video.channelThumbnailUrl.isBlank()) {
            Glide.with(card.avatar).clear(card.avatar)
            card.avatar.setImageDrawable(ColorDrawable(0xFF4A2A79.toInt()))
        } else {
            Glide.with(card.avatar)
                .load(video.channelThumbnailUrl)
                .override(72, 72)
                .dontAnimate()
                .placeholder(ColorDrawable(0xFF303036.toInt()))
                .error(ColorDrawable(0xFF4A2A79.toInt()))
                .circleCrop()
                .into(card.avatar)
        }
    }

    fun recycle() {
        current = null
        card.titleView.text = ""
        card.channelView.text = ""
        card.moreButton.text = "⋮"
        card.liveBadge.visibility = View.GONE
        card.durationBadge.visibility = View.GONE
        Glide.with(card.thumbnail).clear(card.thumbnail)
        Glide.with(card.avatar).clear(card.avatar)
        card.setOnClickListener(null)
        card.moreButton.setOnClickListener(null)
    }
}

private class ShortsShelfHolder(
    context: Context,
    onOpenShort: (VideoItem) -> Unit
) : RecyclerView.ViewHolder(ShortsShelfView(context, onOpenShort)) {
    private val shelf = itemView as ShortsShelfView

    fun bind(videos: List<VideoItem>, onOpenShort: (VideoItem) -> Unit) {
        shelf.adapter.onOpenShort = onOpenShort
        shelf.adapter.submitList(videos)
    }

    fun recycle() {
        // The nested RecyclerView owns its recycled image requests.
    }
}

private class LoadingHolder(context: Context) : RecyclerView.ViewHolder(
    FrameLayout(context).apply {
        layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 96))
        addView(
            ProgressBar(context),
            FrameLayout.LayoutParams(dp(context, 38), dp(context, 38), Gravity.CENTER)
        )
    }
)

private class EmptyHolder(context: Context) : RecyclerView.ViewHolder(
    TextView(context).apply {
        layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 120))
        text = "No hay videos disponibles. Pulsa actualizar."
        gravity = Gravity.CENTER
        setTextColor(0xFFB6B3BE.toInt())
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        setPadding(dp(context, 20), dp(context, 20), dp(context, 20), dp(context, 20))
    }
)

private class ShortsShelfView(
    context: Context,
    onOpenShort: (VideoItem) -> Unit
) : LinearLayout(context) {
    val adapter = ShortsAdapter(onOpenShort)

    init {
        orientation = VERTICAL
        layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setPadding(0, dp(context, 8), 0, dp(context, 14))

        addView(TextView(context).apply {
            text = "Shorts"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 21f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(context, 14), dp(context, 6), dp(context, 14), dp(context, 10))
        })

        addView(RecyclerView(context).apply {
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 288))
            layoutManager = LinearLayoutManager(context, RecyclerView.HORIZONTAL, false).apply {
                initialPrefetchItemCount = 3
            }
            this.adapter = this@ShortsShelfView.adapter
            itemAnimator = null
            setItemViewCacheSize(4)
            overScrollMode = View.OVER_SCROLL_NEVER
            setPadding(dp(context, 10), 0, dp(context, 10), 0)
            clipToPadding = false
        })
    }
}

private object ShortDiff : DiffUtil.ItemCallback<VideoItem>() {
    override fun areItemsTheSame(oldItem: VideoItem, newItem: VideoItem): Boolean = oldItem.id == newItem.id
    override fun areContentsTheSame(oldItem: VideoItem, newItem: VideoItem): Boolean = oldItem == newItem
}

private class ShortsAdapter(
    var onOpenShort: (VideoItem) -> Unit
) : ListAdapter<VideoItem, ShortHolder>(ShortDiff) {
    init {
        setHasStableIds(true)
    }

    override fun getItemId(position: Int): Long = getItem(position).id.hashCode().toLong()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShortHolder = ShortHolder(parent.context)

    override fun onBindViewHolder(holder: ShortHolder, position: Int) {
        val video = getItem(position)
        holder.bind(video, onOpenShort)
    }

    override fun onViewRecycled(holder: ShortHolder) {
        holder.recycle()
    }
}

private class ShortHolder(context: Context) : RecyclerView.ViewHolder(ShortCardView(context)) {
    private val card = itemView as ShortCardView

    fun bind(video: VideoItem, onOpenShort: (VideoItem) -> Unit) {
        card.setOnClickListener { onOpenShort(video) }
        card.title.text = video.title
        card.meta.text = buildString {
            append(video.channelTitle.ifBlank { "Short recomendado" })
            formatRecyclerPublished(video.publishedAt).takeIf { it.isNotBlank() }?.let {
                append(" · ")
                append(it)
            }
        }
        loadClearThumbnail(card.image, video.thumbnailUrl, 360, 640, fitCenter = false)
    }

    fun recycle() {
        Glide.with(card.image).clear(card.image)
    }
}

private class VideoCardView(context: Context) : LinearLayout(context) {
    val thumbnail = ImageView(context)
    val avatar = ImageView(context)
    val titleView = TextView(context)
    val channelView = TextView(context)
    val moreButton = TextView(context)
    val liveBadge = TextView(context)
    val durationBadge = TextView(context)

    init {
        orientation = VERTICAL
        layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        isClickable = true
        isFocusable = true
        foreground = context.obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackground)).getDrawable(0)

        val mediaFrame = SixteenNineFrame(context).apply {
            setBackgroundColor(Color.BLACK)
            addView(thumbnail, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            addView(liveBadge.apply {
                text = "EN VIVO"
                setTextColor(Color.WHITE)
                setBackgroundColor(0xFFD32F2F.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(dp(context, 7), dp(context, 3), dp(context, 7), dp(context, 3))
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START).apply {
                setMargins(dp(context, 10), 0, 0, dp(context, 10))
            })
            addView(durationBadge.apply {
                setTextColor(Color.WHITE)
                setBackgroundColor(0xCC000000.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                setPadding(dp(context, 6), dp(context, 2), dp(context, 6), dp(context, 2))
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(context, 10), dp(context, 10))
            })
        }
        addView(mediaFrame)

        val info = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.TOP
            setPadding(dp(context, 14), dp(context, 10), dp(context, 8), dp(context, 11))
        }
        info.addView(avatar.apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF303036.toInt())
        }, LayoutParams(dp(context, 40), dp(context, 40)))

        info.addView(LinearLayout(context).apply {
            orientation = VERTICAL
            addView(titleView.apply {
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            }, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(channelView.apply {
                setTextColor(0xFFB6B3BE.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(0, dp(context, 4), 0, 0)
            }, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(context, 11)
        })

        info.addView(moreButton.apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 23f)
            isClickable = true
            isFocusable = true
            foreground = context.obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackgroundBorderless)).getDrawable(0)
        }, LayoutParams(dp(context, 44), dp(context, 44)))
        addView(info)
    }
}

private class ShortCardView(context: Context) : FrameLayout(context) {
    val image = ImageView(context)
    val title = TextView(context)
    val meta = TextView(context)
    private val more = TextView(context)

    init {
        layoutParams = RecyclerView.LayoutParams(dp(context, 154), dp(context, 278)).apply {
            marginEnd = dp(context, 10)
        }
        setBackgroundColor(Color.BLACK)
        clipToOutline = true
        outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(view: View, outline: android.graphics.Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(context, 12).toFloat())
            }
        }
        image.scaleType = ImageView.ScaleType.CENTER_CROP
        addView(image, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val gradient = View(context).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.BOTTOM_TOP,
                intArrayOf(0xE6000000.toInt(), 0x70000000, 0x00000000)
            )
        }
        addView(gradient, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 132), Gravity.BOTTOM))

        more.apply {
            text = "⋮"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            gravity = Gravity.CENTER
            setShadowLayer(5f, 0f, 1f, Color.BLACK)
        }
        addView(more, LayoutParams(dp(context, 34), dp(context, 40), Gravity.TOP or Gravity.END).apply {
            setMargins(0, dp(context, 4), dp(context, 3), 0)
        })

        val textBox = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(context, 9), dp(context, 8), dp(context, 9), dp(context, 10))
            title.setTextColor(Color.WHITE)
            title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
            title.maxLines = 3
            title.ellipsize = android.text.TextUtils.TruncateAt.END
            meta.setTextColor(0xFFE1DDE7.toInt())
            meta.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            meta.maxLines = 1
            meta.ellipsize = android.text.TextUtils.TruncateAt.END
            meta.setPadding(0, dp(context, 5), 0, 0)
            addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(meta, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        addView(textBox, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
    }
}

private class MixCardView(context: Context) : LinearLayout(context) {
    val image = ImageView(context)
    val title = TextView(context)
    val subtitle = TextView(context)

    init {
        orientation = VERTICAL
        layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        isClickable = true
        isFocusable = true
        foreground = context.obtainStyledAttributes(intArrayOf(android.R.attr.selectableItemBackground)).getDrawable(0)

        val frame = SixteenNineFrame(context).apply {
            setPadding(dp(context, 14), 0, dp(context, 14), 0)
            image.scaleType = ImageView.ScaleType.CENTER_CROP
            addView(image, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply {
                setMargins(dp(context, 14), 0, dp(context, 14), 0)
            })
            addView(TextView(context).apply {
                text = "MIX"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(dp(context, 7), dp(context, 4), dp(context, 7), dp(context, 4))
                setBackgroundColor(0xB0000000.toInt())
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(context, 22), dp(context, 10))
            })
        }
        addView(frame)

        title.setTextColor(Color.WHITE)
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
        title.maxLines = 2
        title.ellipsize = android.text.TextUtils.TruncateAt.END
        addView(title, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(context, 16), dp(context, 9), dp(context, 16), 0)
        })

        subtitle.setTextColor(0xFFAAA7B2.toInt())
        subtitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        subtitle.maxLines = 1
        subtitle.ellipsize = android.text.TextUtils.TruncateAt.END
        addView(subtitle, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(context, 16), dp(context, 3), dp(context, 16), dp(context, 16))
        })
    }
}

private class SixteenNineFrame(context: Context) : FrameLayout(context) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val height = (width * 9f / 16f).toInt()
        super.onMeasure(
            MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY)
        )
    }
}

private fun loadClearThumbnail(
    view: ImageView,
    url: String,
    width: Int,
    height: Int,
    fitCenter: Boolean = false
) {
    val manager = Glide.with(view)
    val placeholder = ColorDrawable(0xFF202024.toInt())
    if (!isYoutubeThumbnail(url)) {
        val request = manager.load(url)
            .override(width, height)
            .dontAnimate()
            .placeholder(placeholder)
            .error(ColorDrawable(0xFF2B1B45.toInt()))
        if (fitCenter) request.fitCenter() else request.centerCrop()
        request.into(view)
        return
    }

    val low = manager.load(youtubeThumb(url, "mqdefault.jpg"))
        .override(320, 180)
        .dontAnimate()
        .centerCrop()
    val highFallback = manager.load(youtubeThumb(url, "hqdefault.jpg"))
        .override(width, height)
        .dontAnimate()
        .apply { if (fitCenter) fitCenter() else centerCrop() }
        .error(low)
    val clear = manager.load(youtubeThumb(url, "sddefault.jpg"))
        .override(width, height)
        .dontAnimate()
        .placeholder(placeholder)
        .thumbnail(low)
        .error(highFallback)
    if (fitCenter) clear.fitCenter() else clear.centerCrop()
    clear.into(view)
}

private fun isYoutubeThumbnail(url: String): Boolean =
    url.contains("ytimg.com", ignoreCase = true) ||
        url.contains("youtube.com", ignoreCase = true)

private fun youtubeThumb(url: String, fileName: String): String =
    url.replace(Regex("(maxresdefault|sddefault|hqdefault|mqdefault|default)\\.jpg"), fileName)

private fun formatRecyclerDuration(ms: Long): String {
    if (ms <= 0L) return ""
    val total = ms / 1000L
    val hours = total / 3600L
    val minutes = (total % 3600L) / 60L
    val seconds = total % 60L
    return if (hours > 0L) "%d:%02d:%02d".format(hours, minutes, seconds)
    else "%d:%02d".format(minutes, seconds)
}

private fun formatRecyclerPublished(value: String): String {
    if (value.isBlank()) return ""
    if (value.contains("hace", ignoreCase = true)) return value
    return runCatching {
        val instant = runCatching { java.time.Instant.parse(value) }.getOrElse {
            java.time.LocalDate.parse(value.take(10))
                .atStartOfDay(java.time.ZoneId.systemDefault())
                .toInstant()
        }
        val elapsed = (java.time.Instant.now().epochSecond - instant.epochSecond).coerceAtLeast(0L)
        when {
            elapsed < 3_600L -> "hace ${maxOf(1L, elapsed / 60L)} min"
            elapsed < 86_400L -> "hace ${elapsed / 3_600L} h"
            elapsed < 604_800L -> "hace ${elapsed / 86_400L} días"
            elapsed < 2_592_000L -> "hace ${elapsed / 604_800L} semanas"
            elapsed < 31_536_000L -> "hace ${elapsed / 2_592_000L} meses"
            else -> "hace ${elapsed / 31_536_000L} años"
        }
    }.getOrElse { value.take(10) }
}

private fun dp(context: Context, value: Int): Int =
    (value * context.resources.displayMetrics.density).toInt()

private fun resolveColor(context: Context, attr: Int, fallback: Int): Int {
    val value = TypedValue()
    return if (context.theme.resolveAttribute(attr, value, true)) value.data else fallback
}
