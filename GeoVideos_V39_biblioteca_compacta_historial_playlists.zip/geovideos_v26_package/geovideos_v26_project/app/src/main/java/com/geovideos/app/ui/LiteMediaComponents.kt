package com.geovideos.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.Color as AndroidColor
import android.view.LayoutInflater
import android.view.View
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.ui.PlayerView
import androidx.media3.ui.R as Media3UiR
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import coil.size.Precision
import com.geovideos.app.R
import com.geovideos.app.data.MediaKind
import com.geovideos.app.data.VideoItem

@OptIn(UnstableApi::class)
@Composable
internal fun LitePlayerView(
    controller: MediaController,
    modifier: Modifier = Modifier,
    useController: Boolean,
    resizeMode: Int = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT,
    useTextureView: Boolean = false,
    onSettingsClick: (() -> Unit)? = null
) {
    val attachedView = remember { arrayOfNulls<PlayerView>(1) }
    DisposableEffect(controller) {
        onDispose {
            attachedView[0]?.let { view ->
                if (view.player === controller) view.player = null
            }
            attachedView[0] = null
        }
    }
    AndroidView(
        modifier = modifier.background(Color.Black),
        factory = { context ->
            val layout = if (useTextureView) R.layout.geo_player_texture else R.layout.geo_player_surface
            (LayoutInflater.from(context)
                .inflate(layout, null, false) as PlayerView).apply {
                attachedView[0] = this
                player = controller
                this.useController = useController
                controllerAutoShow = useController
                controllerHideOnTouch = true
                controllerShowTimeoutMs = 2_300
                keepScreenOn = true
                setKeepContentOnPlayerReset(true)
                setShutterBackgroundColor(AndroidColor.TRANSPARENT)
                setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                setShowPreviousButton(false)
                setShowNextButton(false)
                setShowRewindButton(true)
                setShowFastForwardButton(true)
                this.resizeMode = resizeMode
                findViewById<View>(Media3UiR.id.exo_settings)?.setOnClickListener {
                    onSettingsClick?.invoke()
                }
            }
        },
        update = { view ->
            attachedView[0] = view
            if (view.player !== controller) view.player = controller
            view.useController = useController
            view.controllerAutoShow = useController
            view.resizeMode = resizeMode
            view.findViewById<View>(Media3UiR.id.exo_settings)?.setOnClickListener {
                onSettingsClick?.invoke()
            }
        }
    )
}

@Composable
internal fun LiteThumbnail(
    url: String,
    description: String?,
    modifier: Modifier,
    widthPx: Int,
    heightPx: Int,
    contentScale: ContentScale = ContentScale.Crop,
    deferWhileScrolling: Boolean = false
) {
    var loadedSuccessfully by remember(url) { mutableStateOf(false) }

    if (url.isBlank()) {
        LiteThumbnailFallback(modifier)
        return
    }

    // During a fast fling, newly appearing cells show a cheap solid placeholder.
    // Already-decoded images remain visible. Once scrolling stops, Coil starts the request.
    if (deferWhileScrolling && !loadedSuccessfully) {
        Box(modifier = modifier.background(Color(0xFF202024)))
        return
    }

    val context = LocalContext.current
    val request = remember(url, widthPx, heightPx) {
        ImageRequest.Builder(context)
            .data(url)
            .size(widthPx, heightPx)
            .precision(Precision.INEXACT)
            .allowHardware(true)
            .memoryCachePolicy(CachePolicy.ENABLED)
            .diskCachePolicy(CachePolicy.ENABLED)
            .networkCachePolicy(CachePolicy.ENABLED)
            .crossfade(false)
            .build()
    }
    AsyncImage(
        model = request,
        contentDescription = description,
        modifier = modifier.background(Color.Black),
        contentScale = contentScale,
        onSuccess = { loadedSuccessfully = true },
        onError = { loadedSuccessfully = false }
    )
}

@Composable
private fun LiteThumbnailFallback(modifier: Modifier) {
    Box(
        modifier = modifier.background(
            Brush.linearGradient(listOf(Color(0xFF24163D), Color(0xFF4A2A79), Color.Black))
        ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.Default.PlayArrow,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.82f),
            modifier = Modifier.size(42.dp)
        )
    }
}

internal fun shareVideoLite(context: Context, video: VideoItem) {
    val url = if (video.mediaKind == MediaKind.YOUTUBE) {
        "https://www.youtube.com/watch?v=${video.id}"
    } else {
        video.source
    }
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, "${video.title}\n$url")
    }
    context.startActivity(Intent.createChooser(intent, "Compartir video"))
}

internal tailrec fun Context.findActivityLite(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivityLite()
    else -> null
}
