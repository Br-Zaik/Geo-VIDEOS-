// Gana Geo · Verificación de compras de Google Play.
// El teléfono solo envía el token. Este servidor lo valida con la API oficial de
// Google Play y acredita los créditos UNA sola vez (idempotente).
// Secretos: GOOGLE_PLAY_SERVICE_ACCOUNT_JSON (obligatorio), PLAY_PACKAGE_NAME (opcional),
// ALLOW_TEST_PURCHASES=true solo durante pruebas internas/cerradas.
import { createClient } from "jsr:@supabase/supabase-js@2";

const PACKAGE_NAME = Deno.env.get("PLAY_PACKAGE_NAME") ?? "com.ganageo.app";
const PRODUCTS = new Set(["pack_geo_50", "pack_geo_100"]);

function json(body: Record<string, unknown>, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

async function sha256Hex(text: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function base64UrlBytes(bytes: Uint8Array): string {
  let binary = "";
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function base64UrlText(text: string): string {
  return base64UrlBytes(new TextEncoder().encode(text));
}

let cachedToken: { value: string; expiresAt: number } | null = null;

async function googleAccessToken(serviceAccount: { client_email: string; private_key: string }): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  if (cachedToken && cachedToken.expiresAt - 60 > now) return cachedToken.value;

  const header = { alg: "RS256", typ: "JWT" };
  const claims = {
    iss: serviceAccount.client_email,
    scope: "https://www.googleapis.com/auth/androidpublisher",
    aud: "https://oauth2.googleapis.com/token",
    iat: now,
    exp: now + 3600,
  };
  const unsigned = `${base64UrlText(JSON.stringify(header))}.${base64UrlText(JSON.stringify(claims))}`;
  const pem = serviceAccount.private_key.replace(/-----[^-]+-----/g, "").replace(/\s+/g, "");
  const der = Uint8Array.from(atob(pem), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey(
    "pkcs8",
    der,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const signature = new Uint8Array(
    await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(unsigned)),
  );
  const assertion = `${unsigned}.${base64UrlBytes(signature)}`;

  const response = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion,
    }),
  });
  if (!response.ok) throw new Error("google_auth_failed");
  const payload = await response.json();
  cachedToken = { value: payload.access_token, expiresAt: now + Number(payload.expires_in ?? 3600) };
  return cachedToken.value;
}

function friendlyRpcError(message: string): string {
  if (message.includes("not enabled")) return "Las compras todavía no están habilitadas.";
  if (message.includes("another account")) return "La compra pertenece a otra cuenta.";
  if (message.includes("already processed")) return "Esta compra ya fue procesada.";
  if (message.includes("Unsupported product")) return "Producto no reconocido.";
  return "No se pudo acreditar la compra.";
}

Deno.serve(async (req: Request) => {
  if (req.method !== "POST") return json({ ok: false, error: "Método no permitido." }, 405);

  const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
  const authorization = req.headers.get("Authorization") ?? "";
  if (!authorization.startsWith("Bearer ")) return json({ ok: false, error: "Sesión no válida." }, 401);

  // 1) Usuario real de Supabase (no se confía en datos enviados por el teléfono).
  const userClient = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: authorization } },
    auth: { persistSession: false },
  });
  const { data: userData, error: userError } = await userClient.auth.getUser();
  if (userError || !userData?.user) return json({ ok: false, error: "Sesión no válida." }, 401);
  const userId = userData.user.id;

  // 2) Entrada mínima y validada.
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return json({ ok: false, error: "Solicitud inválida." }, 400);
  }
  const productId = String(body?.product_id ?? "");
  const purchaseToken = String(body?.purchase_token ?? "");
  if (!PRODUCTS.has(productId) || purchaseToken.length < 20 || purchaseToken.length > 4096) {
    return json({ ok: false, error: "Datos de compra inválidos." }, 400);
  }

  const rawServiceAccount = Deno.env.get("GOOGLE_PLAY_SERVICE_ACCOUNT_JSON");
  if (!rawServiceAccount) {
    return json({ ok: false, error: "La verificación de compras aún no está configurada." });
  }

  // 3) Consulta oficial a Google Play.
  let purchase: Record<string, unknown>;
  try {
    const accessToken = await googleAccessToken(JSON.parse(rawServiceAccount));
    const url =
      `https://androidpublisher.googleapis.com/androidpublisher/v3/applications/${encodeURIComponent(PACKAGE_NAME)}` +
      `/purchases/products/${encodeURIComponent(productId)}/tokens/${encodeURIComponent(purchaseToken)}`;
    const response = await fetch(url, { headers: { Authorization: `Bearer ${accessToken}` } });
    if (!response.ok) return json({ ok: false, error: "Google Play no confirmó la compra." });
    purchase = await response.json();
  } catch {
    return json({ ok: false, error: "No se pudo consultar Google Play. Se reintentará." });
  }

  // purchaseState: 0 = comprado, 1 = cancelado, 2 = pendiente. Solo se acredita 0.
  if (purchase.purchaseState !== 0) {
    return json({
      ok: false,
      error: purchase.purchaseState === 2 ? "Pago pendiente de confirmación." : "La compra fue cancelada.",
    });
  }

  // La app envía un hash del id de usuario al abrir el pago: debe coincidir.
  const expectedAccount = await sha256Hex(userId);
  if (purchase.obfuscatedExternalAccountId !== expectedAccount) {
    return json({ ok: false, error: "La compra pertenece a otra cuenta." });
  }

  // purchaseType 0 = compra de prueba (licencias de prueba). Bloqueada salvo en pruebas.
  if (purchase.purchaseType === 0 && Deno.env.get("ALLOW_TEST_PURCHASES") !== "true") {
    return json({ ok: false, error: "Compra de prueba no permitida." });
  }

  // 4) Acreditación atómica e idempotente en la base de datos.
  const admin = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false } });
  const tokenHash = await sha256Hex(purchaseToken);
  const { data, error } = await admin.rpc("grant_verified_tool_pack_v2", {
    p_user_id: userId,
    p_purchase_token_hash: tokenHash,
    p_product_id: productId,
    p_order_id: (purchase.orderId as string | undefined) ?? null,
    p_raw_payload: {
      purchaseState: purchase.purchaseState ?? null,
      consumptionState: purchase.consumptionState ?? null,
      purchaseType: purchase.purchaseType ?? null,
      regionCode: purchase.regionCode ?? null,
      purchaseTimeMillis: purchase.purchaseTimeMillis ?? null,
    },
  });
  if (error) return json({ ok: false, error: friendlyRpcError(error.message ?? "") });

  const row = Array.isArray(data) ? data[0] : data;
  return json({
    ok: true,
    credits_granted: Number(row?.credits_granted ?? 0),
    already_processed: Boolean(row?.already_processed),
  });
});
