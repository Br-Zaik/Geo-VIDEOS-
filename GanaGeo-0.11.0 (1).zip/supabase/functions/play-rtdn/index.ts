// Gana Geo · Notificaciones en tiempo real de Google Play (Pub/Sub push).
// Cuando Google anula o reembolsa una compra, se retiran los créditos que no se usaron.
// Seguridad: la URL de suscripción debe incluir ?secret=<PLAY_RTDN_SECRET>.
import { createClient } from "jsr:@supabase/supabase-js@2";

async function sha256Hex(text: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

Deno.serve(async (req: Request) => {
  const expected = Deno.env.get("PLAY_RTDN_SECRET") ?? "";
  const provided = new URL(req.url).searchParams.get("secret") ?? "";
  if (!expected || !timingSafeEqual(expected, provided)) return new Response("forbidden", { status: 403 });
  if (req.method !== "POST") return new Response("method not allowed", { status: 405 });

  let notification: Record<string, any> = {};
  try {
    const envelope = await req.json();
    const data = envelope?.message?.data;
    if (typeof data === "string" && data.length < 20000) {
      notification = JSON.parse(atob(data));
    }
  } catch {
    // Mensaje mal formado: se confirma para que Pub/Sub no lo reintente sin fin.
    return new Response("ignored", { status: 200 });
  }

  const voided = notification?.voidedPurchaseNotification;
  if (voided?.purchaseToken && typeof voided.purchaseToken === "string") {
    const admin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } },
    );
    const tokenHash = await sha256Hex(voided.purchaseToken);
    const { error } = await admin.rpc("revoke_refunded_tool_pack", {
      p_purchase_token_hash: tokenHash,
      p_reason: `voided_refund_type_${voided.refundType ?? "unknown"}`,
    });
    if (error) return new Response("retry", { status: 500 });
  }

  return new Response("ok", { status: 200 });
});
