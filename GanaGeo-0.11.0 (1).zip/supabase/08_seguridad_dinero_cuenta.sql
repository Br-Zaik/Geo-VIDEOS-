-- Gana Geo: seguridad del dinero, retiros solo Yape,
-- eliminación de cuenta y verificación de compras de Google Play.
-- Ejecutar DESPUÉS de 01..08. Es aditiva e idempotente: se puede volver a correr.
-- No borra usuarios, saldos, historial ni pagos existentes.

begin;

-- =========================================================
-- 0. VERIFICACIÓN DE INSTALACIÓN ACTIVA (se restaura si falta)
-- =========================================================
create or replace function public.assert_active_installation(
    p_user_id uuid,
    p_installation_hash text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
    if p_user_id is null or p_installation_hash is null
       or length(trim(p_installation_hash)) < 16 then
        raise exception 'Invalid installation identifier';
    end if;

    if not exists (
        select 1
          from public.devices
         where user_id = p_user_id
           and installation_hash = trim(p_installation_hash)
           and device_status = 'active'
    ) then
        raise exception 'This installation is not active';
    end if;
end;
$$;

revoke all on function public.assert_active_installation(uuid, text)
from public, anon, authenticated;

-- =========================================================
-- 1. INTERRUPTORES DEL SERVIDOR (solo el administrador los cambia)
-- =========================================================
create table if not exists public.app_settings (
    key text primary key,
    enabled boolean not null default false,
    note text,
    updated_at timestamptz not null default now()
);

alter table public.app_settings enable row level security;
revoke all on public.app_settings from anon, authenticated;

insert into public.app_settings (key, enabled, note) values
    ('withdrawals_enabled', false,
     'Retiros por Yape. Mantener en false hasta validar política de Google Play, asesoría legal/contable y operación manual.'),
    ('purchases_enabled', false,
     'Acreditación de compras de Google Play. Activar solo cuando la Edge Function tenga credenciales reales y pruebas aprobadas.')
on conflict (key) do nothing;

create or replace function public.app_flag(p_key text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
    select coalesce((select s.enabled from public.app_settings s where s.key = p_key), false);
$$;

revoke all on function public.app_flag(text) from public, anon, authenticated;

-- Estado público (solo lectura) que la app usa para mostrar u ocultar opciones.
create or replace function public.get_app_features()
returns table (
    withdrawals_enabled boolean,
    purchases_enabled boolean,
    min_withdrawal numeric,
    withdrawal_method text
)
language sql
stable
security definer
set search_path = ''
as $$
    select public.app_flag('withdrawals_enabled'),
           public.app_flag('purchases_enabled'),
           5.00::numeric,
           'yape'::text;
$$;

revoke all on function public.get_app_features() from public, anon;
grant execute on function public.get_app_features() to authenticated;

-- =========================================================
-- 2. RETIROS SOLO POR YAPE (manual, bloqueados por defecto)
-- =========================================================
-- Los métodos antiguos se conservan SOLO para leer registros históricos.
-- Toda solicitud NUEVA debe ser Yape (regla en la base, no solo en la app).
create or replace function public.enforce_yape_only_withdrawal()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
    if new.payment_method <> 'yape' then
        raise exception 'Only Yape withdrawals are accepted';
    end if;
    return new;
end;
$$;

create or replace trigger withdrawals_yape_only
before insert on public.withdrawals
for each row execute function public.enforce_yape_only_withdrawal();

-- Una sola solicitud abierta por usuario (evita doble pulsación y 100 envíos).
create unique index if not exists withdrawals_one_open_per_user
    on public.withdrawals (user_id)
    where status in ('pending', 'under_review', 'approved');

create or replace function public.request_withdrawal(
    p_amount numeric,
    p_payment_method text,
    p_payment_destination text
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
    v_currency text;
    v_withdrawal_id uuid;
    v_phone text := regexp_replace(coalesce(p_payment_destination, ''), '[^0-9]', '', 'g');
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    if not public.app_flag('withdrawals_enabled') then
        raise exception 'Withdrawals are not enabled yet';
    end if;

    if lower(trim(coalesce(p_payment_method, ''))) <> 'yape' then
        raise exception 'Only Yape withdrawals are accepted';
    end if;

    -- Celular peruano: 9 dígitos que empiezan con 9 (se acepta +51 delante).
    if length(v_phone) = 11 and left(v_phone, 2) = '51' then
        v_phone := substr(v_phone, 3);
    end if;
    if v_phone !~ '^9[0-9]{8}$' then
        raise exception 'Invalid Yape phone number';
    end if;

    if p_amount is null or p_amount < 5 then
        raise exception 'Minimum withdrawal is 5 PEN';
    end if;

    if p_amount <> round(p_amount, 2) then
        raise exception 'Withdrawal amount can have at most two decimals';
    end if;

    if not exists (
        select 1 from public.profiles
         where user_id = v_user_id
           and account_status = 'active'
           and country_code = 'PE'
    ) then
        raise exception 'Account is not eligible';
    end if;

    if not exists (
        select 1 from public.devices
         where user_id = v_user_id and device_status = 'active'
    ) then
        raise exception 'This installation is not active';
    end if;

    perform pg_advisory_xact_lock(hashtext('withdrawal:' || v_user_id::text)::bigint);

    if exists (
        select 1 from public.withdrawals
         where user_id = v_user_id
           and status in ('pending', 'under_review', 'approved')
    ) then
        raise exception 'You already have an open withdrawal';
    end if;

    if (select count(*) from public.withdrawals
         where user_id = v_user_id and requested_at > now() - interval '24 hours') >= 3 then
        raise exception 'Too many withdrawal requests today';
    end if;

    select currency into v_currency
      from public.wallets
     where user_id = v_user_id
     for update;

    if v_currency is null then
        raise exception 'Wallet not found';
    end if;

    update public.wallets
       set available_amount = available_amount - p_amount,
           locked_amount = locked_amount + p_amount,
           updated_at = now()
     where user_id = v_user_id
       and available_amount >= p_amount;

    if not found then
        raise exception 'Insufficient available balance';
    end if;

    insert into public.withdrawals (
        user_id, amount, currency, payment_method, payment_destination,
        status, requested_at, updated_at
    ) values (
        v_user_id, p_amount, v_currency, 'yape', v_phone, 'pending', now(), now()
    )
    returning id into v_withdrawal_id;

    insert into public.ledger_entries (
        user_id, entry_type, points_delta, cash_delta, cash_bucket, currency,
        provider, external_transaction_id, description, metadata
    ) values (
        v_user_id, 'withdrawal', 0, -p_amount, 'available', v_currency,
        'gana_geo', v_withdrawal_id::text, 'Retiro por Yape solicitado',
        jsonb_build_object('withdrawal_id', v_withdrawal_id, 'status', 'pending', 'payment_method', 'yape')
    );

    return v_withdrawal_id;
end;
$$;

revoke all on function public.request_withdrawal(numeric, text, text) from public, anon;
grant execute on function public.request_withdrawal(numeric, text, text) to authenticated;

-- Administración manual (solo service_role / SQL Editor). Nunca desde la app.
create or replace function public.admin_mark_withdrawal_paid(
    p_withdrawal_id uuid,
    p_yape_reference text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_w public.withdrawals%rowtype;
begin
    if p_yape_reference is null or length(trim(p_yape_reference)) < 4 then
        raise exception 'A verifiable Yape reference is required';
    end if;

    select * into v_w from public.withdrawals where id = p_withdrawal_id for update;
    if v_w.id is null then raise exception 'Withdrawal not found'; end if;
    if v_w.status = 'paid' then return; end if;
    if v_w.status not in ('pending', 'under_review', 'approved') then
        raise exception 'Withdrawal cannot be marked as paid from status %', v_w.status;
    end if;

    update public.wallets
       set locked_amount = locked_amount - v_w.amount, updated_at = now()
     where user_id = v_w.user_id and locked_amount >= v_w.amount;
    if not found then raise exception 'Wallet locked balance is inconsistent'; end if;

    update public.withdrawals
       set status = 'paid', payment_reference = trim(p_yape_reference),
           processed_at = now(), updated_at = now()
     where id = p_withdrawal_id;

    insert into public.ledger_entries (
        user_id, entry_type, points_delta, cash_delta, cash_bucket, currency,
        provider, external_transaction_id, description, metadata
    ) values (
        v_w.user_id, 'adjustment', 0, 0, 'locked', v_w.currency,
        'gana_geo_paid', p_withdrawal_id::text, 'Retiro pagado por Yape',
        jsonb_build_object('withdrawal_id', p_withdrawal_id, 'amount', v_w.amount)
    ) on conflict (provider, external_transaction_id) do nothing;
end;
$$;

create or replace function public.admin_reject_withdrawal(
    p_withdrawal_id uuid,
    p_reason text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_w public.withdrawals%rowtype;
begin
    select * into v_w from public.withdrawals where id = p_withdrawal_id for update;
    if v_w.id is null then raise exception 'Withdrawal not found'; end if;
    if v_w.status in ('rejected', 'cancelled') then return; end if;
    if v_w.status not in ('pending', 'under_review', 'approved') then
        raise exception 'Withdrawal cannot be rejected from status %', v_w.status;
    end if;

    update public.wallets
       set available_amount = available_amount + v_w.amount,
           locked_amount = locked_amount - v_w.amount,
           updated_at = now()
     where user_id = v_w.user_id and locked_amount >= v_w.amount;
    if not found then raise exception 'Wallet locked balance is inconsistent'; end if;

    update public.withdrawals
       set status = 'rejected', rejection_reason = left(coalesce(p_reason, 'Rechazado'), 300),
           processed_at = now(), updated_at = now()
     where id = p_withdrawal_id;

    insert into public.ledger_entries (
        user_id, entry_type, points_delta, cash_delta, cash_bucket, currency,
        provider, external_transaction_id, description, metadata
    ) values (
        v_w.user_id, 'reversal', 0, v_w.amount, 'available', v_w.currency,
        'gana_geo_reject', p_withdrawal_id::text, 'Retiro rechazado',
        jsonb_build_object('withdrawal_id', p_withdrawal_id)
    ) on conflict (provider, external_transaction_id) do nothing;
end;
$$;

revoke all on function public.admin_mark_withdrawal_paid(uuid, text) from public, anon, authenticated;
revoke all on function public.admin_reject_withdrawal(uuid, text) from public, anon, authenticated;
grant execute on function public.admin_mark_withdrawal_paid(uuid, text) to service_role;
grant execute on function public.admin_reject_withdrawal(uuid, text) to service_role;

-- =========================================================
-- 3. COMPRAS DE GOOGLE PLAY (las llama SOLO la Edge Function)
-- =========================================================
-- Idempotente: el mismo token repetido no vuelve a sumar créditos.
create or replace function public.grant_verified_tool_pack_v2(
    p_user_id uuid,
    p_purchase_token_hash text,
    p_product_id text,
    p_order_id text default null,
    p_raw_payload jsonb default '{}'::jsonb
)
returns table (credits_granted bigint, already_processed boolean)
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_credits bigint;
    v_existing public.play_purchase_claims%rowtype;
begin
    if not public.app_flag('purchases_enabled') then
        raise exception 'Purchases are not enabled yet';
    end if;

    v_credits := case p_product_id
        when 'pack_geo_50' then 50
        when 'pack_geo_100' then 100
        else null
    end;
    if v_credits is null then raise exception 'Unsupported product'; end if;
    if p_purchase_token_hash is null or length(p_purchase_token_hash) < 32 then
        raise exception 'Invalid purchase token';
    end if;

    perform pg_advisory_xact_lock(hashtext('purchase:' || p_purchase_token_hash)::bigint);

    select * into v_existing from public.play_purchase_claims
     where purchase_token_hash = p_purchase_token_hash
     for update;

    if v_existing.id is null and exists (
        select 1 from public.account_deletion_log d
         where p_purchase_token_hash = any (d.purchase_token_hashes)
    ) then
        raise exception 'Purchase token already processed';
    end if;

    if v_existing.id is not null then
        if v_existing.user_id <> p_user_id then
            raise exception 'Purchase token belongs to another account';
        end if;
        return query select v_existing.credits_granted, true;
        return;
    end if;

    insert into public.play_purchase_claims (
        user_id, product_id, purchase_token_hash, order_id, purchase_state,
        credits_granted, raw_payload, verified_at
    ) values (
        p_user_id, p_product_id, p_purchase_token_hash, p_order_id, 'verified',
        v_credits, coalesce(p_raw_payload, '{}'::jsonb), now()
    );

    insert into public.tool_credit_accounts (user_id, purchased_credits)
    values (p_user_id, v_credits)
    on conflict (user_id) do update
       set purchased_credits = public.tool_credit_accounts.purchased_credits + excluded.purchased_credits,
           updated_at = now();

    return query select v_credits, false;
end;
$$;

-- Reembolso o anulación informada por Google: retira los créditos que queden.
create or replace function public.revoke_refunded_tool_pack(
    p_purchase_token_hash text,
    p_reason text default 'refunded'
)
returns bigint
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_claim public.play_purchase_claims%rowtype;
    v_available bigint;
    v_take bigint;
begin
    select * into v_claim from public.play_purchase_claims
     where purchase_token_hash = p_purchase_token_hash
     for update;
    if v_claim.id is null then return 0; end if;
    if v_claim.purchase_state = 'refunded' then return 0; end if;

    select purchased_credits - reserved_purchased into v_available
      from public.tool_credit_accounts
     where user_id = v_claim.user_id
     for update;

    v_take := least(greatest(coalesce(v_available, 0), 0), v_claim.credits_granted);

    update public.tool_credit_accounts
       set purchased_credits = purchased_credits - v_take, updated_at = now()
     where user_id = v_claim.user_id;

    update public.play_purchase_claims
       set purchase_state = 'refunded',
           raw_payload = raw_payload || jsonb_build_object(
               'refund_reason', p_reason,
               'credits_removed', v_take,
               'credits_already_used', v_claim.credits_granted - v_take),
           updated_at = now()
     where id = v_claim.id;

    -- Si ya había usado parte de los créditos queda anotado en credits_already_used
    -- para revisión manual antes de aprobar cualquier retiro de esa cuenta.

    return v_take;
end;
$$;

revoke all on function public.grant_verified_tool_pack(uuid, text, text, text, jsonb) from public, anon, authenticated;
revoke all on function public.grant_verified_tool_pack_v2(uuid, text, text, text, jsonb) from public, anon, authenticated;
revoke all on function public.revoke_refunded_tool_pack(text, text) from public, anon, authenticated;
grant execute on function public.grant_verified_tool_pack_v2(uuid, text, text, text, jsonb) to service_role;
grant execute on function public.revoke_refunded_tool_pack(text, text) to service_role;

-- =========================================================
-- 4. ELIMINACIÓN DE CUENTA DESDE LA APP
--    Se guarda un registro mínimo sin datos personales (hash) por
--    obligaciones antifraude/reembolsos, como se explica en la política.
-- =========================================================
create table if not exists public.account_deletion_log (
    id uuid primary key default gen_random_uuid(),
    user_hash text not null,
    deleted_at timestamptz not null default now(),
    purchase_token_hashes text[] not null default '{}',
    summary jsonb not null default '{}'::jsonb
);

alter table public.account_deletion_log enable row level security;
revoke all on public.account_deletion_log from anon, authenticated;

create or replace function public.delete_my_account()
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
    v_user_id uuid := auth.uid();
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    if exists (
        select 1 from public.withdrawals
         where user_id = v_user_id
           and status in ('pending', 'under_review', 'approved')
    ) then
        raise exception 'Cancel your open withdrawal before deleting the account';
    end if;

    insert into public.account_deletion_log (user_hash, purchase_token_hashes, summary)
    select encode(extensions.digest(v_user_id::text, 'sha256'), 'hex'),
           coalesce((select array_agg(c.purchase_token_hash) from public.play_purchase_claims c
                      where c.user_id = v_user_id), '{}'),
           jsonb_build_object(
               'purchased_credits_left', (select purchased_credits from public.tool_credit_accounts where user_id = v_user_id),
               'reward_points', (select internal_points from public.wallets where user_id = v_user_id),
               'paid_withdrawals', (select count(*) from public.withdrawals where user_id = v_user_id and status = 'paid')
           );

    -- Borra la cuenta de acceso. Por ON DELETE CASCADE se borran perfil,
    -- billetera, créditos, juego, dispositivos y el celular queda libre.
    delete from auth.users where id = v_user_id;
end;
$$;

revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;

-- =========================================================
-- 5. QUITAR ENCUESTAS Y OFERTAS (tabla vacía, sin uso)
-- =========================================================
do $$
begin
    if to_regclass('public.provider_transactions') is not null
       and not exists (select 1 from public.provider_transactions) then
        execute 'drop table public.provider_transactions';
    end if;
end;
$$;

do $$
begin
    if not exists (
        select 1 from public.ledger_entries
         where entry_type in ('survey_reward', 'offer_reward', 'ad_points')
    ) then
        alter table public.ledger_entries drop constraint if exists ledger_entries_entry_type_check;
        alter table public.ledger_entries add constraint ledger_entries_entry_type_check check (
            entry_type in ('game_reward', 'referral_reward', 'purchase_points', 'tool_reward',
                           'withdrawal', 'reversal', 'adjustment')
        );
    end if;
end;
$$;

-- Multijugador ONLINE no se usa (el juego es solo y local por Wi-Fi).
-- Se eliminan piezas vacías que pudieran haber quedado de una instalación previa.
drop function if exists public.geo_mp_add_friend(text);
drop function if exists public.geo_mp_claim_local_unlock(integer);
drop function if exists public.geo_mp_find_player(text);
drop function if exists public.geo_mp_level_allowed(uuid, integer);
drop function if exists public.geo_mp_list_friends();
drop function if exists public.geo_mp_my_cosmetics();
drop function if exists public.geo_mp_my_unlocks();
drop function if exists public.geo_mp_register_profile(text);
drop function if exists public.geo_mp_skin_allowed(uuid, text);
do $$
declare t text;
begin
    foreach t in array array['geo_mp_invites','geo_mp_room_members','geo_mp_friends',
                             'geo_mp_rooms','geo_mp_level_unlocks','geo_mp_cosmetics','geo_mp_profiles']
    loop
        if to_regclass('public.' || t) is not null then
            execute format('drop table if exists public.%I', t);
        end if;
    end loop;
end;
$$;

-- =========================================================
-- 6. RENDIMIENTO
-- =========================================================
create index if not exists geo_game_runs_premium_life_idx
    on public.geo_game_runs (premium_life_id);

-- =========================================================
-- 7. CORRECCIÓN DE ERROR EN GEO AVENTURAS (sin cambiar reglas del juego)
--    activate_geo_game_run y finish_geo_game_run fallaban siempre con
--    "column reference ... is ambiguous" porque las columnas de salida tienen
--    el mismo nombre que columnas de la tabla. Se indica a PostgreSQL que use
--    la columna de la tabla. La lógica es idéntica a la anterior.
-- =========================================================
create or replace function public.activate_geo_game_run(
    p_run_id uuid,
    p_installation_hash text
)
returns table (awarded_points bigint, premium_lives_remaining bigint, premium_used_today integer)
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
    v_user_id uuid := auth.uid();
    v_run public.geo_game_runs%rowtype;
    v_life public.geo_game_premium_lives%rowtype;
    v_account public.tool_credit_accounts%rowtype;
    v_game_account public.geo_game_accounts%rowtype;
    v_combined_progress bigint;
    v_awarded bigint := 0;
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    perform public.assert_active_installation(v_user_id, p_installation_hash);
    perform public.refresh_geo_game_state(v_user_id);

    select * into v_run
      from public.geo_game_runs
     where id = p_run_id and user_id = v_user_id
     for update;

    if v_run.id is null then
        raise exception 'Game run not found';
    end if;

    if v_run.status in ('activated', 'won', 'lost') then
        return query
        select v_run.reward_points_awarded,
               (select count(*) from public.geo_game_premium_lives l
                 where l.user_id = v_user_id and l.status = 'available'),
               a.premium_used_today
          from public.geo_game_accounts a
         where a.user_id = v_user_id;
        return;
    end if;

    if v_run.life_type <> 'premium' or v_run.status <> 'started' then
        raise exception 'Game run cannot be activated';
    end if;

    if v_run.started_at > now() - interval '20 seconds' then
        raise exception 'Premium life activation is not ready';
    end if;

    select * into v_life
      from public.geo_game_premium_lives
     where id = v_run.premium_life_id and user_id = v_user_id
     for update;

    if v_life.id is null or v_life.status <> 'reserved' or v_life.reserved_run_id <> p_run_id then
        raise exception 'Premium life reservation is invalid';
    end if;

    select * into v_game_account
      from public.geo_game_accounts
     where user_id = v_user_id
     for update;

    if v_game_account.premium_used_today >= 10 then
        raise exception 'Daily premium life limit reached';
    end if;

    select * into v_account
      from public.tool_credit_accounts
     where user_id = v_user_id
     for update;

    v_combined_progress := v_account.reward_progress + v_life.purchased_credit_cost;
    v_awarded := (v_combined_progress / 10) * 50;

    update public.tool_credit_accounts
       set purchased_used_total = purchased_used_total + v_life.purchased_credit_cost,
           promo_used_total = promo_used_total + v_life.promo_credit_cost,
           reward_progress = v_combined_progress % 10,
           updated_at = now()
     where user_id = v_user_id;

    update public.geo_game_premium_lives
       set status = 'used', used_at = now()
     where id = v_life.id;

    update public.geo_game_accounts
       set premium_used_today = premium_used_today + 1,
           updated_at = now()
     where user_id = v_user_id;

    if v_awarded > 0 then
        insert into public.wallets (user_id, internal_points, currency)
        values (v_user_id, v_awarded, 'PEN')
        on conflict (user_id) do update
           set internal_points = public.wallets.internal_points + excluded.internal_points,
               updated_at = now();

        insert into public.ledger_entries (
            user_id, entry_type, points_delta, cash_delta, provider,
            external_transaction_id, description, metadata
        ) values (
            v_user_id, 'game_reward', v_awarded, 0, 'geo_adventures', p_run_id::text,
            'Geo Rewards por usar una vida premium',
            jsonb_build_object('level', v_run.level_no,
                               'purchased_credits_used', v_life.purchased_credit_cost,
                               'promo_credits_used', v_life.promo_credit_cost)
        ) on conflict (provider, external_transaction_id) do nothing;
    end if;

    update public.geo_game_runs
       set status = 'activated',
           reward_points_awarded = v_awarded,
           activated_at = now(),
           updated_at = now()
     where id = p_run_id;

    return query
    select v_awarded,
           (select count(*) from public.geo_game_premium_lives l
             where l.user_id = v_user_id and l.status = 'available'),
           a.premium_used_today
      from public.geo_game_accounts a
     where a.user_id = v_user_id;
end;
$$;

create or replace function public.finish_geo_game_run(
    p_run_id uuid,
    p_won boolean,
    p_stars integer,
    p_score bigint,
    p_time_ms bigint,
    p_installation_hash text
)
returns table (unlocked_level integer, total_stars bigint, best_score bigint)
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
    v_user_id uuid := auth.uid();
    v_run public.geo_game_runs%rowtype;
    v_stars integer := case when p_won then greatest(1, least(coalesce(p_stars, 1), 3)) else 0 end;
    v_score bigint := greatest(coalesce(p_score, 0), 0);
begin
    if v_user_id is null then
        raise exception 'Authentication required';
    end if;

    perform public.assert_active_installation(v_user_id, p_installation_hash);

    select * into v_run
      from public.geo_game_runs
     where id = p_run_id and user_id = v_user_id
     for update;

    if v_run.id is null then
        raise exception 'Game run not found';
    end if;

    if v_run.status in ('won', 'lost') then
        return query
        select a.unlocked_level,
               coalesce((select sum(p.best_stars) from public.geo_game_level_progress p
                          where p.user_id = v_user_id), 0),
               a.best_score
          from public.geo_game_accounts a
         where a.user_id = v_user_id;
        return;
    end if;

    if v_run.status <> 'activated' then
        raise exception 'Game run is not active';
    end if;

    update public.geo_game_runs
       set status = case when p_won then 'won' else 'lost' end,
           stars = v_stars,
           score = v_score,
           time_ms = greatest(coalesce(p_time_ms, 0), 0),
           finished_at = now(),
           updated_at = now()
     where id = p_run_id;

    if p_won then
        insert into public.geo_game_level_progress (
            user_id, level_no, best_stars, best_score, best_time_ms, completed_count
        ) values (
            v_user_id, v_run.level_no, v_stars, v_score, greatest(coalesce(p_time_ms, 0), 0), 1
        )
        on conflict (user_id, level_no) do update
           set best_stars = greatest(public.geo_game_level_progress.best_stars, excluded.best_stars),
               best_score = greatest(public.geo_game_level_progress.best_score, excluded.best_score),
               best_time_ms = case
                   when public.geo_game_level_progress.best_time_ms is null then excluded.best_time_ms
                   else least(public.geo_game_level_progress.best_time_ms, excluded.best_time_ms)
               end,
               completed_count = public.geo_game_level_progress.completed_count + 1,
               updated_at = now();

        update public.geo_game_accounts
           set unlocked_level = greatest(unlocked_level, least(v_run.level_no + 1, 20)),
               total_wins = total_wins + 1,
               best_score = greatest(best_score, v_score),
               updated_at = now()
         where user_id = v_user_id;
    else
        update public.geo_game_accounts
           set best_score = greatest(best_score, v_score),
               updated_at = now()
         where user_id = v_user_id;
    end if;

    return query
    select a.unlocked_level,
           coalesce((select sum(p.best_stars) from public.geo_game_level_progress p
                      where p.user_id = v_user_id), 0),
           a.best_score
      from public.geo_game_accounts a
     where a.user_id = v_user_id;
end;
$$;

revoke all on function public.activate_geo_game_run(uuid, text) from public, anon;
grant execute on function public.activate_geo_game_run(uuid, text) to authenticated;
revoke all on function public.finish_geo_game_run(uuid, boolean, integer, bigint, bigint, text) from public, anon;
grant execute on function public.finish_geo_game_run(uuid, boolean, integer, bigint, bigint, text) to authenticated;

commit;
