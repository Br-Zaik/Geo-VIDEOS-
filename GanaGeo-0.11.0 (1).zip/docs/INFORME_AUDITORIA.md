# Gana Geo — Informe de auditoría (etapas 4 a 8)

Fecha: noviembre de 2026. Base: el ZIP más reciente recibido y el servidor Supabase real del proyecto "Gana Geo" (revisado y modificado con autorización del dueño; el proyecto "Tesorería" no se tocó).

Estados: **CORRECTO / PARCIAL / FALTA / ERROR / NO VERIFICABLE**. "Corregido" indica lo hecho en esta entrega.

Limitación: en el entorno de trabajo no hay SDK de Android ni acceso a Internet para Gradle, por lo que **no se compiló ni se ejecutó la app**. La compilación se hace en GitHub Actions.

---

## Estado inicial del servidor (antes de cambios)

| ID | Componente | Estado | Evidencia | Riesgo | Corrección |
|---|---|---|---|---|---|
| S1 | Verificación de instalación | ERROR | `public.assert_active_installation` no existía; la llaman `begin_tool_operation_v2`, `complete_tool_operation`, `buy_geo_game_lives`, `start/activate/finish/cancel_geo_game_run`, `get_geo_game_status` | Herramientas de pago y juego con cuenta fallaban | Restaurada |
| S2 | Vidas rojas | PARCIAL | Servidor 0–3 diarias; app espera 5 y 1 cada 30 min (`GeoGameRules`) | Inconsistencia | Migración 07 aplicada |
| S3 | Historial de migraciones | NO VERIFICABLE | `supabase_migrations` vacío (SQL pegado a mano) | No se sabe qué se ejecutó | Verificado objeto por objeto |
| S4 | RLS | CORRECTO | 14 tablas con RLS; políticas solo SELECT propio; grants solo SELECT a `authenticated` | Bajo | — |
| S5 | Funciones SECURITY DEFINER | CORRECTO | `anon` no ejecuta ninguna salvo `rls_auto_enable` (trigger de evento de Supabase, no invocable útilmente) | Bajo | — |
| S6 | Datos | — | 1 usuario, saldos en cero, 0 compras/retiros/partidas | — | — |
| S7 | Activar vida dorada y terminar partida | ERROR → CORREGIDO | `activate_geo_game_run` y `finish_geo_game_run` fallaban SIEMPRE con "column reference is ambiguous" (columnas de salida con el mismo nombre que la tabla) | Vidas doradas no se podían usar ni se guardaba progreso con cuenta | Se agregó `#variable_conflict use_column`; lógica idéntica. Probado (T11, T12) |

---

## Etapa 4 — Geo Rewards, fidelidad y retiros solo Yape

| ID | Requisito | Estado | Evidencia | Corrección / prueba |
|---|---|---|---|---|
| 4A | Flujo completo compra→créditos→gasto→Rewards→canje→retiro | PARCIAL | Compra y canje no existían; gasto y Rewards sí (`complete_tool_operation`) | Compra preparada (Billing + Edge Function). Canje a soles **no existe** (seguro: nadie puede retirar) |
| 4B | Hitos acumulados sin doble premio | CORRECTO | `reward_progress` 0–9 con resto; 50 por cada 10 créditos comprados; `on conflict (provider, external_transaction_id) do nothing`; `request_id` único | Revisión de código y restricciones |
| 4B | No premiar operación fallida | CORRECTO | Solo `complete_tool_operation` premia; `cancel_tool_operation` devuelve créditos sin premio | — |
| 4C | Vidas → Rewards | PARCIAL (decisión del dueño) | `activate_geo_game_run`: Rewards a los 20 s, independiente de ganar; solo créditos comprados; máx. 10/día | **Se mantiene por decisión del dueño**. Riesgo documentado (ver capítulo especial) |
| 4D | Juego no falsificable | CORRECTO | Nivel ≤ desbloqueado, una partida activa, vidas en servidor, estrellas 0–3 | — |
| 4E | Normas de fidelización Google Play | PARCIAL | Proporción fija, no depende de suerte ni resultado; reglas publicadas en app (`LegalTexts`) y web (`docs/web`) | Aprobación de Google **no garantizada** |
| 4F | Cumplimiento legal Perú | PENDIENTE LEGAL | Ley 29733, Código del Consumidor, IGV/Renta, Libro de Reclamaciones | Ver GUIA paso 6 |
| 4G | Términos visibles | CORRECTO (nuevo) | Perfil > Legal y ayuda; invitado > ícono de información | — |
| 4H | Sostenibilidad S/10 → S/5 | PARCIAL | Estimación: S/10 − IGV 18% = S/8.47; − comisión Google 15% ≈ S/7.20; − Rewards máx. S/5 ≈ S/2.20 antes de renta, servidores y fraude | Confirmar con contador. No se cambió el porcentaje |
| 4I | Retiros inhabilitados hasta validar | CORRECTO (nuevo) | `app_settings.withdrawals_enabled = false`; `request_withdrawal` lo exige | Botón deshabilitado en la app |
| 4J | Solo Yape (UI + servidor + BD) | ERROR → CORREGIDO | Antes: Yape/Plin/PayPal en diálogo, función y CHECK | Diálogo solo Yape; función solo `yape`; disparador `withdrawals_yape_only`; históricos legibles |
| 4J | Validación número y mínimo | FALTA → CORREGIDO | — | Servidor y app: 9 dígitos que empiezan con 9 (+51 aceptado), mínimo S/5, 2 decimales |
| 4K | Flujo manual | FALTA → CORREGIDO | — | `admin_mark_withdrawal_paid` exige referencia Yape; `admin_reject_withdrawal` devuelve una vez |
| 4K | Doble solicitud | FALTA → CORREGIDO | — | Índice único de una solicitud abierta + candado + máx. 3/día |
| 4L | Yape no es pasarela de compra | CORRECTO | Compras solo con Google Play Billing | — |
| 4M | Riesgo 50% de devolución | PARCIAL | Documentado en PLAN_PRIORIDADES | Decisión del dueño |
| 4X | Retiro desde la app | ERROR → CORREGIDO | La app enviaba `p_installation_hash` a `request_withdrawal`/`cancel_my_withdrawal`, que no lo aceptan (PGRST202) | Parámetro quitado |

## Etapa 5 — Google Play Billing

| ID | Requisito | Estado | Evidencia | Corrección |
|---|---|---|---|---|
| 5A | Integración Billing | FALTA → CORREGIDO | No había dependencia ni BillingClient | `PlayBillingManager` (Billing 8.3.0, productos `pack_geo_50`, `pack_geo_100`, compras pendientes habilitadas, reconexión automática) |
| 5B | Validación real en servidor | FALTA → CORREGIDO (pendiente credenciales) | — | Edge Function `verify-play-purchase`: usuario de Supabase, API `purchases.products.get`, `purchaseState = 0`, cuenta ofuscada = hash del usuario, token con hash único, acreditación atómica `grant_verified_tool_pack_v2` |
| 5B | No acreditar PENDING | CORRECTO (nuevo) | App y servidor | — |
| 5B | No usar orderId como control | CORRECTO | Clave única por hash del token | — |
| 5B | Consumir después de acreditar | CORRECTO (nuevo) | `verifyAndConsume` consume solo tras OK | — |
| 5C | Reembolsos / anulaciones | FALTA → CORREGIDO (pendiente Pub/Sub) | — | `play-rtdn` + `revoke_refunded_tool_pack` |
| 5C | Reintentos sin duplicar | CORRECTO (nuevo) | `queryPurchasesAsync` al cargar cuenta; servidor idempotente (`already_processed`) | — |
| 5C | Token de cuenta borrada reutilizado | CORRECTO (nuevo) | `account_deletion_log.purchase_token_hashes` | — |
| 5D | Credenciales fuera del APK | CORRECTO | Solo secretos de Supabase/GitHub | — |
| 5E | Compras de prueba | PREPARADO | `ALLOW_TEST_PURCHASES` solo en pruebas | GUIA paso 3 |
| 5F | Sin Yape para comprar | CORRECTO | — | — |

## Etapa 6 — Seguridad

| ID | Requisito | Estado | Evidencia |
|---|---|---|---|
| 6.1 | RLS / A no ve a B | CORRECTO | Políticas `auth.uid() = user_id`, solo SELECT |
| 6.1 | Sin INSERT/UPDATE/DELETE del cliente | CORRECTO | Grants solo SELECT; todo por RPC |
| 6.1 | Saldos negativos | CORRECTO | CHECK ≥ 0 en billetera y créditos; reservas ≤ saldo |
| 6.1 | Concurrencia | CORRECTO | `pg_advisory_xact_lock`, `for update`, `request_id` únicos |
| 6.1 | Secretos | CORRECTO | No hay service_role ni claves en el ZIP |
| 6.1 | Storage | CORRECTO | No hay buckets |
| 6.2 | Rate limits | PARCIAL | Retiros: 3/día; compras: idempotentes; Auth: límites por defecto de Supabase. Falta límite por IP en Edge Functions |
| 6.3 | APK | PARCIAL | `allowBackup=false`, sin HTTP claro, FileProvider no exportado. R8 apagado (pendiente probar). Deep link `ganageo://geo-room` exportado (solo abre la app) |
| 6.3 | Play Integrity | FALTA | Recomendado antes de activar retiros |
| 6.3 | Saldo local | CORRECTO | Caché de solo lectura; el servidor decide |
| 6.4 | Pruebas concretas | CORRECTO | 35 pruebas A/B/anónimo ejecutadas en el servidor real, todas OK (MATRIZ_PRUEBAS.txt) |

## Etapa 7 — Play Console y publicación

| ID | Requisito | Estado | Nota |
|---|---|---|---|
| 7A | En la app: privacidad, términos, reglas, soporte, eliminar cuenta | CORRECTO (nuevo) | Perfil > Legal y ayuda |
| 7B | Recursos web públicos | PREPARADO | `docs/web/*.html` (falta publicarlos y poner correo) |
| 7C | Ficha, país Perú, precios PEN, formularios | PENDIENTE EXTERNO | GUIA pasos 2 y 5 |
| 7 | Eliminación real de cuenta | CORRECTO (pendiente aplicar SQL) | Borra cuenta y datos en cascada; conserva hash mínimo |
| 7 | Permisos | ERROR (riesgo) | `READ_MEDIA_IMAGES` para galería interna de una herramienta: Google lo restringe. No se modificó la herramienta; ver PLAN punto 2 |
| 7 | targetSdk / AAB | PARCIAL | targetSdk 36; flujo AAB firmado añadido |
| 7 | Prueba cerrada 12 personas / 14 días | NO VERIFICABLE | Depende del tipo y fecha de la cuenta |

## Etapa 8 — Herramientas y optimización

**Inventario real:** 48 elementos = 47 herramientas + Geo Aventuras. **13 de pago** (Escáner, Editor de documentos, Marca/numera/protege PDF, Imágenes a PDF, PDF a imágenes, Firmar PDF, Estudio de imágenes por lote, Comprimir, Cambiar tamaño, Convertir formato, Recortar/girar, Texto y marca de agua: 5 créditos; Organizar PDF: 10). **35 gratis** (matemática, visores, ciencia, estudio, trabajo, rápidas y el juego). Precios app = servidor (`begin_tool_operation_v2`).

| ID | Tema | Estado | Corrección |
|---|---|---|---|
| 8A | Inventario | CORRECTO | Arriba |
| 8B/C | Calidad premium | NO VERIFICABLE | Sin dispositivo; mejoras propuestas en PLAN nivel 3 |
| 8E | Lista de herramientas | CORRECTO + mejorado | Lista perezosa; imágenes 640×360 ahora en RGB_565, fuera del hilo principal, caché 10 MB |
| 8E | Carga de cuenta | Mejorado | 6 consultas en paralelo; historial con orden y límite en el servidor |
| 8F | UX | Mejorado | 4 pestañas sin repetidos; recientes; agrupado por categoría; precio visible antes de pagar |
| 8G | Pruebas | Ver MATRIZ |

---

## Capítulo especial — Geo Aventuras, vidas, Rewards y retiros solo Yape

- **Juego intacto**: 20 niveles, Solo y Multijugador local (Wi-Fi/zona Wi-Fi). El multijugador online no se usa y no aparece en la app.
- **Vidas rojas**: 5, una cada 30 minutos (servidor igualado a la app).
- **Vidas doradas**: 1 = 2 créditos; paquetes 1/5/15 vidas = 2/10/30 créditos; máximo **10 por día**.
- **Rewards del juego (decisión del dueño, se mantiene)**: se suman al usar la vida dorada tras 20 s, **ganes o pierdas**, misma proporción que herramientas (10 créditos comprados = 50 Rewards; 10 vidas = 100 Rewards ≈ S/1 previsto). Créditos promocionales no suman.
- **Análisis de política**: Google Play prohíbe aceptar dinero (o artículos comprados) a cambio de la oportunidad de ganar un premio con valor real, y en juegos el beneficio de fidelidad no puede depender del rendimiento ni del azar. El diseño actual no depende de ganar ni del azar (a favor), pero el premio se entrega por jugar (riesgo). Alternativa si Google lo observa: sumar las Rewards al comprar la vida, sin tocar el juego.
- **Retiros**: solo Yape, manual, bloqueados por interruptor hasta revisión legal.
