package com.ganageo.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class YapeRulesTest {
    @Test
    fun acceptsPeruvianMobileNumbers() {
        assertTrue(YapeRules.isValidPhone("987654321"))
        assertTrue(YapeRules.isValidPhone("987 654 321"))
        assertTrue(YapeRules.isValidPhone("+51 987654321"))
    }

    @Test
    fun rejectsInvalidNumbers() {
        assertFalse(YapeRules.isValidPhone(""))
        assertFalse(YapeRules.isValidPhone("12345"))
        assertFalse(YapeRules.isValidPhone("887654321"))
        assertFalse(YapeRules.isValidPhone("9876543210"))
        assertFalse(YapeRules.isValidPhone("correo@paypal.com"))
    }

    @Test
    fun amountRules() {
        assertTrue(YapeRules.isValidAmount(5.0, 10.0))
        assertTrue(YapeRules.isValidAmount(7.5, 10.0))
        assertFalse(YapeRules.isValidAmount(4.99, 10.0))
        assertFalse(YapeRules.isValidAmount(11.0, 10.0))
        assertFalse(YapeRules.isValidAmount(null, 10.0))
        assertFalse(YapeRules.isValidAmount(5.555, 10.0))
    }

    @Test
    fun accountHashIsStableSha256() {
        assertEquals(
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
            PlayBillingManager.accountHash("abc")
        )
    }
}
