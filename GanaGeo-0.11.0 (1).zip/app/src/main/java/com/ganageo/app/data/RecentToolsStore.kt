package com.ganageo.app.data

import android.content.Context

/**
 * Últimas herramientas abiertas en este dispositivo (solo para accesos rápidos).
 * No guarda archivos ni datos de las herramientas, únicamente sus nombres internos.
 */
class RecentToolsStore(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    fun read(): List<String> = runCatching {
        preferences.getString(KEY_RECENTS, null)
            ?.split(SEPARATOR)
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() }
            ?.distinct()
            ?.take(MAX_RECENTS)
            .orEmpty()
    }.getOrDefault(emptyList())

    fun push(toolName: String): List<String> {
        val clean = toolName.trim()
        if (clean.isEmpty()) return read()
        val updated = (listOf(clean) + read().filterNot { it == clean }).take(MAX_RECENTS)
        runCatching {
            preferences.edit().putString(KEY_RECENTS, updated.joinToString(SEPARATOR)).apply()
        }
        return updated
    }

    fun clear() {
        runCatching { preferences.edit().remove(KEY_RECENTS).apply() }
    }

    private companion object {
        const val PREFS_NAME = "gana_geo_recent_tools"
        const val KEY_RECENTS = "recent_tool_names"
        const val SEPARATOR = ","
        const val MAX_RECENTS = 6
    }
}
