package com.ganageo.app.ui.tools

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint as AndroidPaint
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.NavigateBefore
import androidx.compose.material.icons.rounded.NavigateNext
import androidx.compose.material.icons.rounded.OpenInFull
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.ganageo.app.GanaGeoViewModel
import com.ganageo.app.model.ToolId
import com.ganageo.app.tools.DocumentImageFilter
import com.ganageo.app.tools.ImagesToPdfOptions
import com.ganageo.app.tools.PageSelectionParser
import com.ganageo.app.tools.PdfCompression
import com.ganageo.app.tools.PdfImageFit
import com.ganageo.app.tools.PdfImagePage
import com.ganageo.app.tools.PdfMargin
import com.ganageo.app.tools.PdfOrientation
import com.ganageo.app.tools.PdfPaperSize
import com.ganageo.app.tools.SignaturePlacement
import com.ganageo.app.tools.SignaturePosition
import com.ganageo.app.tools.ToolFileUtils
import com.ganageo.app.ui.theme.CardGreen
import com.ganageo.app.ui.theme.DeepGreen
import com.ganageo.app.ui.theme.Gold
import com.ganageo.app.ui.theme.NeonGreen
import kotlinx.coroutines.launch

@Composable
fun ImagesToPdfScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val pages = remember { mutableStateListOf<PdfImagePage>() }
    var selectedPageIndex by rememberSaveable { mutableStateOf(0) }
    var applyToAll by rememberSaveable { mutableStateOf(true) }
    var showFullPreview by rememberSaveable { mutableStateOf(false) }
    var showPdfSettings by rememberSaveable { mutableStateOf(false) }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    var paperIndex by rememberSaveable { mutableStateOf(PdfPaperSize.A4.ordinal) }
    var orientationIndex by rememberSaveable { mutableStateOf(PdfOrientation.AUTOMATIC.ordinal) }
    var marginIndex by rememberSaveable { mutableStateOf(PdfMargin.NORMAL.ordinal) }
    var compressionIndex by rememberSaveable { mutableStateOf(PdfCompression.NORMAL.ordinal) }
    var fitIndex by rememberSaveable { mutableStateOf(PdfImageFit.CONTAIN.ordinal) }
    var passwordEnabled by rememberSaveable { mutableStateOf(false) }
    var password by rememberSaveable { mutableStateOf("") }
    var outputName by rememberSaveable { mutableStateOf("documento_gana_geo.pdf") }
    var processing by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }

    fun persistReadPermission(uri: Uri) {
        runCatching {
            context.contentResolver.takePersistableUriPermission(
                uri,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
    }

    fun appendImages(selected: List<Uri>, persistPermission: Boolean) {
        val available = (ToolFileUtils.MAX_IMAGES_PER_PDF - pages.size).coerceAtLeast(0)
        val accepted = selected.take(available)
        if (persistPermission) accepted.forEach(::persistReadPermission)
        val firstNewIndex = pages.size
        pages.addAll(accepted.map(::PdfImagePage))
        if (accepted.isNotEmpty()) selectedPageIndex = firstNewIndex.coerceAtMost(pages.lastIndex)
        if (selected.size > available) onMessage("Solo se permiten ${ToolFileUtils.MAX_IMAGES_PER_PDF} imágenes por PDF.")
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(ToolFileUtils.MAX_IMAGES_PER_PDF)
    ) { selected -> appendImages(selected, persistPermission = false) }

    val filesLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { selected ->
        appendImages(selected, persistPermission = true)
    }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val uri = pendingCameraUri
        if (success && uri != null && pages.size < ToolFileUtils.MAX_IMAGES_PER_PDF) {
            pages.add(PdfImagePage(uri))
            selectedPageIndex = pages.lastIndex
        }
        pendingCameraUri = null
    }

    fun launchCameraCapture() {
        runCatching { ToolFileUtils.createCameraImageUri(context) }
            .onSuccess { pendingCameraUri = it; cameraLauncher.launch(it) }
            .onFailure { onMessage(it.message ?: "No se pudo abrir la cámara.") }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchCameraCapture() else onMessage("Se necesita permiso de cámara para tomar una foto.")
    }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        if (output == null || pages.isEmpty()) return@rememberLauncherForActivityResult
        val options = ImagesToPdfOptions(
            paperSize = PdfPaperSize.entries[paperIndex],
            orientation = PdfOrientation.entries[orientationIndex],
            margin = PdfMargin.entries[marginIndex],
            compression = PdfCompression.entries[compressionIndex],
            fit = PdfImageFit.entries[fitIndex],
            password = password.takeIf { passwordEnabled }
        )
        processing = true
        progress = 0f
        scope.launch {
            runPaidTool(viewModel, tool) {
                ToolFileUtils.createPdfFromImages(
                    context = context,
                    pages = pages.toList(),
                    output = output,
                    options = options,
                    onProgress = { completed, total ->
                        scope.launch { progress = completed.toFloat() / total.coerceAtLeast(1) }
                    }
                )
            }.onSuccess { onMessage(successMessage("PDF creado con ${pages.size} páginas.", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo crear el PDF.") }
            processing = false
        }
    }

    fun updateSelected(transform: (PdfImagePage) -> PdfImagePage) {
        if (pages.isEmpty()) return
        if (applyToAll) {
            pages.indices.forEach { index -> pages[index] = transform(pages[index]) }
        } else {
            val index = selectedPageIndex.coerceIn(0, pages.lastIndex)
            pages[index] = transform(pages[index])
        }
    }

    val totalInputBytes = pages.sumOf { ToolFileUtils.fileSize(context, it.uri) }
    val selectedPage = pages.getOrNull(selectedPageIndex)

    if (showFullPreview && selectedPage != null) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showFullPreview = false },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(Modifier.fillMaxSize().background(Color.Black)) {
                AdjustedUriImage(
                    uri = selectedPage.uri,
                    rotation = selectedPage.rotationDegrees,
                    filter = selectedPage.filter,
                    brightness = selectedPage.brightness,
                    contrast = selectedPage.contrast,
                    modifier = Modifier.fillMaxSize().padding(top = 62.dp, bottom = 28.dp, start = 12.dp, end = 12.dp)
                )
                Row(
                    modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(
                            onClick = { if (selectedPageIndex > 0) selectedPageIndex-- },
                            enabled = selectedPageIndex > 0,
                            modifier = Modifier.background(Color.Black.copy(alpha = 0.55f), CircleShape)
                        ) {
                            Icon(Icons.Rounded.NavigateBefore, contentDescription = "Imagen anterior", tint = Color.White)
                        }
                        Text(
                            "Página ${selectedPageIndex + 1} de ${pages.size}",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.background(Color.Black.copy(alpha = 0.35f), RoundedCornerShape(16.dp)).padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                        IconButton(
                            onClick = { if (selectedPageIndex < pages.lastIndex) selectedPageIndex++ },
                            enabled = selectedPageIndex < pages.lastIndex,
                            modifier = Modifier.background(Color.Black.copy(alpha = 0.55f), CircleShape)
                        ) {
                            Icon(Icons.Rounded.NavigateNext, contentDescription = "Imagen siguiente", tint = Color.White)
                        }
                    }
                    IconButton(
                        onClick = { showFullPreview = false },
                        modifier = Modifier.background(Color.Black.copy(alpha = 0.55f), CircleShape)
                    ) {
                        Icon(Icons.Rounded.Close, contentDescription = "Cerrar vista completa", tint = Color.White)
                    }
                }
                Text(
                    "Desliza por las miniaturas abajo o usa las flechas para cambiar de página.",
                    color = Color.White.copy(alpha = 0.88f),
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    }

    if (showPdfSettings) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showPdfSettings = false }) {
            Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(22.dp)) {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { Text("Configuración del PDF", style = MaterialTheme.typography.titleLarge) }
                    item { SimpleDropdown("Tamaño de papel", PdfPaperSize.entries.map { it.label }, paperIndex) { paperIndex = it } }
                    item { SimpleDropdown("Orientación", PdfOrientation.entries.map { it.label }, orientationIndex) { orientationIndex = it } }
                    item { SimpleDropdown("Márgenes", PdfMargin.entries.map { it.label }, marginIndex) { marginIndex = it } }
                    item { SimpleDropdown("Ajuste de imagen", PdfImageFit.entries.map { it.label }, fitIndex) { fitIndex = it } }
                    item { SimpleDropdown("Compresión", PdfCompression.entries.map { "${it.label} · ${it.detail}" }, compressionIndex) { compressionIndex = it } }
                    item {
                        OutlinedTextField(
                            value = outputName,
                            onValueChange = { value -> outputName = value.replace(Regex("[\\/:*?\"<>|]"), "_").take(80) },
                            label = { Text("Nombre del PDF") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = passwordEnabled, onCheckedChange = { passwordEnabled = it })
                            Icon(Icons.Rounded.Lock, contentDescription = null, tint = Gold)
                            Spacer(Modifier.width(7.dp))
                            Text("Proteger con contraseña")
                        }
                    }
                    if (passwordEnabled) {
                        item {
                            OutlinedTextField(
                                value = password,
                                onValueChange = { password = it.take(40) },
                                label = { Text("Contraseña (mínimo 4 caracteres)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { showPdfSettings = false }, modifier = Modifier.weight(1f)) {
                                Text("Cerrar")
                            }
                            Button(
                                onClick = {
                                    if (passwordEnabled && password.length < 4) onMessage("La contraseña debe tener por lo menos 4 caracteres.")
                                    else {
                                        showPdfSettings = false
                                        launchPaidExport(viewModel, tool, onMessage) {
                                            val normalizedName = outputName.trim().ifBlank { "documento_gana_geo.pdf" }
                                            saveLauncher.launch(if (normalizedName.endsWith(".pdf", true)) normalizedName else "$normalizedName.pdf")
                                        }
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
                            ) {
                                Icon(Icons.Rounded.PictureAsPdf, contentDescription = null)
                                Text(" Crear PDF")
                            }
                        }
                    }
                }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        ToolHeader(tool.title, "Costo por exportación: ${tool.creditCost} créditos", onBack)

        Card(
            colors = CardDefaults.cardColors(containerColor = CardGreen),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (pages.isEmpty()) "Agrega imágenes para comenzar" else "${pages.size} páginas · ${ToolFileUtils.readableSize(totalInputBytes)}",
                    fontWeight = FontWeight.Bold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        modifier = Modifier.weight(1f),
                        enabled = !processing
                    ) {
                        Icon(Icons.Rounded.PhotoLibrary, contentDescription = null)
                        Text(" Galería")
                    }
                    OutlinedButton(
                        onClick = { filesLauncher.launch(arrayOf("image/*")) },
                        modifier = Modifier.weight(1f),
                        enabled = !processing
                    ) {
                        Icon(Icons.Rounded.Folder, contentDescription = null)
                        Text(" Archivos")
                    }
                    OutlinedButton(
                        onClick = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) launchCameraCapture()
                            else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                        },
                        enabled = !processing
                    ) {
                        Icon(Icons.Rounded.AddAPhoto, contentDescription = null)
                    }
                }
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxSize()) {
                if (selectedPage != null) {
                    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                if (applyToAll) "Vista previa · editando todas" else "Vista previa · página ${selectedPageIndex + 1}",
                                color = NeonGreen,
                                fontWeight = FontWeight.Bold
                            )
                            FilledTonalButton(onClick = { showFullPreview = true }) {
                                Icon(Icons.Rounded.OpenInFull, contentDescription = null)
                                Text(" Pantalla completa")
                            }
                        }
                        Text(
                            "Toca la imagen para verla grande. Usa las miniaturas para cambiar rápidamente.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.76f)
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.12f), RoundedCornerShape(18.dp))
                                .clickable { showFullPreview = true }
                        ) {
                            AdjustedUriImage(
                                uri = selectedPage.uri,
                                rotation = selectedPage.rotationDegrees,
                                filter = selectedPage.filter,
                                brightness = selectedPage.brightness,
                                contrast = selectedPage.contrast,
                                modifier = Modifier.fillMaxSize().padding(8.dp)
                            )
                        }
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            itemsIndexed(pages, key = { index, item -> "${item.uri}-$index" }) { index, item ->
                                PdfImageThumbnailCard(
                                    page = item,
                                    pageNumber = index + 1,
                                    selected = index == selectedPageIndex,
                                    onSelect = { selectedPageIndex = index }
                                )
                            }
                        }
                    }
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Aquí verás la imagen completa.\nAbre desde Galería, Archivos o Cámara.", textAlign = TextAlign.Center)
                    }
                }
            }
        }

        selectedPage?.let { page ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CardGreen),
                shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(
                            onClick = { applyToAll = false },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = if (!applyToAll) NeonGreen else Color.White.copy(alpha = 0.08f),
                                contentColor = if (!applyToAll) DeepGreen else Color.White
                            )
                        ) { Text("Esta imagen") }
                        FilledTonalButton(
                            onClick = { applyToAll = true },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = if (applyToAll) NeonGreen else Color.White.copy(alpha = 0.08f),
                                contentColor = if (applyToAll) DeepGreen else Color.White
                            )
                        ) { Text("Aplicar a todas") }
                    }

                    SimpleDropdown("Filtro", DocumentImageFilter.entries.map { it.label }, page.filter.ordinal) {
                        selected -> updateSelected { it.copy(filter = DocumentImageFilter.entries[selected], useCustomAdjustments = true) }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Brillo ${if (page.brightness >= 0) "+" else ""}${page.brightness}", modifier = Modifier.width(102.dp), fontWeight = FontWeight.Bold)
                        Slider(
                            value = page.brightness.toFloat(),
                            onValueChange = { value -> updateSelected { it.copy(brightness = value.toInt(), useCustomAdjustments = true) } },
                            valueRange = -50f..50f,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Contraste ${String.format("%.2f", page.contrast)}", modifier = Modifier.width(102.dp), fontWeight = FontWeight.Bold)
                        Slider(
                            value = page.contrast,
                            onValueChange = { value -> updateSelected { it.copy(contrast = value, useCustomAdjustments = true) } },
                            valueRange = 0.7f..1.5f,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { updateSelected { it.copy(filter = DocumentImageFilter.ORIGINAL, brightness = 0, contrast = 1f, useCustomAdjustments = true) } },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = null)
                            Text(" Restablecer")
                        }
                        OutlinedButton(onClick = { showPdfSettings = true }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Rounded.Save, contentDescription = null)
                            Text(" PDF")
                        }
                    }

                    Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            IconButton(
                                onClick = {
                                    if (selectedPageIndex > 0) {
                                        val item = pages.removeAt(selectedPageIndex)
                                        pages.add(selectedPageIndex - 1, item)
                                        selectedPageIndex--
                                    }
                                },
                                enabled = selectedPageIndex > 0
                            ) { Icon(Icons.Rounded.ArrowUpward, contentDescription = "Mover antes") }
                            IconButton(
                                onClick = {
                                    if (selectedPageIndex < pages.lastIndex) {
                                        val item = pages.removeAt(selectedPageIndex)
                                        pages.add(selectedPageIndex + 1, item)
                                        selectedPageIndex++
                                    }
                                },
                                enabled = selectedPageIndex < pages.lastIndex
                            ) { Icon(Icons.Rounded.ArrowDownward, contentDescription = "Mover después") }
                            IconButton(onClick = { pages[selectedPageIndex] = page.copy(rotationDegrees = (page.rotationDegrees + 90) % 360) }) {
                                Icon(Icons.Rounded.RotateRight, contentDescription = "Girar")
                            }
                            IconButton(onClick = {
                                pages.removeAt(selectedPageIndex)
                                selectedPageIndex = selectedPageIndex.coerceAtMost((pages.lastIndex).coerceAtLeast(0))
                            }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Eliminar", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                        OutlinedButton(onClick = { pages.clear(); selectedPageIndex = 0 }, enabled = !processing) {
                            Text("Quitar todas")
                        }
                    }
                    if (processing) ProcessingCard("Creando PDF", progress)
                }
            }
        }
    }
}

@Composable
fun PdfToImagesScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf<Uri?>(null) }
    var pageCount by remember { mutableStateOf(0) }
    var formatIndex by rememberSaveable { mutableStateOf(0) }
    var pagesText by rememberSaveable { mutableStateOf("") }
    var quality by rememberSaveable { mutableStateOf(90f) }
    var resolutionIndex by rememberSaveable { mutableStateOf(1) }
    var prefix by rememberSaveable { mutableStateOf("pagina") }
    var processing by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    val formats = listOf("JPG", "PNG")
    val widths = listOf(1200, 1800, 2400)
    val resolutionLabels = listOf("Ligera · 1200 px", "Normal · 1800 px", "Alta · 2400 px")

    val inputLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        input = uri
        pageCount = 0
        if (uri != null) scope.launch {
            runCatching { ToolFileUtils.pdfPageCount(context, uri) }
                .onSuccess { pageCount = it }
                .onFailure { onMessage(it.message ?: "No se pudo abrir el PDF.") }
        }
    }
    val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        val source = input
        if (tree == null || source == null) return@rememberLauncherForActivityResult
        val selected = runCatching { PageSelectionParser.parse(pagesText, pageCount.takeIf { it > 0 }) }
            .getOrElse {
                onMessage(it.message ?: "Revisa las páginas indicadas.")
                return@rememberLauncherForActivityResult
            }
        processing = true
        progress = 0f
        scope.launch {
            runPaidTool(viewModel, tool) {
                ToolFileUtils.pdfToImages(
                    context = context,
                    input = source,
                    outputTree = tree,
                    format = if (formats[formatIndex] == "PNG") Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG,
                    quality = quality.toInt(),
                    selectedPages = selected,
                    maxWidth = widths[resolutionIndex],
                    filePrefix = prefix,
                    onProgress = { completed, total ->
                        scope.launch { progress = completed.toFloat() / total.coerceAtLeast(1) }
                    }
                )
            }.onSuccess { onMessage(successMessage("Páginas exportadas en la carpeta seleccionada.", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo convertir el PDF.") }
            processing = false
        }
    }

    ToolPage(tool, onBack) {
        FileSelectionCard(
            "PDF seleccionado",
            input?.let {
                "${ToolFileUtils.displayName(context, it)} · ${pageCount.takeIf { it > 0 } ?: "…"} páginas · ${ToolFileUtils.readableSize(ToolFileUtils.fileSize(context, it))}"
            } ?: "Selecciona un archivo PDF.",
            "Elegir PDF"
        ) { inputLauncher.launch(arrayOf("application/pdf")) }
        input?.let { PdfFirstPagePreview(it) }
        SettingSection("Opciones de exportación") {
            SimpleDropdown("Formato", formats, formatIndex) { formatIndex = it }
            SimpleDropdown("Resolución", resolutionLabels, resolutionIndex) { resolutionIndex = it }
            if (formatIndex == 0) {
                Text("Calidad JPG: ${quality.toInt()} %")
                Slider(value = quality, onValueChange = { quality = it }, valueRange = 45f..100f)
            }
            OutlinedTextField(
                value = pagesText,
                onValueChange = { pagesText = sanitizePageInput(it) },
                label = { Text("Páginas (vacío = todas)") },
                supportingText = { Text("Ejemplo: 1-3, 7, 10") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = prefix,
                onValueChange = { prefix = it.replace(Regex("[^A-Za-z0-9_-]"), "_").take(30) },
                label = { Text("Prefijo de archivos") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }
        if (processing) ProcessingCard("Exportando páginas", progress)
        Button(
            onClick = {
                runCatching { PageSelectionParser.parse(pagesText, pageCount.takeIf { it > 0 }) }
                    .onSuccess { launchPaidExport(viewModel, tool, onMessage) { folderLauncher.launch(null) } }
                    .onFailure { onMessage(it.message ?: "Revisa las páginas indicadas.") }
            },
            enabled = input != null && !processing,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
        ) {
            Icon(Icons.Rounded.PictureAsPdf, contentDescription = null)
            Text(" Elegir carpeta y convertir · ${tool.creditCost} créditos")
        }
        InfoToolText("Cada página se guarda con su número original. El PDF no se modifica.")
    }
}

@Composable
fun PdfOrganizerScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val modes = listOf(
        "Unir PDF",
        "Reordenar o extraer",
        "Eliminar páginas",
        "Girar páginas",
        "Invertir orden",
        "Dividir en varios PDF",
        "Comprimir PDF"
    )
    var modeIndex by rememberSaveable { mutableStateOf(0) }
    val inputs = remember { mutableStateListOf<Uri>() }
    var pageCount by remember { mutableStateOf(0) }
    var pagesText by rememberSaveable { mutableStateOf("") }
    val visualOrder = remember { mutableStateListOf<Int>() }
    val selectedPages = remember { mutableStateListOf<Int>() }
    var rotationIndex by rememberSaveable { mutableStateOf(0) }
    var splitBaseName by rememberSaveable { mutableStateOf("parte") }
    var compressionIndex by rememberSaveable { mutableStateOf(1) }
    var processing by remember { mutableStateOf(false) }
    val compressionLabels = listOf("Máxima · archivo pequeño", "Media · recomendada", "Normal · más detalle", "Baja · calidad alta")
    val compressionWidths = listOf(900, 1300, 1800, 2400)

    fun updateSingle(uri: Uri?) {
        inputs.clear()
        pageCount = 0
        if (uri != null) {
            inputs.add(uri)
            scope.launch {
                runCatching { ToolFileUtils.pdfPageCount(context, uri) }
                    .onSuccess { count ->
                        pageCount = count
                        visualOrder.clear()
                        visualOrder.addAll(1..count)
                        selectedPages.clear()
                        pagesText = if (modeIndex == 1) visualOrder.joinToString(",") else ""
                    }
                    .onFailure { onMessage(it.message ?: "No se pudo abrir el PDF.") }
            }
        }
    }

    val multiLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { selected ->
        inputs.clear()
        inputs.addAll(selected.take(20))
    }
    val singleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument(), ::updateSingle)
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        if (output == null || inputs.isEmpty()) return@rememberLauncherForActivityResult
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                when (modeIndex) {
                    0 -> ToolFileUtils.mergePdfs(context, inputs.toList(), output)
                    1 -> ToolFileUtils.organizePdf(
                        context,
                        inputs.first(),
                        output,
                        PageSelectionParser.parse(pagesText, pageCount)
                    )
                    2 -> {
                        val removed = PageSelectionParser.parse(pagesText, pageCount).toSet()
                        val remaining = (1..pageCount).filterNot(removed::contains)
                        require(remaining.isNotEmpty()) { "No puedes eliminar todas las páginas." }
                        ToolFileUtils.organizePdf(context, inputs.first(), output, remaining)
                    }
                    3 -> ToolFileUtils.organizePdf(
                        context = context,
                        input = inputs.first(),
                        output = output,
                        pageOrder = emptyList(),
                        rotation = listOf(90, 180, 270)[rotationIndex],
                        rotationPages = PageSelectionParser.parse(pagesText, pageCount).toSet()
                    )
                    4 -> ToolFileUtils.organizePdf(
                        context,
                        inputs.first(),
                        output,
                        (pageCount downTo 1).toList()
                    )
                    6 -> ToolFileUtils.compressPdf(
                        context,
                        inputs.first(),
                        output,
                        compressionWidths[compressionIndex]
                    )
                    else -> error("Operación de PDF no válida.")
                }
            }.onSuccess { onMessage(successMessage("PDF procesado correctamente.", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo procesar el PDF.") }
            processing = false
        }
    }
    val folderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        val input = inputs.firstOrNull()
        if (tree == null || input == null) return@rememberLauncherForActivityResult
        val groups = runCatching { PageSelectionParser.parseGroups(pagesText, pageCount) }
            .getOrElse {
                onMessage(it.message ?: "Revisa los rangos.")
                return@rememberLauncherForActivityResult
            }
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                ToolFileUtils.splitPdf(context, input, tree, groups, splitBaseName)
            }.onSuccess { onMessage(successMessage("Se crearon ${groups.size} archivos PDF.", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo dividir el PDF.") }
            processing = false
        }
    }

    ToolPage(tool, onBack) {
        SimpleDropdown("Operación", modes, modeIndex) {
            modeIndex = it
            inputs.clear()
            pageCount = 0
            pagesText = ""
            visualOrder.clear()
            selectedPages.clear()
        }
        FileSelectionCard(
            title = if (modeIndex == 0) "PDF seleccionados" else "PDF seleccionado",
            detail = when {
                inputs.isEmpty() -> "No hay archivos elegidos."
                modeIndex == 0 -> "${inputs.size} archivos · se unirán en el orden mostrado."
                else -> "${ToolFileUtils.displayName(context, inputs.first())} · ${pageCount.takeIf { it > 0 } ?: "…"} páginas"
            },
            button = if (modeIndex == 0) "Elegir varios PDF" else "Elegir PDF",
            onClick = {
                if (modeIndex == 0) multiLauncher.launch(arrayOf("application/pdf"))
                else singleLauncher.launch(arrayOf("application/pdf"))
            }
        )
        if (modeIndex == 0 && inputs.isNotEmpty()) {
            inputs.forEachIndexed { index, uri ->
                FileOrderRow(
                    name = ToolFileUtils.displayName(context, uri),
                    index = index,
                    total = inputs.size,
                    onUp = {
                        val item = inputs.removeAt(index)
                        inputs.add(index - 1, item)
                    },
                    onDown = {
                        val item = inputs.removeAt(index)
                        inputs.add(index + 1, item)
                    },
                    onDelete = { inputs.removeAt(index) }
                )
            }
        } else if (modeIndex !in 1..3 || pageCount > 80) {
            inputs.firstOrNull()?.let { PdfFirstPagePreview(it) }
        }

        if (inputs.isNotEmpty() && pageCount in 1..80 && modeIndex in 1..3) {
            SettingSection(
                when (modeIndex) {
                    1 -> "Orden visual de páginas"
                    2 -> "Toca las páginas que quieres eliminar"
                    else -> "Toca las páginas que quieres girar"
                }
            ) {
                Text(
                    when (modeIndex) {
                        1 -> "Usa las flechas para mover páginas o la papelera para extraer solo las que necesitas."
                        2 -> "Las páginas marcadas se eliminarán. El original nunca se reemplaza."
                        else -> "Si no marcas ninguna página, la rotación se aplicará a todas."
                    },
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(visualOrder.toList(), key = { _, page -> page }) { index, pageNumber ->
                        PdfOrganizerPageTile(
                            uri = inputs.first(),
                            pageNumber = pageNumber,
                            selected = pageNumber in selectedPages,
                            mode = modeIndex,
                            canMoveBack = index > 0,
                            canMoveForward = index < visualOrder.lastIndex,
                            onSelect = {
                                if (modeIndex == 2 || modeIndex == 3) {
                                    if (pageNumber in selectedPages) selectedPages.remove(pageNumber) else selectedPages.add(pageNumber)
                                    pagesText = selectedPages.sorted().joinToString(",")
                                }
                            },
                            onMoveBack = {
                                if (index > 0) {
                                    val item = visualOrder.removeAt(index)
                                    visualOrder.add(index - 1, item)
                                    pagesText = visualOrder.joinToString(",")
                                }
                            },
                            onMoveForward = {
                                if (index < visualOrder.lastIndex) {
                                    val item = visualOrder.removeAt(index)
                                    visualOrder.add(index + 1, item)
                                    pagesText = visualOrder.joinToString(",")
                                }
                            },
                            onRemoveFromOrder = {
                                if (modeIndex == 1 && visualOrder.size > 1) {
                                    visualOrder.remove(pageNumber)
                                    pagesText = visualOrder.joinToString(",")
                                }
                            }
                        )
                    }
                }
                if (modeIndex == 1) Text("Salida: ${visualOrder.size} de $pageCount páginas", color = NeonGreen, fontWeight = FontWeight.Bold)
                else if (selectedPages.isNotEmpty()) Text("Seleccionadas: ${selectedPages.sorted().joinToString(", ")}", color = NeonGreen)
            }
        }

        when (modeIndex) {
            1 -> if (pageCount > 80) PageListField(pagesText, { pagesText = it }, "Nuevo orden o páginas", "Ejemplo: 3,1,2,4 o 1-5,9")
            2 -> if (pageCount > 80) PageListField(pagesText, { pagesText = it }, "Páginas a eliminar", "Ejemplo: 2,5-7")
            3 -> {
                if (pageCount > 80) PageListField(pagesText, { pagesText = it }, "Páginas a girar", "Vacío = todas; ejemplo: 1,3-5")
                SimpleDropdown("Rotación", listOf("90°", "180°", "270°"), rotationIndex) { rotationIndex = it }
            }
            5 -> {
                PageListField(pagesText, { pagesText = it }, "Grupos separados por ;", "Ejemplo: 1-3; 4-6; 7-10")
                OutlinedTextField(
                    value = splitBaseName,
                    onValueChange = { splitBaseName = it.replace(Regex("[^A-Za-z0-9_-]"), "_").take(30) },
                    label = { Text("Nombre base") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            6 -> {
                SimpleDropdown("Nivel de compresión", compressionLabels, compressionIndex) { compressionIndex = it }
                Text(
                    "La compresión crea una copia más ligera rasterizando cada página. Puede reducir el detalle de fotografías o planos.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (processing) ProcessingCard("Procesando PDF", null)
        Button(
            onClick = {
                val validation = runCatching {
                    when (modeIndex) {
                        0 -> require(inputs.size >= 2) { "Selecciona dos o más PDF." }
                        1, 2 -> PageSelectionParser.parse(pagesText, pageCount).also { require(it.isNotEmpty()) { "Indica las páginas." } }
                        3 -> if (pagesText.isNotBlank()) PageSelectionParser.parse(pagesText, pageCount)
                        4 -> require(pageCount > 0) { "Espera a que se lea el documento." }
                        5 -> PageSelectionParser.parseGroups(pagesText, pageCount)
                        6 -> require(pageCount > 0) { "Espera a que se lea el documento." }
                        else -> error("Operación de PDF no válida.")
                    }
                }
                validation.onFailure {
                    onMessage(it.message ?: "Revisa los datos.")
                    return@Button
                }
                launchPaidExport(viewModel, tool, onMessage) {
                    if (modeIndex == 5) folderLauncher.launch(null)
                    else saveLauncher.launch(
                        when (modeIndex) {
                            0 -> "pdf_unido.pdf"
                            1 -> "pdf_reordenado.pdf"
                            2 -> "pdf_sin_paginas.pdf"
                            3 -> "pdf_girado.pdf"
                            4 -> "pdf_invertido.pdf"
                            else -> "pdf_comprimido.pdf"
                        }
                    )
                }
            },
            enabled = inputs.isNotEmpty() && !processing,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
        ) {
            Icon(if (modeIndex == 5) Icons.Rounded.Folder else Icons.Rounded.Save, contentDescription = null)
            Text(" ${if (modeIndex == 5) "Elegir carpeta" else "Guardar resultado"} · ${tool.creditCost} créditos")
        }
        InfoToolText("Nunca se reemplaza el original. Los PDF dañados o con contraseña pueden no abrirse.")
    }
}

@Composable
fun SignPdfScreen(
    viewModel: GanaGeoViewModel,
    tool: ToolId,
    onBack: () -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf<Uri?>(null) }
    var pageCount by remember { mutableStateOf(0) }
    var pageText by rememberSaveable { mutableStateOf("1") }
    var positionIndex by rememberSaveable { mutableStateOf(SignaturePosition.BOTTOM_RIGHT.ordinal) }
    var sizePercent by rememberSaveable { mutableStateOf(28f) }
    var label by rememberSaveable { mutableStateOf("") }
    val strokes = remember { mutableStateListOf<SnapshotStateList<Offset>>() }
    var signaturePadSize by remember { mutableStateOf(IntSize.Zero) }
    var processing by remember { mutableStateOf(false) }

    val inputLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        input = uri
        pageCount = 0
        if (uri != null) scope.launch {
            runCatching { ToolFileUtils.pdfPageCount(context, uri) }
                .onSuccess { pageCount = it }
                .onFailure { onMessage(it.message ?: "No se pudo abrir el PDF.") }
        }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { output ->
        val source = input
        val page = pageText.toIntOrNull()
        if (output == null || source == null || page == null) return@rememberLauncherForActivityResult
        processing = true
        scope.launch {
            runPaidTool(viewModel, tool) {
                val signature = signatureBitmap(strokes, signaturePadSize)
                try {
                    ToolFileUtils.signPdf(
                        context = context,
                        input = source,
                        output = output,
                        signature = signature,
                        pageNumber = page,
                        placement = SignaturePlacement(
                            position = SignaturePosition.entries[positionIndex],
                            widthPercent = sizePercent.toInt(),
                            label = label
                        )
                    )
                } finally {
                    if (!signature.isRecycled) signature.recycle()
                }
            }.onSuccess { onMessage(successMessage("Documento firmado y guardado.", it)) }
                .onFailure { onMessage(it.message ?: "No se pudo firmar el PDF.") }
            processing = false
        }
    }

    ToolPage(tool, onBack) {
        FileSelectionCard(
            "PDF seleccionado",
            input?.let { "${ToolFileUtils.displayName(context, it)} · ${pageCount.takeIf { it > 0 } ?: "…"} páginas" }
                ?: "Selecciona el documento que deseas firmar.",
            "Elegir PDF"
        ) { inputLauncher.launch(arrayOf("application/pdf")) }
        input?.let {
            val previewPage = ((pageText.toIntOrNull() ?: 1) - 1).coerceAtLeast(0)
            PdfPagePreview(it, previewPage)
        }
        SettingSection("Ubicación de la firma") {
            OutlinedTextField(
                value = pageText,
                onValueChange = { pageText = it.filter(Char::isDigit).take(4) },
                label = { Text("Página") },
                supportingText = { Text(if (pageCount > 0) "Entre 1 y $pageCount" else "Selecciona un PDF") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            SimpleDropdown("Posición", SignaturePosition.entries.map { it.label }, positionIndex) { positionIndex = it }
            Text("Tamaño: ${sizePercent.toInt()} % del ancho de página")
            Slider(value = sizePercent, onValueChange = { sizePercent = it }, valueRange = 12f..55f)
            OutlinedTextField(
                value = label,
                onValueChange = { label = it.take(80) },
                label = { Text("Texto debajo (opcional)") },
                placeholder = { Text("Nombre o fecha") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        Text("Dibuja tu firma", fontWeight = FontWeight.Bold)
        SignaturePad(strokes, onSizeChanged = { signaturePadSize = it })
        OutlinedButton(onClick = { strokes.clear() }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.Refresh, contentDescription = null)
            Text(" Limpiar firma")
        }
        if (processing) ProcessingCard("Firmando documento", null)
        Button(
            onClick = {
                val page = pageText.toIntOrNull()
                when {
                    page == null || page < 1 -> onMessage("Indica una página válida.")
                    pageCount > 0 && page > pageCount -> onMessage("El documento solo tiene $pageCount páginas.")
                    strokes.isEmpty() -> onMessage("Dibuja tu firma antes de continuar.")
                    else -> launchPaidExport(viewModel, tool, onMessage) { saveLauncher.launch("documento_firmado.pdf") }
                }
            },
            enabled = input != null && strokes.isNotEmpty() && !processing,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = DeepGreen)
        ) {
            Icon(Icons.Rounded.Save, contentDescription = null)
            Text(" Firmar y guardar · ${tool.creditCost} créditos")
        }
        InfoToolText("La firma se coloca en una copia nueva. Revisa siempre el documento antes de compartirlo.")
    }
}

@Composable
private fun PdfImageThumbnailCard(
    page: PdfImagePage,
    pageNumber: Int,
    selected: Boolean,
    onSelect: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (selected) NeonGreen.copy(alpha = 0.28f) else CardGreen
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.width(112.dp).clickable(onClick = onSelect)
    ) {
        Column(Modifier.padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            AdjustedUriImage(
                uri = page.uri,
                rotation = page.rotationDegrees,
                filter = page.filter,
                brightness = page.brightness,
                contrast = page.contrast,
                modifier = Modifier.fillMaxWidth().height(116.dp)
            )
            Text("Página $pageNumber", fontWeight = FontWeight.Bold, color = if (selected) NeonGreen else Color.White)
        }
    }
}

@Composable
private fun PdfImagePageCard(
    page: PdfImagePage,
    pageNumber: Int,
    filter: DocumentImageFilter,
    brightness: Int,
    contrast: Float,
    onMoveUp: (() -> Unit)?,
    onMoveDown: (() -> Unit)?,
    onRotate: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CardGreen),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.width(170.dp)
    ) {
        Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            AdjustedUriImage(
                uri = page.uri,
                rotation = page.rotationDegrees,
                filter = filter,
                brightness = brightness,
                contrast = contrast,
                modifier = Modifier.fillMaxWidth().height(190.dp)
            )
            Text("Página $pageNumber", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                IconButton(onClick = { onMoveUp?.invoke() }, enabled = onMoveUp != null) {
                    Icon(Icons.Rounded.ArrowUpward, contentDescription = "Mover antes")
                }
                IconButton(onClick = { onMoveDown?.invoke() }, enabled = onMoveDown != null) {
                    Icon(Icons.Rounded.ArrowDownward, contentDescription = "Mover después")
                }
                IconButton(onClick = onRotate) {
                    Icon(Icons.Rounded.RotateRight, contentDescription = "Girar")
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Rounded.Delete, contentDescription = "Eliminar", tint = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
private fun AdjustedUriImage(
    uri: Uri,
    rotation: Int,
    filter: DocumentImageFilter,
    brightness: Int,
    contrast: Float,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var bitmap by remember(uri) { mutableStateOf<Bitmap?>(null) }
    var error by remember(uri) { mutableStateOf<String?>(null) }
    LaunchedEffect(uri) {
        runCatching { ToolFileUtils.loadBitmap(context, uri, maxEdge = 1100) }
            .onSuccess { fresh ->
                val old = bitmap
                bitmap = fresh
                error = null
                old?.takeIf { it !== fresh && !it.isRecycled }?.recycle()
            }
            .onFailure { error = it.message ?: "No se pudo mostrar la imagen." }
    }
    DisposableEffect(uri) {
        onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() }
    }

    val matrix = remember(filter, brightness, contrast) {
        previewColorMatrix(filter, brightness, contrast)
    }
    Box(
        modifier.background(Color.Black.copy(alpha = 0.28f), RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        bitmap?.let {
            Image(
                it.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize().graphicsLayer(rotationZ = rotation.toFloat()),
                contentScale = ContentScale.Fit,
                colorFilter = ColorFilter.colorMatrix(matrix)
            )
        } ?: if (error != null) {
            Text(error.orEmpty(), color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
        } else CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
    }
}

private fun previewColorMatrix(filter: DocumentImageFilter, brightness: Int, contrast: Float): ColorMatrix {
    val c = when (filter) {
        DocumentImageFilter.DOCUMENT -> contrast * 1.18f
        DocumentImageFilter.ENHANCE -> contrast * 1.08f
        else -> contrast
    }.coerceIn(0.5f, 2f)
    val t = brightness.coerceIn(-80, 80) * 2.55f + 128f * (1f - c)
    val values = if (filter == DocumentImageFilter.GRAYSCALE || filter == DocumentImageFilter.DOCUMENT) {
        floatArrayOf(
            0.213f * c, 0.715f * c, 0.072f * c, 0f, t,
            0.213f * c, 0.715f * c, 0.072f * c, 0f, t,
            0.213f * c, 0.715f * c, 0.072f * c, 0f, t,
            0f, 0f, 0f, 1f, 0f
        )
    } else {
        floatArrayOf(
            c, 0f, 0f, 0f, t,
            0f, c, 0f, 0f, t,
            0f, 0f, c, 0f, t,
            0f, 0f, 0f, 1f, 0f
        )
    }
    return ColorMatrix(values)
}

@Composable
private fun PdfOrganizerPageTile(
    uri: Uri,
    pageNumber: Int,
    selected: Boolean,
    mode: Int,
    canMoveBack: Boolean,
    canMoveForward: Boolean,
    onSelect: () -> Unit,
    onMoveBack: () -> Unit,
    onMoveForward: () -> Unit,
    onRemoveFromOrder: () -> Unit
) {
    val context = LocalContext.current
    var bitmap by remember(uri, pageNumber) { mutableStateOf<Bitmap?>(null) }
    var failed by remember(uri, pageNumber) { mutableStateOf(false) }
    LaunchedEffect(uri, pageNumber) {
        runCatching { ToolFileUtils.renderPdfPage(context, uri, pageNumber - 1, maxWidth = 260) }
            .onSuccess { next ->
                val previous = bitmap
                bitmap = next
                failed = false
                if (previous != null && previous !== next && !previous.isRecycled) previous.recycle()
            }
            .onFailure { failed = true }
    }
    DisposableEffect(uri, pageNumber) {
        onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() }
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = if (selected) NeonGreen.copy(alpha = 0.20f) else CardGreen),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.width(138.dp).clickable(enabled = mode == 2 || mode == 3, onClick = onSelect)
    ) {
        Column(Modifier.padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Box(Modifier.fillMaxWidth().height(156.dp), contentAlignment = Alignment.Center) {
                bitmap?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
                    ?: if (failed) Text("Sin vista", color = MaterialTheme.colorScheme.error) else CircularProgressIndicator(modifier = Modifier.size(26.dp))
                if (selected) {
                    Box(Modifier.align(Alignment.TopEnd).background(NeonGreen, CircleShape).padding(horizontal = 7.dp, vertical = 3.dp)) {
                        Text("✓", color = DeepGreen, fontWeight = FontWeight.Black)
                    }
                }
            }
            Text("Página $pageNumber", fontWeight = FontWeight.Bold, maxLines = 1)
            if (mode == 1) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    IconButton(onClick = onMoveBack, enabled = canMoveBack, modifier = Modifier.size(34.dp)) { Icon(Icons.Rounded.NavigateBefore, "Mover antes") }
                    IconButton(onClick = onMoveForward, enabled = canMoveForward, modifier = Modifier.size(34.dp)) { Icon(Icons.Rounded.NavigateNext, "Mover después") }
                    IconButton(onClick = onRemoveFromOrder, modifier = Modifier.size(34.dp)) { Icon(Icons.Rounded.Delete, "Quitar", tint = MaterialTheme.colorScheme.error) }
                }
            }
        }
    }
}

@Composable
private fun PdfFirstPagePreview(uri: Uri) = PdfPagePreview(uri, 0)

@Composable
private fun PdfPagePreview(uri: Uri, pageIndex: Int) {
    val context = LocalContext.current
    var bitmap by remember(uri, pageIndex) { mutableStateOf<Bitmap?>(null) }
    var error by remember(uri, pageIndex) { mutableStateOf<String?>(null) }
    LaunchedEffect(uri, pageIndex) {
        runCatching { ToolFileUtils.renderPdfPage(context, uri, pageIndex.coerceAtLeast(0), maxWidth = 750) }
            .onSuccess { newBitmap ->
                val old = bitmap
                bitmap = newBitmap
                error = null
                if (old != null && old !== newBitmap && !old.isRecycled) old.recycle()
            }
            .onFailure { error = it.message ?: "No se pudo mostrar la vista previa." }
    }
    DisposableEffect(Unit) { onDispose { bitmap?.takeIf { !it.isRecycled }?.recycle() } }
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(18.dp)) {
        Box(
            modifier = Modifier.fillMaxWidth().height(260.dp).padding(10.dp),
            contentAlignment = Alignment.Center
        ) {
            bitmap?.let {
                Image(it.asImageBitmap(), contentDescription = "Vista previa PDF", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            } ?: if (error != null) {
                Text(error.orEmpty(), color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
            } else CircularProgressIndicator()
        }
    }
}

@Composable
private fun FileOrderRow(
    name: String,
    index: Int,
    total: Int,
    onUp: () -> Unit,
    onDown: () -> Unit,
    onDelete: () -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${index + 1}", color = NeonGreen, fontWeight = FontWeight.Bold, modifier = Modifier.width(28.dp))
            Text(name, modifier = Modifier.weight(1f), maxLines = 2)
            IconButton(onClick = onUp, enabled = index > 0) { Icon(Icons.Rounded.ArrowUpward, null) }
            IconButton(onClick = onDown, enabled = index < total - 1) { Icon(Icons.Rounded.ArrowDownward, null) }
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, null, tint = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
private fun SignaturePad(
    strokes: SnapshotStateList<SnapshotStateList<Offset>>,
    onSizeChanged: (IntSize) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(190.dp)
            .background(Color.White, RoundedCornerShape(16.dp))
            .onSizeChanged(onSizeChanged)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { point -> strokes.add(mutableStateListOf(point)) },
                    onDrag = { change, _ ->
                        change.consume()
                        strokes.lastOrNull()?.add(change.position)
                    }
                )
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            strokes.forEach { stroke ->
                if (stroke.size == 1) drawCircle(Color.Black, radius = 2.5f, center = stroke.first())
                else {
                    val path = Path().apply {
                        moveTo(stroke.first().x, stroke.first().y)
                        stroke.drop(1).forEach { lineTo(it.x, it.y) }
                    }
                    drawPath(path, Color.Black, style = Stroke(width = 5f, cap = StrokeCap.Round))
                }
            }
        }
    }
}

private fun signatureBitmap(strokes: List<List<Offset>>, padSize: IntSize): Bitmap {
    require(strokes.isNotEmpty()) { "Dibuja una firma antes de continuar." }
    require(padSize.width > 0 && padSize.height > 0) { "La firma todavía no está lista." }
    val bitmap = Bitmap.createBitmap(900, 300, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bitmap)
    canvas.drawColor(AndroidColor.TRANSPARENT)
    val paint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
        color = AndroidColor.BLACK
        strokeWidth = 8f
        style = AndroidPaint.Style.STROKE
        strokeCap = AndroidPaint.Cap.ROUND
        strokeJoin = AndroidPaint.Join.ROUND
    }
    val scaleX = 900f / padSize.width.toFloat()
    val scaleY = 300f / padSize.height.toFloat()
    strokes.forEach { stroke ->
        if (stroke.size >= 2) {
            val path = android.graphics.Path().apply {
                moveTo(stroke.first().x * scaleX, stroke.first().y * scaleY)
                stroke.drop(1).forEach { lineTo(it.x * scaleX, it.y * scaleY) }
            }
            canvas.drawPath(path, paint)
        }
    }
    return bitmap
}

@Composable
private fun ToolPage(tool: ToolId, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ToolHeader(tool.title, "Costo por exportación: ${tool.creditCost} créditos", onBack)
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item { Column(verticalArrangement = Arrangement.spacedBy(14.dp)) { content() } }
        }
    }
}

@Composable
private fun SettingSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            content()
        }
    }
}

@Composable
private fun FileSelectionCard(title: String, detail: String, button: String, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardGreen), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            Text(detail, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.Folder, contentDescription = null)
                Text(" $button")
            }
        }
    }
}

@Composable
private fun PageListField(value: String, onChange: (String) -> Unit, label: String, hint: String) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(sanitizePageInput(it)) },
        label = { Text(label) },
        supportingText = { Text(hint) },
        modifier = Modifier.fillMaxWidth()
    )
}

private fun sanitizePageInput(value: String): String =
    value.filter { ch -> ch.isDigit() || ch == ',' || ch == '-' || ch == ';' || ch.isWhitespace() }.take(400)

@Composable
private fun ProcessingCard(title: String, progress: Float?) {
    Card(colors = CardDefaults.cardColors(containerColor = NeonGreen.copy(alpha = 0.12f)), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            if (progress == null) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            else {
                LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                Text("${(progress * 100).toInt()} %", color = NeonGreen)
            }
            Text("No cierres la aplicación hasta terminar.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun InfoToolText(text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Gold.copy(alpha = 0.10f)), shape = RoundedCornerShape(16.dp)) {
        Text(text, modifier = Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
