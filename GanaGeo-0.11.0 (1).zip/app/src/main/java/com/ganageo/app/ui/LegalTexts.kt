package com.ganageo.app.ui

import com.ganageo.app.BuildConfig

/**
 * Textos legales mostrados dentro de la app. La versión pública (web) está en
 * docs/web y debe decir lo mismo. Revisar con un abogado en Perú antes de publicar.
 */
enum class LegalDoc(val title: String) {
    PRIVACY("Política de privacidad"),
    TERMS("Términos y condiciones"),
    REWARDS("Reglas de Geo Rewards"),
    DELETE("Eliminar tu cuenta")
}

object LegalTexts {
    const val LAST_UPDATE = "Noviembre de 2026"

    val supportContact: String
        get() = BuildConfig.SUPPORT_EMAIL.ifBlank {
            "el correo de contacto del desarrollador que aparece en la ficha de Gana Geo en Google Play"
        }

    fun body(doc: LegalDoc): String = when (doc) {
        LegalDoc.PRIVACY -> privacy()
        LegalDoc.TERMS -> terms()
        LegalDoc.REWARDS -> rewards()
        LegalDoc.DELETE -> deletion()
    }

    private fun privacy() = """
Última actualización: $LAST_UPDATE

1. Quién es responsable
Gana Geo es una app para Perú. El responsable del tratamiento de tus datos es el desarrollador de Gana Geo. Contacto: $supportContact.

2. Qué datos usamos
• Cuenta de Google: nombre, correo y foto de perfil, solo si inicias sesión.
• Geo ID: número que identifica tu cuenta dentro de la app.
• Identificador de instalación: un código al azar creado por la app. No usamos IMEI, número de serie ni otros identificadores del equipo.
• Créditos, Geo Rewards e historial: qué herramienta de pago usaste, cuántos créditos gastaste y cuándo. No guardamos el contenido de tus archivos.
• Compras de Google Play: producto, fecha y una huella cifrada del comprobante. No vemos tu tarjeta ni tus datos de pago.
• Retiros (solo cuando estén habilitados): número de Yape, monto y estado.
• Geo Aventuras: vidas, niveles y puntajes de tu cuenta.

3. Tus archivos
Las herramientas de PDF, imágenes, documentos y cálculos trabajan dentro de tu celular. Tus archivos no se suben a nuestros servidores. El multijugador local de Geo Aventuras usa solo tu red Wi-Fi o zona Wi-Fi.

4. Para qué los usamos
Para crear y proteger tu cuenta, cobrar y sumar créditos, calcular Geo Rewards, prevenir fraude (una cuenta con Rewards por celular), atender soporte y cumplir la ley.

5. Con quién se comparten
• Supabase: guarda la base de datos de la app.
• Google: inicio de sesión y pagos con Google Play.
No vendemos tus datos y la app no muestra publicidad.

6. Seguridad
La información viaja cifrada (HTTPS). Cada usuario solo puede ver sus propios datos y los saldos solo los cambia el servidor.

7. Cuánto tiempo los guardamos
Mientras tengas cuenta. Si la eliminas, se borran tu perfil, saldos, historial y progreso. Solo conservamos un registro mínimo, sin nombre ni correo (una huella cifrada de la cuenta y de sus compras), para atender reembolsos de Google Play y evitar fraudes, por el plazo que exija la ley.

8. Tus derechos
Según la Ley N.° 29733 de Protección de Datos Personales del Perú, puedes pedir acceso, rectificación, cancelación u oposición. Escríbenos a: $supportContact. También puedes eliminar tu cuenta desde Perfil.

9. Menores de edad
Las compras, Geo Rewards y retiros son solo para personas mayores de 18 años.

10. Cambios
Si cambiamos esta política, lo avisaremos en la app.
""".trim()

    private fun terms() = """
Última actualización: $LAST_UPDATE

1. El servicio
Gana Geo ofrece herramientas gratuitas, herramientas que usan créditos y el juego Geo Aventuras. Está pensada para usuarios en Perú.

2. Cuenta
Puedes usar las herramientas gratuitas y el juego sin cuenta. Para créditos, Geo Rewards y retiros necesitas iniciar sesión con Google. Solo se permite una cuenta con Rewards por celular. Si cambias de celular, puedes autorizar el nuevo desde la app.

3. Créditos
• Se compran solo con Google Play: S/ 5 = 50 créditos y S/ 10 = 100 créditos (precios en soles mostrados por Google Play).
• Sirven para usar herramientas de pago y vidas doradas de Geo Aventuras.
• No son dinero, no se transfieren y no se cambian por soles.
• Antes de usar una herramienta se muestra su costo. Si la operación falla o la cancelas, los créditos se devuelven.
• Los reembolsos siguen las reglas de Google Play. Si Google reembolsa una compra, se retiran los créditos que no se hayan usado.

4. Uso correcto
No está permitido modificar la app, usar programas automáticos, crear cuentas falsas, abusar de errores ni intentar obtener créditos o Rewards sin una compra real. Si ocurre, podemos anular saldos y suspender la cuenta.

5. Herramientas
Las herramientas se entregan tal como están. Revisa siempre tus documentos y resultados antes de usarlos en trámites importantes.

6. Geo Rewards
Se rigen por las "Reglas de Geo Rewards", que forman parte de estos términos.

7. Ley aplicable
Se aplican las leyes del Perú, incluido el Código de Protección y Defensa del Consumidor. Para consultas o reclamos escribe a: $supportContact.

8. Cambios
Podemos actualizar estos términos. Los cambios importantes se avisarán en la app.
""".trim()

    private fun rewards() = """
Última actualización: $LAST_UPDATE

1. Qué son
Geo Rewards son puntos de fidelidad por usar créditos COMPRADOS en Gana Geo. Son un beneficio adicional: lo principal es la utilidad de las herramientas.

2. Cómo se ganan (proporción fija)
• Herramientas de pago: cada 10 créditos comprados usados en operaciones completadas suman 50 Geo Rewards. Ejemplo: 20 créditos = 100 Rewards; 100 créditos = 500 Rewards.
• Geo Aventuras: una vida dorada cuesta 2 créditos. Las Rewards se suman al usar la vida dorada (después de 20 segundos de juego), ganes o pierdas, con la misma proporción. Máximo 10 vidas doradas por día.
• No dependen de la suerte ni de tu puntaje.
• Los créditos de regalo o promoción no suman Rewards.
• Las herramientas gratuitas no suman Rewards.

3. Canje y retiro
• Equivalencia prevista: 100 Geo Rewards = S/ 1.
• El único método de retiro es Yape, a un número peruano a tu nombre. Monto mínimo: S/ 5.
• Cada solicitud la revisa una persona antes de pagar. No hay pagos automáticos.
• IMPORTANTE: el canje y los retiros todavía NO están habilitados. Se anunciarán en la app cuando estén listos.

4. Requisitos
Ser mayor de 18 años, residir en Perú, tener la cuenta activa y una sola cuenta con Rewards por celular.

5. Anulaciones
Se anulan Rewards obtenidas con compras reembolsadas, con fraude o con errores de la app.

6. Cambios o fin del programa
Podemos cambiar o terminar el programa avisando en la app. Las Rewards ya ganadas se tratarán según estas reglas.

Contacto: $supportContact.
""".trim()

    private fun deletion() = """
Puedes eliminar tu cuenta cuando quieras desde Perfil > Eliminar cuenta, sin reinstalar la app. Si ya no tienes la app, escríbenos desde el correo de tu cuenta de Google a: $supportContact.

Qué se borra: perfil, Geo ID, créditos, Geo Rewards, historial, progreso de Geo Aventuras y el vínculo con tu celular.

Qué se conserva: un registro mínimo sin nombre ni correo (huella cifrada de la cuenta y de sus compras) para reembolsos de Google Play y prevención de fraude.

Antes de eliminar: si tienes una solicitud de retiro abierta, primero cancélala. Los créditos y Rewards que tengas se pierden y no se pueden recuperar.
""".trim()
}
