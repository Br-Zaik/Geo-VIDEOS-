package com.ganageo.app.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Profile(
    @SerialName("user_id") val userId: String,
    @SerialName("geo_id") val geoId: Long,
    @SerialName("display_name") val displayName: String? = null,
    @SerialName("avatar_url") val avatarUrl: String? = null,
    @SerialName("country_code") val countryCode: String = "PE",
    @SerialName("account_status") val accountStatus: String = "active",
    @SerialName("created_at") val createdAt: String? = null
)

@Serializable
data class Wallet(
    @SerialName("user_id") val userId: String,
    @SerialName("internal_points") val internalPoints: Long = 0,
    @SerialName("pending_amount") val pendingAmount: Double = 0.0,
    @SerialName("available_amount") val availableAmount: Double = 0.0,
    @SerialName("locked_amount") val lockedAmount: Double = 0.0,
    val currency: String = "PEN"
)

@Serializable
data class LedgerEntry(
    val id: Long,
    @SerialName("entry_type") val entryType: String,
    @SerialName("points_delta") val pointsDelta: Long = 0,
    @SerialName("cash_delta") val cashDelta: Double = 0.0,
    @SerialName("cash_bucket") val cashBucket: String? = null,
    val currency: String? = null,
    val provider: String? = null,
    val description: String? = null,
    @SerialName("created_at") val createdAt: String? = null
)

@Serializable
data class Withdrawal(
    val id: String,
    val amount: Double,
    val currency: String,
    @SerialName("payment_method") val paymentMethod: String,
    @SerialName("payment_destination") val paymentDestination: String,
    val status: String,
    @SerialName("requested_at") val requestedAt: String? = null,
    @SerialName("rejection_reason") val rejectionReason: String? = null
)

@Serializable
data class DashboardData(
    val profile: Profile,
    val wallet: Wallet,
    val ledger: List<LedgerEntry>,
    val withdrawals: List<Withdrawal>,
    val deviceNotice: String? = null,
    val toolCredits: ToolCreditAccount = ToolCreditAccount(),
    val features: AppFeatures = AppFeatures()
)

@Serializable
data class ToolCreditAccount(
    @SerialName("user_id") val userId: String = "",
    @SerialName("purchased_credits") val purchasedCredits: Long = 0,
    @SerialName("promo_credits") val promoCredits: Long = 0,
    @SerialName("reserved_purchased") val reservedPurchased: Long = 0,
    @SerialName("reserved_promo") val reservedPromo: Long = 0,
    @SerialName("purchased_used_total") val purchasedUsedTotal: Long = 0,
    @SerialName("promo_used_total") val promoUsedTotal: Long = 0,
    @SerialName("reward_progress") val rewardProgress: Long = 0
) {
    val availableCredits: Long
        get() = (purchasedCredits + promoCredits - reservedPurchased - reservedPromo).coerceAtLeast(0)
}

@Serializable
data class ToolOperationReservation(
    @SerialName("operation_id") val operationId: String,
    @SerialName("reserved_credits") val reservedCredits: Long,
    @SerialName("credit_source") val creditSource: String = "purchased"
)

@Serializable
data class ToolOperationResult(
    @SerialName("awarded_points") val awardedPoints: Long = 0,
    @SerialName("remaining_credits") val remainingCredits: Long = 0
)

/** Interruptores que decide el servidor (no se pueden activar desde el teléfono). */
@Serializable
data class AppFeatures(
    @SerialName("withdrawals_enabled") val withdrawalsEnabled: Boolean = false,
    @SerialName("purchases_enabled") val purchasesEnabled: Boolean = false,
    @SerialName("min_withdrawal") val minWithdrawal: Double = 5.0,
    @SerialName("withdrawal_method") val withdrawalMethod: String = "yape"
)

/** Respuesta de la Edge Function que valida compras con Google Play. */
@Serializable
data class PlayPurchaseVerification(
    val ok: Boolean = false,
    @SerialName("credits_granted") val creditsGranted: Long = 0,
    @SerialName("already_processed") val alreadyProcessed: Boolean = false,
    val error: String? = null
)
