package com.ganageo.app.data

/** Reglas puras (sin Android) para retiros por Yape. El servidor aplica las mismas. */
object YapeRules {
    const val MIN_WITHDRAWAL_PEN = 5.0

    /** Celular peruano: 9 dígitos que empiezan con 9. Acepta +51 delante y espacios. */
    fun isValidPhone(raw: String): Boolean {
        var digits = raw.filter(Char::isDigit)
        if (digits.length == 11 && digits.startsWith("51")) digits = digits.substring(2)
        return digits.length == 9 && digits.startsWith("9")
    }

    fun isValidAmount(amount: Double?, available: Double): Boolean =
        amount != null && amount >= MIN_WITHDRAWAL_PEN && amount <= available &&
            Math.round(amount * 100.0) / 100.0 == amount
}
