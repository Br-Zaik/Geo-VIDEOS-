package com.geovideos.app.ui

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.geovideos.app.data.ChannelItem
import com.geovideos.app.data.CommentItem
import com.geovideos.app.data.VideoDetails
import com.geovideos.app.data.VideoItem
import com.geovideos.app.network.HomeChip
import java.time.Instant
import kotlin.math.max

internal enum class NativeVideoListMode { FULL, COMPACT }

private object NativePools {
    val video = RecyclerView.RecycledViewPool().apply {
        setMaxRecycledViews(NativeVideoAdapter.TYPE_FULL, 10)
        setMaxRecycledViews(NativeVideoAdapter.TYPE_COMPACT, 16)
    }
    val channel = RecyclerView.RecycledViewPool().apply {
        setMaxRecycledViews(NativeChannelAdapter.TYPE_CHANNEL, 16)
    }
    val player = RecyclerView.RecycledViewPool().apply {
        setMaxRecycledViews(NativePlayerAdapter.TYPE_RELATED, 14)
        setMaxRecycledViews(NativePlayerAdapter.TYPE_RELATED_FULL, 8)
    }
}

@Composable
internal fun NativeVideoList(
    modifier: Modifier,
    videos: List<VideoItem>,
    loading: Boolean = false,
    loadingMore: Boolean = false,
    canLoadMore: Boolean = false,
    mode: NativeVideoListMode = NativeVideoListMode.COMPACT,
    emptyMessage: String = "No hay videos disponibles.",
    onLoadMore: (() -> Unit)? = null,
    onPlay: (VideoItem) -> Unit,
    onSave: (VideoItem) -> Unit
) {
    val adapter = remember { NativeVideoAdapter(mode, onPlay, onSave) }
    AndroidView(
        modifier = modifier,
        factory = { context ->
            RecyclerView(context).apply {
                layoutManager = LinearLayoutManager(context).apply { initialPrefetchItemCount = 3 }
                this.adapter = adapter
                itemAnimator = null
                setHasFixedSize(false)
                setItemViewCacheSize(if (mode == NativeVideoListMode.COMPACT) 8 else 5)
                setRecycledViewPool(NativePools.video)
                overScrollMode = View.OVER_SCROLL_NEVER
                isNestedScrollingEnabled = true
                addOnScrollListener(object : RecyclerView.OnScrollListener() {
                    override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                        if (dy <= 0 || onLoadMore == null) return
                        val manager = recyclerView.layoutManager as? LinearLayoutManager ?: return
                        val last = manager.findLastVisibleItemPosition()
                        val currentAdapter = recyclerView.adapter as? NativeVideoAdapter ?: return
                        if (currentAdapter.canLoadMore && !currentAdapter.loadingMore && last >= currentAdapter.itemCount - 4) {
                            currentAdapter.loadingMore = true
                            currentAdapter.onLoadMore?.invoke()
                        }
                    }
                })
            }
        },
        update = { recyclerView ->
            val current = recyclerView.adapter as NativeVideoAdapter
            current.onPlay = onPlay
            current.onSave = onSave
            current.onLoadMore = onLoadMore
            current.canLoadMore = canLoadMore
            current.loadingMore = loadingMore
            current.submitContent(videos, loading, loadingMore, emptyMessage)
        }
    )
}

@Composable
internal fun NativeChannelList(
    modifier: Modifier,
    channels: List<ChannelItem>,
    emptyMessage: String = "No hay canales disponibles.",
    onOpenChannel: (ChannelItem) -> Unit
) {
    val adapter = remember { NativeChannelAdapter(onOpenChannel) }
    AndroidView(
        modifier = modifier,
        factory = { context ->
            RecyclerView(context).apply {
                layoutManager = LinearLayoutManager(context)
                this.adapter = adapter
                itemAnimator = null
                setHasFixedSize(true)
                setItemViewCacheSize(8)
                setRecycledViewPool(NativePools.channel)
                overScrollMode = View.OVER_SCROLL_NEVER
            }
        },
        update = { recyclerView ->
            val current = recyclerView.adapter as NativeChannelAdapter
            current.onOpen = onOpenChannel
            current.submitContent(channels, emptyMessage)
        }
    )
}

internal data class PlayerHeaderData(
    val video: VideoItem,
    val details: VideoDetails?,
    val isLiked: Boolean,
    val isDisliked: Boolean,
    val isWatchLater: Boolean,
    val description: String,
    val channelAvatar: String,
    val publishedAt: String,
    val qualityLabel: String = "Calidad",
    val audioOnly: Boolean = false,
    val mixAvailable: Boolean = false,
    val mixCount: Int = 0,
    val isSubscribed: Boolean = false,
    val queueTitle: String = "",
    val queueSubtitle: String = "",
    val queuePosition: Int = 0,
    val relatedChips: List<HomeChip> = emptyList(),
    val selectedRelatedChip: String = ""
)

@Composable
internal fun NativePlayerDetailsList(
    modifier: Modifier,
    header: PlayerHeaderData,
    related: List<VideoItem>,
    relatedLoading: Boolean,
    relatedLoadingMore: Boolean,
    relatedCanLoadMore: Boolean,
    onLike: () -> Unit,
    onDislike: () -> Unit,
    onWatchLater: () -> Unit,
    onShare: () -> Unit,
    onQuality: () -> Unit,
    onDownload: () -> Unit,
    onToggleAudioOnly: () -> Unit,
    onPictureInPicture: () -> Unit,
    onOpenChannel: (ChannelItem) -> Unit,
    onPlayRelated: (VideoItem) -> Unit,
    onSaveRelated: (VideoItem) -> Unit,
    onDownloadRelated: (VideoItem) -> Unit,
    onLoadMore: () -> Unit,
    onSelectChip: (HomeChip) -> Unit = {},
    onToggleSubscribe: () -> Unit = {},
    onOpenComments: () -> Unit = {},
    onSeek: (Long) -> Unit = {},
    onOpenQueue: () -> Unit = {}
) {
    val adapter = remember {
        NativePlayerAdapter(
            onLike = onLike,
            onDislike = onDislike,
            onWatchLater = onWatchLater,
            onShare = onShare,
            onQuality = onQuality,
            onDownload = onDownload,
            onToggleAudioOnly = onToggleAudioOnly,
            onPictureInPicture = onPictureInPicture,
            onOpenChannel = onOpenChannel,
            onPlayRelated = onPlayRelated,
            onSaveRelated = onSaveRelated,
            onDownloadRelated = onDownloadRelated,
            onLoadMore = onLoadMore
        )
    }
    AndroidView(
        modifier = modifier,
        factory = { context ->
            RecyclerView(context).apply {
                layoutManager = LinearLayoutManager(context).apply { initialPrefetchItemCount = 3 }
                this.adapter = adapter
                itemAnimator = null
                setHasFixedSize(false)
                setItemViewCacheSize(7)
                setRecycledViewPool(NativePools.player)
                overScrollMode = View.OVER_SCROLL_NEVER
                addOnScrollListener(object : RecyclerView.OnScrollListener() {
                    override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                        if (dy <= 0) return
                        val manager = recyclerView.layoutManager as? LinearLayoutManager ?: return
                        val current = recyclerView.adapter as? NativePlayerAdapter ?: return
                        if (current.canLoadMore && !current.loadingMore && manager.findLastVisibleItemPosition() >= current.itemCount - 4) {
                            current.loadingMore = true
                            current.onLoadMore()
                        }
                    }
                })
            }
        },
        update = { recyclerView ->
            val current = recyclerView.adapter as NativePlayerAdapter
            current.updateCallbacks(
                onLike, onDislike, onWatchLater, onShare, onQuality, onDownload,
                onToggleAudioOnly, onPictureInPicture,
                onOpenChannel, onPlayRelated, onSaveRelated, onDownloadRelated, onLoadMore
            )
            current.onSelectChip = onSelectChip
            current.onToggleSubscribe = onToggleSubscribe
            current.onOpenComments = onOpenComments
            current.onSeek = onSeek
            current.onOpenQueue = onOpenQueue
            current.canLoadMore = relatedCanLoadMore
            current.loadingMore = relatedLoadingMore
            current.submitContent(header, related.distinctBy { it.id }, relatedLoading, relatedLoadingMore, relatedCanLoadMore)
        }
    )
}

private sealed interface VideoRow {
    val id: Long
    data class Video(val item: VideoItem) : VideoRow { override val id = item.id.hashCode().toLong() }
    data object Loading : VideoRow { override val id = Long.MIN_VALUE + 101 }
    data class Empty(val message: String) : VideoRow { override val id = Long.MIN_VALUE + 102 }
}

private object VideoRowDiff : DiffUtil.ItemCallback<VideoRow>() {
    override fun areItemsTheSame(oldItem: VideoRow, newItem: VideoRow) = oldItem.id == newItem.id
    override fun areContentsTheSame(oldItem: VideoRow, newItem: VideoRow) = oldItem == newItem
}

private class NativeVideoAdapter(
    private val mode: NativeVideoListMode,
    var onPlay: (VideoItem) -> Unit,
    var onSave: (VideoItem) -> Unit
) : ListAdapter<VideoRow, RecyclerView.ViewHolder>(VideoRowDiff) {
    var onLoadMore: (() -> Unit)? = null
    var canLoadMore = false
    var loadingMore = false

    init { setHasStableIds(true) }

    fun submitContent(videos: List<VideoItem>, loading: Boolean, loadingMore: Boolean, emptyMessage: String) {
        this.loadingMore = loadingMore
        submitList(buildList {
            videos.distinctBy { it.id }.forEach { add(VideoRow.Video(it)) }
            when {
                loadingMore || (loading && videos.isEmpty()) -> add(VideoRow.Loading)
                videos.isEmpty() -> add(VideoRow.Empty(emptyMessage))
            }
        })
    }

    override fun getItemId(position: Int) = getItem(position).id
    override fun getItemViewType(position: Int): Int = when (getItem(position)) {
        is VideoRow.Video -> if (mode == NativeVideoListMode.FULL) TYPE_FULL else TYPE_COMPACT
        VideoRow.Loading -> TYPE_LOADING
        is VideoRow.Empty -> TYPE_EMPTY
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder = when (viewType) {
        TYPE_FULL -> FullVideoHolder(parent.context)
        TYPE_COMPACT -> CompactVideoHolder(parent.context)
        TYPE_LOADING -> LoadingRowHolder(parent.context)
        else -> EmptyRowHolder(parent.context)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = getItem(position)) {
            is VideoRow.Video -> when (holder) {
                is FullVideoHolder -> holder.bind(row.item, onPlay, onSave)
                is CompactVideoHolder -> holder.bind(row.item, onPlay, onSave)
            }
            is VideoRow.Empty -> (holder as EmptyRowHolder).bind(row.message)
            VideoRow.Loading -> Unit
        }
    }

    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        when (holder) {
            is FullVideoHolder -> holder.recycle()
            is CompactVideoHolder -> holder.recycle()
        }
        super.onViewRecycled(holder)
    }

    companion object {
        const val TYPE_FULL = 20
        const val TYPE_COMPACT = 21
        const val TYPE_LOADING = 22
        const val TYPE_EMPTY = 23
    }
}

private class FullVideoHolder(context: Context) : RecyclerView.ViewHolder(FullVideoCardView(context)) {
    private val card = itemView as FullVideoCardView

    fun bind(video: VideoItem, onPlay: (VideoItem) -> Unit, onSave: (VideoItem) -> Unit) {
        card.title.text = video.title.ifBlank { "Video" }
        card.channel.text = buildString {
            append(video.channelTitle.ifBlank { "Canal" })
            video.viewCountText.takeIf { it.isNotBlank() }?.let { append(" · ").append(it) }
            formatRelativeTime(video.publishedAt).takeIf { it.isNotBlank() }?.let { append(" · ").append(it) }
            if (video.isNew) append(" · Nuevo")
        }
        card.duration.text = durationText(video.durationMs)
        card.duration.visibility = if (video.durationMs > 0L && !video.isLive) View.VISIBLE else View.GONE
        card.live.visibility = if (video.isLive) View.VISIBLE else View.GONE
        card.setOnClickListener { onPlay(video) }
        card.more.setOnClickListener { onSave(video) }
        loadThumbnail(card.thumbnail, video.thumbnailUrl, 640, 360)
        loadAvatar(card.avatar, video.channelThumbnailUrl)
    }

    fun recycle() {
        card.title.text = ""
        card.channel.text = ""
        Glide.with(card.thumbnail).clear(card.thumbnail)
        Glide.with(card.avatar).clear(card.avatar)
        card.setOnClickListener(null)
        card.more.setOnClickListener(null)
    }
}

private class CompactVideoHolder(context: Context) : RecyclerView.ViewHolder(CompactVideoCardView(context)) {
    private val card = itemView as CompactVideoCardView

    fun bind(video: VideoItem, onPlay: (VideoItem) -> Unit, onSave: (VideoItem) -> Unit) {
        card.title.text = video.title.ifBlank { "Video" }
        card.channel.text = video.channelTitle.ifBlank { "Canal" }
        card.meta.text = listOfNotNull(
            formatRelativeTime(video.publishedAt).takeIf { it.isNotBlank() },
            if (video.resumePositionMs > 0L) "Continuar" else null
        ).joinToString(" · ")
        card.duration.text = durationText(video.durationMs)
        card.duration.visibility = if (video.durationMs > 0L && !video.isLive) View.VISIBLE else View.GONE
        card.setOnClickListener { onPlay(video) }
        card.more.setOnClickListener { onSave(video) }
        loadThumbnail(card.thumbnail, video.thumbnailUrl, 480, 270)
    }

    fun recycle() {
        card.title.text = ""
        card.channel.text = ""
        card.meta.text = ""
        Glide.with(card.thumbnail).clear(card.thumbnail)
        card.setOnClickListener(null)
        card.more.setOnClickListener(null)
    }
}

private class FullVideoCardView(context: Context) : LinearLayout(context) {
    val thumbnail = ImageView(context)
    val avatar = ImageView(context)
    val title = TextView(context)
    val channel = TextView(context)
    val more = TextView(context)
    val duration = TextView(context)
    val live = TextView(context)

    init {
        orientation = VERTICAL
        layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setBackgroundColor(Color.BLACK)
        isClickable = true
        isFocusable = true

        val media = NativeSixteenNineFrame(context).apply {
            setBackgroundColor(Color.BLACK)
            thumbnail.scaleType = ImageView.ScaleType.CENTER_CROP
            addView(thumbnail, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            live.text = "EN VIVO"
            live.setTextColor(Color.WHITE)
            live.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            live.setTypeface(live.typeface, android.graphics.Typeface.BOLD)
            live.background = roundedDrawable(0xFFD32F2F.toInt(), 5f, context)
            live.setPadding(dp(context, 7), dp(context, 3), dp(context, 7), dp(context, 3))
            addView(live, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START).apply {
                setMargins(dp(context, 10), 0, 0, dp(context, 9))
            })
            duration.setTextColor(Color.WHITE)
            duration.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            duration.background = roundedDrawable(0xCC000000.toInt(), 4f, context)
            duration.setPadding(dp(context, 6), dp(context, 2), dp(context, 6), dp(context, 2))
            addView(duration, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(context, 10), dp(context, 9))
            })
        }
        addView(media)

        val info = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.TOP
            setPadding(dp(context, 14), dp(context, 10), dp(context, 8), dp(context, 12))
            setBackgroundColor(Color.BLACK)
        }
        avatar.scaleType = ImageView.ScaleType.CENTER_CROP
        info.addView(avatar, LayoutParams(dp(context, 40), dp(context, 40)))
        val texts = LinearLayout(context).apply {
            orientation = VERTICAL
            title.setTextColor(Color.WHITE)
            title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
            title.maxLines = 2
            title.ellipsize = TextUtils.TruncateAt.END
            channel.setTextColor(0xFFB6B3BE.toInt())
            channel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            channel.maxLines = 1
            channel.ellipsize = TextUtils.TruncateAt.END
            channel.setPadding(0, dp(context, 4), 0, 0)
            addView(title, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(channel, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        info.addView(texts, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(context, 11) })
        more.text = "⋮"
        more.gravity = Gravity.CENTER
        more.setTextColor(Color.WHITE)
        more.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
        info.addView(more, LayoutParams(dp(context, 44), dp(context, 44)))
        addView(info)
    }
}

private class CompactVideoCardView(context: Context) : LinearLayout(context) {
    val thumbnail = ImageView(context)
    val title = TextView(context)
    val channel = TextView(context)
    val meta = TextView(context)
    val more = TextView(context)
    val duration = TextView(context)

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 108))
        setPadding(dp(context, 12), dp(context, 8), dp(context, 8), dp(context, 8))
        setBackgroundColor(Color.BLACK)
        isClickable = true
        isFocusable = true

        val media = FrameLayout(context)
        thumbnail.scaleType = ImageView.ScaleType.CENTER_CROP
        media.addView(thumbnail, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        duration.setTextColor(Color.WHITE)
        duration.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
        duration.background = roundedDrawable(0xCC000000.toInt(), 4f, context)
        duration.setPadding(dp(context, 5), dp(context, 2), dp(context, 5), dp(context, 2))
        media.addView(duration, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(context, 5), dp(context, 5))
        })
        addView(media, LayoutParams(dp(context, 150), dp(context, 84)))

        val texts = LinearLayout(context).apply {
            orientation = VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            title.setTextColor(Color.WHITE)
            title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
            title.maxLines = 2
            title.ellipsize = TextUtils.TruncateAt.END
            channel.setTextColor(0xFFB6B3BE.toInt())
            channel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            channel.maxLines = 1
            channel.ellipsize = TextUtils.TruncateAt.END
            meta.setTextColor(0xFF8E8A97.toInt())
            meta.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            meta.maxLines = 1
            addView(title, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(channel, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(context, 4) })
            addView(meta, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(context, 2) })
        }
        addView(texts, LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply { marginStart = dp(context, 12) })
        more.text = "⋮"
        more.gravity = Gravity.CENTER
        more.setTextColor(Color.WHITE)
        more.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
        addView(more, LayoutParams(dp(context, 42), dp(context, 48)))
    }
}

private class PlayerRelatedHolder(context: Context) : RecyclerView.ViewHolder(PlayerRelatedCardView(context)) {
    private val card = itemView as PlayerRelatedCardView

    fun bind(
        video: VideoItem,
        onPlay: (VideoItem) -> Unit,
        onDownload: (VideoItem) -> Unit
    ) {
        card.title.text = video.title.ifBlank { "Video" }
        card.channel.text = video.channelTitle.ifBlank { "Canal" }
        card.meta.text = formatRelativeTime(video.publishedAt)
        card.meta.visibility = if (card.meta.text.isNullOrBlank()) View.GONE else View.VISIBLE
        card.duration.text = durationText(video.durationMs)
        card.duration.visibility = if (video.durationMs > 0L && !video.isLive) View.VISIBLE else View.GONE
        card.live.visibility = if (video.isLive) View.VISIBLE else View.GONE
        card.setOnClickListener { onPlay(video) }
        card.download.setOnClickListener { onDownload(video) }
        loadThumbnail(card.thumbnail, video.thumbnailUrl, 480, 270)
    }

    fun recycle() {
        card.title.text = ""
        card.channel.text = ""
        card.meta.text = ""
        Glide.with(card.thumbnail).clear(card.thumbnail)
        card.setOnClickListener(null)
        card.download.setOnClickListener(null)
    }
}

private class PlayerRelatedCardView(context: Context) : LinearLayout(context) {
    val thumbnail = ImageView(context)
    val title = TextView(context)
    val channel = TextView(context)
    val meta = TextView(context)
    val duration = TextView(context)
    val live = TextView(context)
    val download = ImageView(context)

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 102))
        setPadding(dp(context, 12), dp(context, 7), dp(context, 7), dp(context, 7))
        setBackgroundColor(Color.BLACK)
        isClickable = true
        isFocusable = true

        val media = FrameLayout(context).apply { setBackgroundColor(0xFF121216.toInt()) }
        thumbnail.scaleType = ImageView.ScaleType.CENTER_CROP
        media.addView(thumbnail, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        duration.setTextColor(Color.WHITE)
        duration.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
        duration.background = roundedDrawable(0xCC000000.toInt(), 4f, context)
        duration.setPadding(dp(context, 5), dp(context, 2), dp(context, 5), dp(context, 2))
        media.addView(duration, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(context, 5), dp(context, 5))
        })
        live.text = "EN VIVO"
        live.setTextColor(Color.WHITE)
        live.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
        live.setTypeface(live.typeface, android.graphics.Typeface.BOLD)
        live.background = roundedDrawable(0xFFD32F2F.toInt(), 4f, context)
        live.setPadding(dp(context, 5), dp(context, 2), dp(context, 5), dp(context, 2))
        media.addView(live, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START).apply {
            setMargins(dp(context, 5), 0, 0, dp(context, 5))
        })
        addView(media, LayoutParams(dp(context, 146), dp(context, 82)))

        val texts = LinearLayout(context).apply {
            orientation = VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            title.setTextColor(Color.WHITE)
            title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
            title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
            title.maxLines = 2
            title.ellipsize = TextUtils.TruncateAt.END
            channel.setTextColor(0xFFB9B5C0.toInt())
            channel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            channel.maxLines = 1
            channel.ellipsize = TextUtils.TruncateAt.END
            meta.setTextColor(0xFF8E8A97.toInt())
            meta.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            meta.maxLines = 1
            addView(title, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(channel, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(context, 3) })
            addView(meta, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(context, 1) })
        }
        addView(texts, LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply { marginStart = dp(context, 11) })

        download.setImageResource(com.geovideos.app.R.drawable.ic_player_download)
        download.setColorFilter(Color.WHITE)
        download.contentDescription = "Descargar"
        download.setPadding(dp(context, 10), dp(context, 10), dp(context, 10), dp(context, 10))
        download.isClickable = true
        download.isFocusable = true
        addView(download, LayoutParams(dp(context, 46), dp(context, 52)))
    }
}

private sealed interface ChannelRow {
    val id: Long
    data class Channel(val item: ChannelItem) : ChannelRow { override val id = item.id.hashCode().toLong() }
    data class Empty(val message: String) : ChannelRow { override val id = Long.MIN_VALUE + 201 }
}

private object ChannelRowDiff : DiffUtil.ItemCallback<ChannelRow>() {
    override fun areItemsTheSame(oldItem: ChannelRow, newItem: ChannelRow) = oldItem.id == newItem.id
    override fun areContentsTheSame(oldItem: ChannelRow, newItem: ChannelRow) = oldItem == newItem
}

private class NativeChannelAdapter(var onOpen: (ChannelItem) -> Unit) : ListAdapter<ChannelRow, RecyclerView.ViewHolder>(ChannelRowDiff) {
    init { setHasStableIds(true) }
    fun submitContent(channels: List<ChannelItem>, emptyMessage: String) = submitList(
        if (channels.isEmpty()) listOf<ChannelRow>(ChannelRow.Empty(emptyMessage))
        else channels.map<ChannelItem, ChannelRow> { ChannelRow.Channel(it) }
    )
    override fun getItemId(position: Int) = getItem(position).id
    override fun getItemViewType(position: Int) = if (getItem(position) is ChannelRow.Channel) TYPE_CHANNEL else TYPE_EMPTY
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder =
        if (viewType == TYPE_CHANNEL) ChannelHolder(parent.context) else EmptyRowHolder(parent.context)
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = getItem(position)) {
            is ChannelRow.Channel -> (holder as ChannelHolder).bind(row.item, onOpen)
            is ChannelRow.Empty -> (holder as EmptyRowHolder).bind(row.message)
        }
    }
    companion object { const val TYPE_CHANNEL = 30; const val TYPE_EMPTY = 31 }
}

private class ChannelHolder(context: Context) : RecyclerView.ViewHolder(ChannelCardView(context)) {
    private val card = itemView as ChannelCardView
    fun bind(channel: ChannelItem, onOpen: (ChannelItem) -> Unit) {
        card.title.text = channel.title.ifBlank { "Canal" }
        card.description.text = channel.description
        card.description.visibility = if (channel.description.isBlank()) View.GONE else View.VISIBLE
        card.setOnClickListener { onOpen(channel) }
        loadAvatar(card.avatar, channel.thumbnailUrl, 120)
    }
}

private class ChannelCardView(context: Context) : LinearLayout(context) {
    val avatar = ImageView(context)
    val title = TextView(context)
    val description = TextView(context)
    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 78))
        setPadding(dp(context, 14), dp(context, 9), dp(context, 14), dp(context, 9))
        setBackgroundColor(Color.BLACK)
        avatar.scaleType = ImageView.ScaleType.CENTER_CROP
        addView(avatar, LayoutParams(dp(context, 56), dp(context, 56)))
        val texts = LinearLayout(context).apply {
            orientation = VERTICAL
            title.setTextColor(Color.WHITE)
            title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
            title.maxLines = 1
            title.ellipsize = TextUtils.TruncateAt.END
            description.setTextColor(0xFFAAA7B2.toInt())
            description.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            description.maxLines = 2
            description.ellipsize = TextUtils.TruncateAt.END
            addView(title)
            addView(description)
        }
        addView(texts, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(context, 14) })
        addView(TextView(context).apply {
            text = "›"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
            gravity = Gravity.CENTER
        }, LayoutParams(dp(context, 36), dp(context, 56)))
    }
}

private sealed interface PlayerRow {
    val id: Long
    data class Header(val data: PlayerHeaderData) : PlayerRow { override val id = Long.MIN_VALUE + 301 }
    data class Mix(val current: VideoItem, val seed: VideoItem) : PlayerRow { override val id = Long.MIN_VALUE + 302 }
    data class Related(val item: VideoItem) : PlayerRow { override val id = item.id.hashCode().toLong() }
    /** Tarjeta grande (como YouTube) para videos relacionados que no son de un Mix. */
    data class RelatedFull(val item: VideoItem) : PlayerRow { override val id = ("full:" + item.id).hashCode().toLong() }
    data object Loading : PlayerRow { override val id = Long.MIN_VALUE + 303 }
    data object More : PlayerRow { override val id = Long.MIN_VALUE + 304 }
    /** Filtros de relacionados ("Todos", "De este canal", "Relacionados"...). */
    data class Chips(val chips: List<HomeChip>, val selected: String) : PlayerRow { override val id = Long.MIN_VALUE + 305 }
}

private object PlayerRowDiff : DiffUtil.ItemCallback<PlayerRow>() {
    override fun areItemsTheSame(oldItem: PlayerRow, newItem: PlayerRow) = oldItem.id == newItem.id
    override fun areContentsTheSame(oldItem: PlayerRow, newItem: PlayerRow) = oldItem == newItem
}

private class NativePlayerAdapter(
    private var onLike: () -> Unit,
    private var onDislike: () -> Unit,
    private var onWatchLater: () -> Unit,
    private var onShare: () -> Unit,
    private var onQuality: () -> Unit,
    private var onDownload: () -> Unit,
    private var onToggleAudioOnly: () -> Unit,
    private var onPictureInPicture: () -> Unit,
    private var onOpenChannel: (ChannelItem) -> Unit,
    private var onPlayRelated: (VideoItem) -> Unit,
    private var onSaveRelated: (VideoItem) -> Unit,
    private var onDownloadRelated: (VideoItem) -> Unit,
    var onLoadMore: () -> Unit
) : ListAdapter<PlayerRow, RecyclerView.ViewHolder>(PlayerRowDiff) {
    var canLoadMore = false
    var loadingMore = false
    var onSelectChip: (HomeChip) -> Unit = {}
    var onToggleSubscribe: () -> Unit = {}
    var onOpenComments: () -> Unit = {}
    var onSeek: (Long) -> Unit = {}
    var onOpenQueue: () -> Unit = {}
    init { setHasStableIds(true) }

    fun updateCallbacks(
        like: () -> Unit, dislike: () -> Unit, later: () -> Unit, share: () -> Unit,
        quality: () -> Unit, download: () -> Unit,
        audioOnly: () -> Unit, pictureInPicture: () -> Unit,
        channel: (ChannelItem) -> Unit, play: (VideoItem) -> Unit,
        save: (VideoItem) -> Unit, downloadRelated: (VideoItem) -> Unit, load: () -> Unit
    ) {
        onLike = like; onDislike = dislike; onWatchLater = later; onShare = share
        onQuality = quality; onDownload = download
        onToggleAudioOnly = audioOnly; onPictureInPicture = pictureInPicture
        onOpenChannel = channel; onPlayRelated = play; onSaveRelated = save
        onDownloadRelated = downloadRelated; onLoadMore = load
    }

    fun submitContent(header: PlayerHeaderData, related: List<VideoItem>, loading: Boolean, loadingMore: Boolean, canLoadMore: Boolean) {
        this.loadingMore = loadingMore
        this.canLoadMore = canLoadMore
        submitList(buildList {
            add(PlayerRow.Header(header))
            if (!header.video.isMix && header.relatedChips.size > 1) {
                add(PlayerRow.Chips(header.relatedChips, header.selectedRelatedChip))
            }
            // La cola / Mix tiene su propio panel; abajo siempre van tarjetas grandes como YouTube.
            val compact = false
            related.forEach { add(if (compact) PlayerRow.Related(it) else PlayerRow.RelatedFull(it)) }
            if (loading || loadingMore) add(PlayerRow.Loading)
            else if (canLoadMore) add(PlayerRow.More)
        })
    }

    override fun getItemId(position: Int) = getItem(position).id
    override fun getItemViewType(position: Int): Int = when (getItem(position)) {
        is PlayerRow.Header -> TYPE_HEADER
        is PlayerRow.Mix -> TYPE_MIX
        is PlayerRow.Related -> TYPE_RELATED
        is PlayerRow.RelatedFull -> TYPE_RELATED_FULL
        PlayerRow.Loading -> TYPE_LOADING
        PlayerRow.More -> TYPE_MORE
        is PlayerRow.Chips -> TYPE_CHIPS
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder = when (viewType) {
        TYPE_HEADER -> PlayerHeaderHolder(parent.context)
        TYPE_MIX -> PlayerRelatedHolder(parent.context)
        TYPE_RELATED -> PlayerRelatedHolder(parent.context)
        TYPE_RELATED_FULL -> FullVideoHolder(parent.context)
        TYPE_LOADING -> LoadingRowHolder(parent.context)
        TYPE_CHIPS -> PlayerChipsHolder(parent.context)
        else -> MoreRowHolder(parent.context)
    }
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = getItem(position)) {
            is PlayerRow.Header -> (holder as PlayerHeaderHolder).bind(
                row.data, onLike, onDislike, onWatchLater, onShare,
                onQuality, onDownload, onToggleAudioOnly,
                onPictureInPicture, onOpenChannel,
                onToggleSubscribe = { onToggleSubscribe() },
                onOpenComments = { onOpenComments() },
                onSeek = { ms -> onSeek(ms) },
                onOpenQueue = { onOpenQueue() }
            )
            is PlayerRow.Chips -> (holder as PlayerChipsHolder).bind(row.chips, row.selected) { chip -> onSelectChip(chip) }
            is PlayerRow.Mix -> (holder as PlayerRelatedHolder).bind(
                row.seed.copy(
                    title = "Mix: ${row.current.title}",
                    channelTitle = listOf(row.current.channelTitle, row.seed.channelTitle)
                        .filter { it.isNotBlank() }
                        .distinct()
                        .joinToString(", ") + " y más"
                ),
                onPlay = { onPlayRelated(row.seed) },
                onDownload = { onDownloadRelated(row.seed) }
            )
            is PlayerRow.Related -> (holder as PlayerRelatedHolder).bind(
                row.item,
                onPlay = onPlayRelated,
                onDownload = onDownloadRelated
            )
            is PlayerRow.RelatedFull -> (holder as FullVideoHolder).bind(
                row.item,
                onPlay = onPlayRelated,
                onSave = onSaveRelated
            )
            PlayerRow.More -> (holder as MoreRowHolder).bind(onLoadMore)
            PlayerRow.Loading -> Unit
        }
    }
    override fun onViewRecycled(holder: RecyclerView.ViewHolder) {
        super.onViewRecycled(holder)
        if (holder is FullVideoHolder) holder.recycle()
    }
    companion object {
        const val TYPE_HEADER = 40
        const val TYPE_MIX = 41
        const val TYPE_RELATED = 42
        const val TYPE_LOADING = 43
        const val TYPE_MORE = 44
        const val TYPE_RELATED_FULL = 45
        const val TYPE_CHIPS = 46
    }
}

/** Fila de filtros como YouTube: píldoras grises, la elegida en blanco. */
private class PlayerChipsHolder(context: Context) : RecyclerView.ViewHolder(HorizontalScrollView(context)) {
    private val row = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(dp(context, 12), dp(context, 6), dp(context, 12), dp(context, 8))
    }

    init {
        (itemView as HorizontalScrollView).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setBackgroundColor(Color.BLACK)
            layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            addView(row)
        }
    }

    fun bind(chips: List<HomeChip>, selected: String, onSelect: (HomeChip) -> Unit) {
        val context = itemView.context
        row.removeAllViews()
        chips.forEachIndexed { index, chip ->
            val isSelected = chip.token == selected || (selected.isBlank() && index == 0)
            row.addView(TextView(context).apply {
                text = chip.title
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(if (isSelected) Color.BLACK else Color.WHITE)
                background = roundedDrawable(if (isSelected) Color.WHITE else 0xFF272727.toInt(), 8f, context)
                setPadding(dp(context, 12), 0, dp(context, 12), 0)
                isClickable = true
                setOnClickListener { if (!isSelected) onSelect(chip) }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(context, 32)).apply {
                marginEnd = dp(context, 8)
            })
        }
    }
}

private val TIMESTAMP_REGEX = Regex("\\b(?:(\\d{1,2}):)?(\\d{1,2}):(\\d{2})\\b")

/** Descripción como YouTube: enlaces y marcas de tiempo (1:23) que se pueden tocar. */
private fun descriptionSpannable(text: String, onSeek: (Long) -> Unit): CharSequence {
    val spannable = android.text.SpannableString(text)
    runCatching { android.text.util.Linkify.addLinks(spannable, android.text.util.Linkify.WEB_URLS) }
    TIMESTAMP_REGEX.findAll(text).forEach { match ->
        val hours = match.groupValues[1].toLongOrNull() ?: 0L
        val minutes = match.groupValues[2].toLongOrNull() ?: return@forEach
        val seconds = match.groupValues[3].toLongOrNull() ?: return@forEach
        if (seconds > 59) return@forEach
        val ms = ((hours * 3600L) + (minutes * 60L) + seconds) * 1000L
        spannable.setSpan(object : android.text.style.ClickableSpan() {
            override fun onClick(widget: View) = onSeek(ms)
            override fun updateDrawState(ds: android.text.TextPaint) {
                ds.color = 0xFF3EA6FF.toInt()
                ds.isUnderlineText = false
            }
        }, match.range.first, match.range.last + 1, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
    return spannable
}

private class PlayerHeaderHolder(context: Context) : RecyclerView.ViewHolder(PlayerHeaderView(context)) {
    private val view = itemView as PlayerHeaderView
    fun bind(
        data: PlayerHeaderData,
        onLike: () -> Unit,
        onDislike: () -> Unit,
        onWatchLater: () -> Unit,
        onShare: () -> Unit,
        onQuality: () -> Unit,
        onDownload: () -> Unit,
        onToggleAudioOnly: () -> Unit,
        onPictureInPicture: () -> Unit,
        onOpenChannel: (ChannelItem) -> Unit,
        onToggleSubscribe: () -> Unit = {},
        onOpenComments: () -> Unit = {},
        onSeek: (Long) -> Unit = {},
        onOpenQueue: () -> Unit = {}
    ) {
        val video = data.video
        view.title.text = video.title
        view.meta.text = buildList {
            data.details?.viewCount?.takeIf { it > 0 }?.let { add("${compactNumber(it)} visualizaciones") }
            formatRelativeTime(data.publishedAt).takeIf { it.isNotBlank() }?.let(::add)
        }.joinToString(" · ")
        view.channel.text = video.channelTitle.ifBlank { "Canal" }
        view.subscribers.text = data.details?.subscriberCount?.takeIf { it > 0 }?.let { "${compactNumber(it)} suscriptores" }.orEmpty()
        view.like.setLabel(data.details?.likeCount?.takeIf { it > 0 }?.let(::compactNumber) ?: "Me gusta")
        view.dislike.setLabel("No me gusta")
        view.watchLater.setLabel(if (data.isWatchLater) "Guardado" else "Ver después")
        view.share.setLabel("Compartir")
        view.quality.setLabel(data.qualityLabel)
        view.download.setLabel("Descargar")
        view.music.setLabel(if (data.audioOnly) "Volver al video" else "Reproducir música")
        view.window.setLabel("Ventana emergente")
        setActionSelected(view.like, data.isLiked)
        setActionSelected(view.dislike, data.isDisliked)
        setActionSelected(view.watchLater, data.isWatchLater)
        setActionSelected(view.music, data.audioOnly)
        val commentCount = data.details?.commentCount ?: 0L
        view.commentsTitle.text = if (commentCount > 0L) {
            "Comentarios ${compactNumber(commentCount)}"
        } else {
            "Comentarios"
        }
        view.commentsTab.text = if (commentCount > 0L) {
            "Comentarios ${compactNumber(commentCount)}"
        } else {
            "Comentarios"
        }
        // Panel de cola plegado (como YouTube): título del Mix y posición; al tocar se abre.
        view.mixBanner.visibility = if (data.mixAvailable) View.VISIBLE else View.GONE
        view.tabsRow.visibility = View.VISIBLE
        view.normalInfoContent.visibility = View.VISIBLE
        view.mixBanner.text = if (data.mixAvailable) {
            val mixTitle = data.queueTitle.ifBlank { "Mix" }.take(60)
            val total = data.mixCount.coerceAtLeast(1)
            val position = data.queuePosition.coerceIn(1, total)
            buildString {
                append(mixTitle)
                append("\n")
                if (data.queueSubtitle.isNotBlank()) append(data.queueSubtitle).append(" · ")
                append("$position/$total   ·   Ver la cola ⌄")
            }
        } else {
            ""
        }
        view.mixBanner.setOnClickListener { onOpenQueue() }
        view.description.text = descriptionSpannable(data.description, onSeek)
        view.description.movementMethod = android.text.method.LinkMovementMethod.getInstance()
        view.description.linksClickable = true
        view.descriptionToggle.visibility = if (data.description.isBlank()) View.GONE else View.VISIBLE
        if (view.boundVideoId != video.id) {
            view.boundVideoId = video.id
            view.descriptionBox.visibility = View.GONE
            view.showInfo()
        }
        val expandedNow = view.descriptionBox.visibility == View.VISIBLE
        view.descriptionToggle.text = if (expandedNow) "Descripción   Menos" else "Descripción   Más"
        val toggleDescription = View.OnClickListener {
            if (data.description.isBlank()) return@OnClickListener
            val expanded = view.descriptionBox.visibility == View.VISIBLE
            view.descriptionBox.visibility = if (expanded) View.GONE else View.VISIBLE
            view.descriptionToggle.text = if (expanded) "Descripción   Más" else "Descripción   Menos"
        }
        view.descriptionToggle.setOnClickListener(toggleDescription)
        view.meta.setOnClickListener(toggleDescription)
        view.title.setOnClickListener(toggleDescription)
        bindCommentPreview(view.commentsBox, data.details?.comments.orEmpty())
        view.infoTab.setOnClickListener { view.showInfo() }
        // Como YouTube: los comentarios se abren en una hoja con orden, respuestas y "más".
        view.commentsTab.setOnClickListener { onOpenComments() }
        view.commentsBox.setOnClickListener { onOpenComments() }
        view.commentsRow.setOnClickListener { onOpenComments() }
        view.commentsHint.setOnClickListener { view.showInfo() }
        view.like.setOnClickListener { onLike() }
        view.dislike.setOnClickListener { onDislike() }
        view.watchLater.setOnClickListener { onWatchLater() }
        view.share.setOnClickListener { onShare() }
        view.quality.setOnClickListener { onQuality() }
        view.download.setOnClickListener { onDownload() }
        view.music.setOnClickListener { onToggleAudioOnly() }
        view.window.setOnClickListener { onPictureInPicture() }
        view.channelButton.visibility = if (video.channelId.isBlank()) View.GONE else View.VISIBLE
        // Píldora de YouTube: "Suscribirse" en blanco, "Suscrito" en gris con campana.
        view.channelButton.text = if (data.isSubscribed) "\uD83D\uDD14  Suscrito  ⌄" else "Suscribirse"
        view.channelButton.setTextColor(if (data.isSubscribed) Color.WHITE else Color.BLACK)
        view.channelButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
        view.channelButton.background = roundedDrawable(
            if (data.isSubscribed) 0xFF272727.toInt() else Color.WHITE,
            18f,
            view.context
        )
        view.channelButton.setPadding(dp(view.context, 14), 0, dp(view.context, 14), 0)
        val openChannel = View.OnClickListener {
            if (video.channelId.isNotBlank()) {
                onOpenChannel(ChannelItem(video.channelId, video.channelTitle, data.channelAvatar))
            }
        }
        view.channelButton.setOnClickListener { onToggleSubscribe() }
        view.avatar.setOnClickListener(openChannel)
        view.channel.setOnClickListener(openChannel)
        view.subscribers.setOnClickListener(openChannel)
        loadAvatar(view.avatar, data.channelAvatar, 112)
    }
}

private class PlayerHeaderView(context: Context) : LinearLayout(context) {
    val infoTab = TextView(context)
    val commentsTab = TextView(context)
    val tabsRow = LinearLayout(context)
    val normalInfoContent = LinearLayout(context)
    private val infoPanel = LinearLayout(context)
    private val commentsPanel = LinearLayout(context)
    private val relatedTitle = TextView(context)

    val title = TextView(context)
    val meta = TextView(context)
    val avatar = ImageView(context)
    val channel = TextView(context)
    val subscribers = TextView(context)
    val channelButton = TextView(context)
    var boundVideoId: String = ""
    val like = PlayerActionView(context, com.geovideos.app.R.drawable.ic_short_like, "Me gusta")
    val dislike = PlayerActionView(context, com.geovideos.app.R.drawable.ic_short_dislike, "No me gusta")
    val watchLater = PlayerActionView(context, com.geovideos.app.R.drawable.ic_short_save, "Ver después")
    val share = PlayerActionView(context, com.geovideos.app.R.drawable.ic_short_share, "Compartir")
    val quality = PlayerActionView(context, com.geovideos.app.R.drawable.ic_player_quality, "Calidad")
    val download = PlayerActionView(context, com.geovideos.app.R.drawable.ic_player_download, "Descargar")
    val music = PlayerActionView(context, com.geovideos.app.R.drawable.ic_player_music, "Reproducir música")
    val window = PlayerActionView(context, com.geovideos.app.R.drawable.ic_player_window, "Ventana emergente")
    val commentsRow = LinearLayout(context)
    val commentsTitle = TextView(context)
    val commentsHint = TextView(context)
    val commentsBox = LinearLayout(context)
    val mixBanner = TextView(context)
    val descriptionToggle = TextView(context)
    val descriptionBox = LinearLayout(context)
    val description = TextView(context)

    init {
        orientation = VERTICAL
        layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setPadding(dp(context, 10), dp(context, 0), dp(context, 10), dp(context, 8))
        setBackgroundColor(Color.BLACK)

        tabsRow.orientation = HORIZONTAL
        tabsRow.gravity = Gravity.CENTER_VERTICAL
        tabsRow.setPadding(0, 0, 0, dp(context, 2))
        stylePlayerTab(infoTab, "Info")
        stylePlayerTab(commentsTab, "Comentarios")
        tabsRow.addView(infoTab, LayoutParams(dp(context, 72), dp(context, 36)))
        tabsRow.addView(commentsTab, LayoutParams(dp(context, 150), dp(context, 36)).apply { marginStart = dp(context, 6) })
        addView(tabsRow, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        infoPanel.orientation = VERTICAL
        normalInfoContent.orientation = VERTICAL

        mixBanner.setTextColor(Color.WHITE)
        mixBanner.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
        mixBanner.setTypeface(mixBanner.typeface, android.graphics.Typeface.BOLD)
        mixBanner.setLineSpacing(dp(context, 2).toFloat(), 1f)
        mixBanner.setPadding(dp(context, 10), dp(context, 8), dp(context, 10), dp(context, 8))
        mixBanner.background = roundedDrawable(0xFF1B1B1F.toInt(), 3f, context)
        mixBanner.visibility = View.GONE
        infoPanel.addView(mixBanner, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(context, 6) })

        title.setTextColor(Color.WHITE)
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17.5f)
        title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
        title.maxLines = 2
        title.ellipsize = TextUtils.TruncateAt.END
        normalInfoContent.addView(title)

        meta.setTextColor(0xFFAAA7B2.toInt())
        meta.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
        normalInfoContent.addView(meta, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(context, 3) })

        val channelRow = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        avatar.scaleType = ImageView.ScaleType.CENTER_CROP
        channelRow.addView(avatar, LayoutParams(dp(context, 42), dp(context, 42)))
        val channelTexts = LinearLayout(context).apply {
            orientation = VERTICAL
            channel.setTextColor(Color.WHITE)
            channel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
            channel.setTypeface(channel.typeface, android.graphics.Typeface.BOLD)
            channel.maxLines = 1
            subscribers.setTextColor(0xFFAAA7B2.toInt())
            subscribers.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            addView(channel)
            addView(subscribers)
        }
        channelRow.addView(channelTexts, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(context, 11) })
        styleAction(context, channelButton, "Canal")
        channelRow.addView(channelButton, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(context, 36)))
        normalInfoContent.addView(channelRow, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(context, 9) })
        normalInfoContent.addView(
            View(context).apply { setBackgroundColor(0xFF343238.toInt()) },
            LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 1)).apply { topMargin = dp(context, 8) }
        )

        val scroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val actions = LinearLayout(context).apply { orientation = HORIZONTAL }
        listOf(like, share, watchLater, download, quality, window).forEach { item ->
            actions.addView(item, LinearLayout.LayoutParams(dp(context, 68), dp(context, 64)))
        }
        scroll.addView(actions)
        normalInfoContent.addView(scroll, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 66)).apply { topMargin = dp(context, 4) })

        descriptionToggle.setTextColor(Color.WHITE)
        descriptionToggle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        descriptionToggle.setTypeface(descriptionToggle.typeface, android.graphics.Typeface.BOLD)
        descriptionToggle.gravity = Gravity.CENTER_VERTICAL
        descriptionToggle.setPadding(dp(context, 11), dp(context, 8), dp(context, 11), dp(context, 8))
        descriptionToggle.background = roundedDrawable(0xFF1D1B22.toInt(), 12f, context)
        normalInfoContent.addView(descriptionToggle, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(context, 5) })

        descriptionBox.orientation = VERTICAL
        descriptionBox.setPadding(dp(context, 11), dp(context, 9), dp(context, 11), dp(context, 9))
        descriptionBox.background = roundedDrawable(0xFF17151B.toInt(), 12f, context)
        description.setTextColor(0xFFC8C5CE.toInt())
        description.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
        description.maxLines = Int.MAX_VALUE
        description.ellipsize = null
        descriptionBox.addView(description, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        descriptionBox.visibility = View.GONE
        normalInfoContent.addView(descriptionBox, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(context, 5) })
        infoPanel.addView(normalInfoContent, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addView(infoPanel, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        commentsPanel.orientation = VERTICAL
        commentsRow.orientation = HORIZONTAL
        commentsRow.gravity = Gravity.CENTER_VERTICAL
        commentsRow.setPadding(dp(context, 13), dp(context, 10), dp(context, 13), dp(context, 10))
        commentsRow.background = roundedDrawable(0xFF1D1B22.toInt(), 12f, context)
        commentsTitle.setTextColor(Color.WHITE)
        commentsTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        commentsTitle.setTypeface(commentsTitle.typeface, android.graphics.Typeface.BOLD)
        commentsHint.text = "Volver a información"
        commentsHint.setTextColor(0xFF9D6CFF.toInt())
        commentsHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        commentsHint.setTypeface(commentsHint.typeface, android.graphics.Typeface.BOLD)
        commentsRow.addView(commentsTitle, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        commentsRow.addView(commentsHint)
        commentsPanel.addView(commentsRow, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        commentsBox.orientation = VERTICAL
        commentsBox.setPadding(dp(context, 11), dp(context, 6), dp(context, 11), dp(context, 8))
        commentsBox.background = roundedDrawable(0xFF151419.toInt(), 12f, context)
        commentsPanel.addView(commentsBox, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(context, 6) })
        commentsPanel.visibility = View.GONE
        addView(commentsPanel, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        relatedTitle.text = "Videos relacionados"
        relatedTitle.setTextColor(Color.WHITE)
        relatedTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 21f)
        relatedTitle.setTypeface(relatedTitle.typeface, android.graphics.Typeface.BOLD)
        relatedTitle.setPadding(0, dp(context, 18), 0, dp(context, 8))
        addView(relatedTitle)
    }

    fun showInfo() {
        infoPanel.visibility = View.VISIBLE
        commentsPanel.visibility = View.GONE
        relatedTitle.visibility = View.GONE
        setTabSelected(infoTab, true)
        setTabSelected(commentsTab, false)
    }

    fun showComments() {
        infoPanel.visibility = View.GONE
        commentsPanel.visibility = View.VISIBLE
        relatedTitle.visibility = View.GONE
        setTabSelected(infoTab, false)
        setTabSelected(commentsTab, true)
    }

    private fun stylePlayerTab(view: TextView, textValue: String) {
        view.text = textValue
        view.gravity = Gravity.CENTER
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        view.setTypeface(view.typeface, android.graphics.Typeface.BOLD)
        view.background = null
        view.isClickable = true
        view.isFocusable = true
    }

    private fun setTabSelected(view: TextView, selected: Boolean) {
        view.setTextColor(if (selected) 0xFF9D6CFF.toInt() else 0xFFA8A4AF.toInt())
        view.background = null
        view.paintFlags = if (selected) {
            view.paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
        } else {
            view.paintFlags and android.graphics.Paint.UNDERLINE_TEXT_FLAG.inv()
        }
    }
}


private fun bindCommentPreview(container: LinearLayout, comments: List<CommentItem>) {
    val context = container.context
    container.removeAllViews()
    if (comments.isEmpty()) {
        container.addView(TextView(context).apply {
            text = "No hay comentarios disponibles para mostrar."
            setTextColor(0xFFB9B5C0.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(dp(context, 2), dp(context, 8), dp(context, 2), dp(context, 8))
        })
        return
    }
    comments.take(5).forEachIndexed { index, comment ->
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            setPadding(0, dp(context, 8), 0, dp(context, 8))
        }
        val avatar = ImageView(context).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        row.addView(avatar, LinearLayout.LayoutParams(dp(context, 34), dp(context, 34)))
        val texts = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply {
                text = comment.author.ifBlank { "Usuario" }
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            addView(TextView(context).apply {
                text = comment.text
                setTextColor(0xFFD0CCD6.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                maxLines = 4
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(context, 3), 0, 0)
            })
            val metaText = buildList {
                formatRelativeTime(comment.publishedAt).takeIf { it.isNotBlank() }?.let(::add)
                comment.likeCount.takeIf { it > 0L }?.let { add("${compactNumber(it)} Me gusta") }
            }.joinToString(" · ")
            if (metaText.isNotBlank()) {
                addView(TextView(context).apply {
                    text = metaText
                    setTextColor(0xFF8F8B96.toInt())
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                    setPadding(0, dp(context, 4), 0, 0)
                })
            }
        }
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(context, 10)
        })
        container.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        loadAvatar(avatar, comment.authorThumbnailUrl, 72)
        if (index < comments.take(5).lastIndex) {
            container.addView(View(context).apply { setBackgroundColor(0xFF2A2830.toInt()) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 1)))
        }
    }
}

private class LoadingRowHolder(context: Context) : RecyclerView.ViewHolder(FrameLayout(context).apply {
    layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 88))
    setBackgroundColor(Color.BLACK)
    addView(ProgressBar(context), FrameLayout.LayoutParams(dp(context, 34), dp(context, 34), Gravity.CENTER))
})

private class EmptyRowHolder(context: Context) : RecyclerView.ViewHolder(TextView(context).apply {
    layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 120))
    gravity = Gravity.CENTER
    setTextColor(0xFFB6B3BE.toInt())
    setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
    setBackgroundColor(Color.BLACK)
    setPadding(dp(context, 18), dp(context, 18), dp(context, 18), dp(context, 18))
}) {
    private val text = itemView as TextView
    fun bind(message: String) { text.text = message }
}

private class MoreRowHolder(context: Context) : RecyclerView.ViewHolder(TextView(context).apply {
    layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 64))
    gravity = Gravity.CENTER
    text = "Cargar más"
    setTextColor(0xFF9D6CFF.toInt())
    setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
    setTypeface(typeface, android.graphics.Typeface.BOLD)
    setBackgroundColor(Color.BLACK)
}) {
    private val button = itemView as TextView
    fun bind(onLoadMore: () -> Unit) { button.setOnClickListener { onLoadMore() } }
}

private class NativeSixteenNineFrame(context: Context) : FrameLayout(context) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        super.onMeasure(
            MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec((width * 9f / 16f).toInt(), MeasureSpec.EXACTLY)
        )
    }
}

private fun loadThumbnail(view: ImageView, url: String, width: Int, height: Int) {
    val manager = Glide.with(view)
    val placeholder = ColorDrawable(0xFF202024.toInt())
    if (!isYoutubeThumbnailList(url)) {
        manager.load(url)
            .override(width, height)
            .dontAnimate()
            .placeholder(placeholder)
            .error(ColorDrawable(0xFF2B1B45.toInt()))
            .centerCrop()
            .into(view)
        return
    }

    val low = manager.load(youtubeThumbnailList(url, "mqdefault.jpg"))
        .override(320, 180)
        .dontAnimate()
        .centerCrop()
    val highFallback = manager.load(youtubeThumbnailList(url, "hqdefault.jpg"))
        .override(width, height)
        .dontAnimate()
        .centerCrop()
        .error(low)
    manager.load(youtubeThumbnailList(url, "sddefault.jpg"))
        .override(width, height)
        .dontAnimate()
        .placeholder(placeholder)
        .thumbnail(low)
        .error(highFallback)
        .centerCrop()
        .into(view)
}

private fun loadAvatar(view: ImageView, url: String, size: Int = 96) {
    if (url.isBlank()) {
        Glide.with(view).clear(view)
        view.setImageDrawable(ColorDrawable(0xFF303036.toInt()))
        return
    }
    Glide.with(view)
        .load(url)
        .override(size, size)
        .dontAnimate()
        .placeholder(ColorDrawable(0xFF303036.toInt()))
        .error(ColorDrawable(0xFF303036.toInt()))
        .circleCrop()
        .into(view)
}

private fun isYoutubeThumbnailList(url: String): Boolean =
    url.contains("ytimg.com", ignoreCase = true) ||
        url.contains("youtube.com", ignoreCase = true)

private fun youtubeThumbnailList(url: String, fileName: String): String =
    url.replace(Regex("(maxresdefault|sddefault|hqdefault|mqdefault|default)\\.jpg"), fileName)

private fun durationText(ms: Long): String {
    if (ms <= 0L) return ""
    val total = ms / 1000L
    val h = total / 3600L
    val m = (total % 3600L) / 60L
    val s = total % 60L
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

private fun formatRelativeTime(value: String): String {
    if (value.isBlank()) return ""
    if (value.contains("hace", true)) return value
    return runCatching {
        val instant = Instant.parse(value)
        val elapsed = max(0L, Instant.now().epochSecond - instant.epochSecond)
        when {
            elapsed < 3_600 -> "hace ${max(1L, elapsed / 60)} min"
            elapsed < 86_400 -> "hace ${elapsed / 3_600} h"
            elapsed < 604_800 -> "hace ${elapsed / 86_400} días"
            elapsed < 2_592_000 -> "hace ${elapsed / 604_800} semanas"
            elapsed < 31_536_000 -> "hace ${elapsed / 2_592_000} meses"
            else -> "hace ${elapsed / 31_536_000} años"
        }
    }.getOrElse { value.take(10) }
}

private fun compactNumber(value: Long): String = when {
    value >= 1_000_000_000 -> "%.1f mil M".format(value / 1_000_000_000.0).replace(".0", "")
    value >= 1_000_000 -> "%.1f M".format(value / 1_000_000.0).replace(".0", "")
    value >= 1_000 -> "%.1f K".format(value / 1_000.0).replace(".0", "")
    else -> value.toString()
}


private class PlayerActionView(context: Context, iconRes: Int, label: String) : LinearLayout(context) {
    private val icon = ImageView(context)
    private val labelView = TextView(context)

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        isClickable = true
        isFocusable = true
        icon.setImageResource(iconRes)
        icon.setColorFilter(Color.WHITE)
        addView(icon, LayoutParams(dp(context, 23), dp(context, 23)))
        labelView.text = label
        labelView.gravity = Gravity.CENTER
        labelView.setTextColor(Color.WHITE)
        labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f)
        labelView.maxLines = 2
        labelView.ellipsize = TextUtils.TruncateAt.END
        addView(labelView, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(context, 6)
        })
    }

    fun setLabel(value: String) {
        labelView.text = value
    }

    fun setSelectedState(selected: Boolean) {
        isSelected = selected
        val color = if (selected) 0xFF9D6CFF.toInt() else Color.WHITE
        icon.setColorFilter(color)
        labelView.setTextColor(color)
    }
}

private fun setActionSelected(view: PlayerActionView, selected: Boolean) {
    view.setSelectedState(selected)
}

private fun styleAction(context: Context, view: TextView, text: String) {
    view.text = text
    view.gravity = Gravity.CENTER
    view.setTextColor(0xFFB8B5BF.toInt())
    view.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
    view.setTypeface(view.typeface, android.graphics.Typeface.BOLD)
    view.setPadding(dp(context, 12), 0, dp(context, 12), 0)
    view.background = null
    view.isClickable = true
    view.isFocusable = true
}

private fun roundedDrawable(color: Int, radiusDp: Float, context: Context, stroke: Int? = null): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusDp * context.resources.displayMetrics.density
        stroke?.let { setStroke(dp(context, 1), it) }
    }

private fun dp(context: Context, value: Int): Int =
    (value * context.resources.displayMetrics.density).toInt()
