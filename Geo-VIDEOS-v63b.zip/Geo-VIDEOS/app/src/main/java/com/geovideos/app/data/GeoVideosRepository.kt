package com.geovideos.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class GeoVideosRepository(context: Context) {
    private val preferences = context.getSharedPreferences("geo_videos_v4", Context.MODE_PRIVATE)
    private val accountPreferences = context.getSharedPreferences(AUTH_PREFS_NAME, Context.MODE_PRIVATE)

    init {
        migrateLegacyAccountState()
        migrateAccountFeedSchema()
    }

    private fun migrateAccountFeedSchema() {
        val current = preferences.getInt(KEY_FEED_SCHEMA, 0)
        if (current >= FEED_SCHEMA_VERSION) return
        // V50.6 todavía podía conservar Me gusta/historial dentro de Principal y conservar
        // Shorts mal clasificados en el feed normal. Invalidar solo el cache remoto una vez;
        // no tocar cuenta, historial, descargas, ajustes ni acciones locales.
        preferences.edit()
            .remove(KEY_PERSONALIZED)
            .remove(KEY_POPULAR)
            .remove(KEY_SHORTS)
            .remove(KEY_LAST_SYNC)
            .putInt(KEY_FEED_SCHEMA, FEED_SCHEMA_VERSION)
            .apply()
    }

    fun loadHistory(): List<VideoItem> {
        val storageKey = historyStorageKey()
        preferences.getString(storageKey, null)?.let { return decodeVideos(it) }

        // Migrar una sola vez el historial local de versiones anteriores a la cuenta Google
        // actualmente conectada. Asi cambiar de cuenta no mezcla reproducciones entre usuarios.
        if (storageKey != KEY_HISTORY) {
            val legacy = preferences.getString(KEY_HISTORY, null)
            if (!legacy.isNullOrBlank()) {
                preferences.edit()
                    .putString(storageKey, legacy)
                    .remove(KEY_HISTORY)
                    .apply()
                return decodeVideos(legacy)
            }
        }
        return emptyList()
    }
    fun loadWatchLater(): List<VideoItem> = decodeVideos(preferences.getString(KEY_WATCH_LATER, "[]").orEmpty())
    fun loadDownloads(): List<VideoItem> = decodeVideos(preferences.getString(KEY_DOWNLOADS, "[]").orEmpty())
    fun loadSearchHistory(): List<String> = decodeStrings(preferences.getString(KEY_SEARCH_HISTORY, "[]").orEmpty())
    fun loadLocalLikedIds(): Set<String> = preferences.getStringSet(KEY_LOCAL_LIKES, emptySet()).orEmpty().toSet()
    fun loadLocalDislikedIds(): Set<String> = preferences.getStringSet(KEY_LOCAL_DISLIKES, emptySet()).orEmpty().toSet()
    fun loadLocalLikedVideos(): List<VideoItem> = loadVideos(KEY_LOCAL_LIKED_VIDEOS)

    fun loadAutoplay(): Boolean = preferences.getBoolean(KEY_AUTOPLAY, true)
    fun loadDataSaver(): Boolean = preferences.getBoolean(KEY_DATA_SAVER, false)
    fun loadNotificationsEnabled(): Boolean = preferences.getBoolean(KEY_NOTIFICATIONS, true)
    fun hasConnectedAccount(): Boolean = accountPreferences.getBoolean(KEY_CONNECTED_ACCOUNT, false)
    fun loadLastSyncMs(): Long = preferences.getLong(KEY_LAST_SYNC, 0L)
    fun loadYouTubeSyncEnabled(): Boolean = preferences.getBoolean(KEY_YOUTUBE_SYNC_ENABLED, false)
    fun loadGeoWatchLaterPlaylistId(): String = preferences.getString(KEY_GEO_WATCH_LATER_PLAYLIST, "").orEmpty()

    fun loadProfile(): GoogleProfile? = decodeProfile(
        accountPreferences.getString(KEY_PROFILE, null)
    )

    fun saveConnectedProfile(profile: GoogleProfile) {
        val email = profile.email.trim()
        if (email.isBlank()) return
        val profileJson = JSONObject()
            .put("name", profile.name.trim())
            .put("email", email)
            .put("pictureUrl", profile.pictureUrl.trim())
            .put("channelTitle", profile.channelTitle.trim())
            .put("channelId", profile.channelId.trim())
        accountPreferences.edit()
            .putString(KEY_PROFILE, profileJson.toString())
            .putBoolean(KEY_CONNECTED_ACCOUNT, true)
            .apply()
    }

    fun loadPersonalized(): List<VideoItem> = loadVideos(KEY_PERSONALIZED)
    fun loadPopular(): List<VideoItem> = loadVideos(KEY_POPULAR)
    fun loadLive(): List<VideoItem> = loadVideos(KEY_LIVE)
    fun loadGaming(): List<VideoItem> = loadVideos(KEY_GAMING)
    fun loadMusic(): List<VideoItem> = loadVideos(KEY_MUSIC)
    fun loadShorts(): List<VideoItem> = loadVideos(KEY_SHORTS)
    fun loadLiked(): List<VideoItem> = loadVideos(KEY_LIKED)
    fun loadUploads(): List<VideoItem> = loadVideos(KEY_UPLOADS)
    fun loadSubscriptions(): List<ChannelItem> = decodeChannels(preferences.getString(KEY_SUBSCRIPTIONS, "[]").orEmpty())
    fun loadPlaylists(): List<PlaylistItem> = decodePlaylists(preferences.getString(KEY_PLAYLISTS, "[]").orEmpty())
    fun loadNotifications(): List<NotificationItem> = decodeNotifications(preferences.getString(KEY_REMOTE_NOTIFICATIONS, "[]").orEmpty())

    fun loadChannelAvatars(): Map<String, String> = runCatching {
        val json = JSONObject(preferences.getString(KEY_CHANNEL_AVATARS, "{}").orEmpty().ifBlank { "{}" })
        buildMap {
            val keys = json.keys()
            while (keys.hasNext()) {
                val channelId = keys.next()
                val url = json.optString(channelId)
                if (channelId.isNotBlank() && url.isNotBlank()) put(channelId, url)
            }
        }
    }.getOrDefault(emptyMap())

    fun saveChannelAvatars(avatars: Map<String, String>) {
        if (avatars.isEmpty()) return
        val merged = LinkedHashMap(loadChannelAvatars())
        avatars.forEach { (channelId, url) ->
            if (channelId.isNotBlank() && url.isNotBlank()) merged[channelId] = url
        }
        while (merged.size > MAX_CHANNEL_AVATARS) {
            merged.remove(merged.keys.first())
        }
        val json = JSONObject()
        merged.forEach { (channelId, url) -> json.put(channelId, url) }
        preferences.edit().putString(KEY_CHANNEL_AVATARS, json.toString()).apply()
    }

    fun setAutoplay(value: Boolean) {
        preferences.edit().putBoolean(KEY_AUTOPLAY, value).apply()
    }

    fun setDataSaver(value: Boolean) {
        preferences.edit().putBoolean(KEY_DATA_SAVER, value).apply()
    }

    fun setNotificationsEnabled(value: Boolean) {
        preferences.edit().putBoolean(KEY_NOTIFICATIONS, value).apply()
    }

    fun markConnected(value: Boolean) {
        accountPreferences.edit().putBoolean(KEY_CONNECTED_ACCOUNT, value).apply()
    }

    fun setYouTubeSyncEnabled(value: Boolean) {
        preferences.edit().putBoolean(KEY_YOUTUBE_SYNC_ENABLED, value).apply()
    }

    fun saveGeoWatchLaterPlaylistId(value: String) {
        preferences.edit().putString(KEY_GEO_WATCH_LATER_PLAYLIST, value).apply()
    }

    fun clearYouTubeSyncAccountBinding() {
        preferences.edit()
            .putBoolean(KEY_YOUTUBE_SYNC_ENABLED, false)
            .remove(KEY_GEO_WATCH_LATER_PLAYLIST)
            .apply()
    }

    fun saveSubscriptions(channels: List<ChannelItem>) {
        preferences.edit().putString(KEY_SUBSCRIPTIONS, encodeChannels(channels).toString()).apply()
    }

    fun saveLikedVideos(videos: List<VideoItem>) {
        preferences.edit().putString(KEY_LIKED, encodeVideos(videos).toString()).apply()
    }

    fun saveRemoteSnapshot(
        profile: GoogleProfile,
        personalized: List<VideoItem>,
        popular: List<VideoItem>,
        live: List<VideoItem>,
        gaming: List<VideoItem>,
        music: List<VideoItem>,
        shorts: List<VideoItem>,
        liked: List<VideoItem>,
        uploads: List<VideoItem>,
        subscriptions: List<ChannelItem>,
        playlists: List<PlaylistItem>,
        notifications: List<NotificationItem>,
        syncTimeMs: Long = System.currentTimeMillis()
    ) {
        val profileJson = JSONObject()
            .put("name", profile.name)
            .put("email", profile.email)
            .put("pictureUrl", profile.pictureUrl)
            .put("channelTitle", profile.channelTitle)
            .put("channelId", profile.channelId)

        accountPreferences.edit()
            .putString(KEY_PROFILE, profileJson.toString())
            .putBoolean(KEY_CONNECTED_ACCOUNT, true)
            .apply()

        preferences.edit()
            .remove(KEY_PROFILE)
            .remove(KEY_CONNECTED_ACCOUNT)
            .putString(KEY_PERSONALIZED, encodeVideos(personalized).toString())
            .putString(KEY_POPULAR, encodeVideos(popular).toString())
            .putString(KEY_LIVE, encodeVideos(live).toString())
            .putString(KEY_GAMING, encodeVideos(gaming).toString())
            .putString(KEY_MUSIC, encodeVideos(music).toString())
            .putString(KEY_SHORTS, encodeVideos(shorts).toString())
            .putString(KEY_LIKED, encodeVideos(liked).toString())
            .putString(KEY_UPLOADS, encodeVideos(uploads).toString())
            .putString(KEY_SUBSCRIPTIONS, encodeChannels(subscriptions).toString())
            .putString(KEY_PLAYLISTS, encodePlaylists(playlists).toString())
            .putString(KEY_REMOTE_NOTIFICATIONS, encodeNotifications(notifications).toString())
            .putLong(KEY_LAST_SYNC, syncTimeMs)
            .apply()
    }

    fun addToHistory(video: VideoItem): List<VideoItem> {
        val previous = loadHistory().firstOrNull { it.id == video.id }
        val merged = video.copy(
            resumePositionMs = if (video.resumePositionMs > 0L) video.resumePositionMs else previous?.resumePositionMs ?: 0L,
            durationMs = if (video.durationMs > 0L) video.durationMs else previous?.durationMs ?: 0L,
            watchedAtMs = System.currentTimeMillis()
        )
        val updated = loadHistory().filterNot { it.id == video.id }.toMutableList()
        updated.add(0, merged)
        return updated.take(MAX_HISTORY_ITEMS).also(::saveHistory)
    }

    fun updatePlayback(video: VideoItem, positionMs: Long, durationMs: Long): List<VideoItem> {
        val previousHistory = loadHistory()
        val previous = previousHistory.firstOrNull { it.id == video.id }
        val safePosition = positionMs.coerceAtLeast(0L)
        val safeDuration = when {
            durationMs > 0L -> durationMs
            video.durationMs > 0L -> video.durationMs
            else -> previous?.durationMs ?: 0L
        }
        val normalizedPosition = if (safeDuration > 0L && safePosition >= safeDuration - 8_000L) 0L else safePosition
        val current = previousHistory.filterNot { it.id == video.id }.toMutableList()
        current.add(
            0,
            video.copy(
                resumePositionMs = normalizedPosition,
                durationMs = safeDuration,
                watchedAtMs = System.currentTimeMillis()
            )
        )
        return current.take(MAX_HISTORY_ITEMS).also(::saveHistory)
    }

    fun removeFromHistory(videoId: String): List<VideoItem> {
        val updated = loadHistory().filterNot { it.id == videoId }
        saveHistory(updated)
        return updated
    }

    fun toggleWatchLater(video: VideoItem): List<VideoItem> {
        val current = loadWatchLater().toMutableList()
        val existing = current.indexOfFirst { it.id == video.id }
        if (existing >= 0) current.removeAt(existing) else current.add(0, video)
        return current.take(150).also { saveVideos(KEY_WATCH_LATER, it) }
    }


    fun toggleLocalLike(video: VideoItem): Triple<Set<String>, Set<String>, List<VideoItem>> {
        val videoId = video.id
        val likes = loadLocalLikedIds().toMutableSet()
        val dislikes = loadLocalDislikedIds().toMutableSet()
        val localVideos = loadLocalLikedVideos().filterNot { it.id == videoId }.toMutableList()
        if (likes.add(videoId)) {
            localVideos.add(0, video)
        } else {
            likes.remove(videoId)
        }
        dislikes.remove(videoId)
        preferences.edit()
            .putStringSet(KEY_LOCAL_LIKES, likes)
            .putStringSet(KEY_LOCAL_DISLIKES, dislikes)
            .putString(KEY_LOCAL_LIKED_VIDEOS, encodeVideos(localVideos.take(250)).toString())
            .apply()
        return Triple(likes, dislikes, localVideos.take(250))
    }

    fun toggleLocalDislike(videoId: String): Triple<Set<String>, Set<String>, List<VideoItem>> {
        val likes = loadLocalLikedIds().toMutableSet()
        val dislikes = loadLocalDislikedIds().toMutableSet()
        val localVideos = loadLocalLikedVideos().filterNot { it.id == videoId }
        if (!dislikes.add(videoId)) dislikes.remove(videoId)
        likes.remove(videoId)
        preferences.edit()
            .putStringSet(KEY_LOCAL_LIKES, likes)
            .putStringSet(KEY_LOCAL_DISLIKES, dislikes)
            .putString(KEY_LOCAL_LIKED_VIDEOS, encodeVideos(localVideos).toString())
            .apply()
        return Triple(likes, dislikes, localVideos)
    }

    fun addDownload(title: String, url: String, downloadId: Long): List<VideoItem> {
        val item = VideoItem(
            id = "download-$downloadId",
            title = title.ifBlank { "Video descargado" },
            channelTitle = "Descarga directa",
            thumbnailUrl = "",
            mediaKind = MediaKind.DIRECT,
            source = url,
            downloadId = downloadId
        )
        val updated = loadDownloads()
            .filterNot { it.downloadId == downloadId }
            .toMutableList()
            .apply { add(0, item) }
            .take(100)
        saveVideos(KEY_DOWNLOADS, updated)
        return updated
    }

    fun removeDownload(downloadId: Long): List<VideoItem> {
        val updated = loadDownloads().filterNot { it.downloadId == downloadId }
        saveVideos(KEY_DOWNLOADS, updated)
        return updated
    }

    fun removeSearch(query: String): List<String> {
        val updated = loadSearchHistory().filterNot { it.equals(query.trim(), true) }
        saveStrings(KEY_SEARCH_HISTORY, updated)
        return updated
    }

    fun addSearch(query: String): List<String> {
        val clean = query.trim()
        if (clean.isBlank()) return loadSearchHistory()
        val updated = loadSearchHistory().filterNot { it.equals(clean, true) }.toMutableList()
        updated.add(0, clean)
        return updated.take(25).also { saveStrings(KEY_SEARCH_HISTORY, it) }
    }

    fun clearLocalUserData() {
        val editor = preferences.edit()
        preferences.all.keys
            .filter { it == KEY_HISTORY || it.startsWith(KEY_HISTORY_ACCOUNT_PREFIX) }
            .forEach { key -> editor.remove(key) }
        editor
            .remove(KEY_WATCH_LATER)
            .remove(KEY_DOWNLOADS)
            .remove(KEY_SEARCH_HISTORY)
            .remove(KEY_LOCAL_LIKES)
            .remove(KEY_LOCAL_DISLIKES)
            .remove(KEY_LOCAL_LIKED_VIDEOS)
            .apply()
    }

    fun clearAccountCache() {
        accountPreferences.edit().clear().apply()
        preferences.edit()
            .remove(KEY_PROFILE)
            .remove(KEY_CONNECTED_ACCOUNT)
            .remove(KEY_PERSONALIZED)
            .remove(KEY_POPULAR)
            .remove(KEY_LIVE)
            .remove(KEY_GAMING)
            .remove(KEY_MUSIC)
            .remove(KEY_SHORTS)
            .remove(KEY_LIKED)
            .remove(KEY_UPLOADS)
            .remove(KEY_SUBSCRIPTIONS)
            .remove(KEY_PLAYLISTS)
            .remove(KEY_REMOTE_NOTIFICATIONS)
            .remove(KEY_LAST_SYNC)
            .apply()
    }

    private fun migrateLegacyAccountState() {
        val currentProfile = decodeProfile(accountPreferences.getString(KEY_PROFILE, null))
        val currentConnected = accountPreferences.getBoolean(KEY_CONNECTED_ACCOUNT, false)
        if (currentConnected && currentProfile != null) {
            // El archivo nuevo ya es la fuente de verdad. Borra restos antiguos para
            // que un backup viejo no pueda volver a imponerse en futuras versiones.
            preferences.edit().remove(KEY_PROFILE).remove(KEY_CONNECTED_ACCOUNT).apply()
            return
        }

        // Si el archivo nuevo quedó a medias (connected sin correo, JSON dañado, etc.),
        // no se acepta como sesión válida.
        accountPreferences.edit().clear().apply()

        val legacyProfile = decodeProfile(preferences.getString(KEY_PROFILE, null))
        val legacyConnected = preferences.getBoolean(KEY_CONNECTED_ACCOUNT, false)
        if (legacyConnected && legacyProfile != null) {
            saveConnectedProfile(legacyProfile)
        }
        preferences.edit().remove(KEY_PROFILE).remove(KEY_CONNECTED_ACCOUNT).apply()
    }

    private fun decodeProfile(raw: String?): GoogleProfile? = runCatching {
        if (raw.isNullOrBlank()) return@runCatching null
        val item = JSONObject(raw)
        val email = item.optString("email").trim()
        if (email.isBlank()) return@runCatching null
        GoogleProfile(
            name = item.optString("name").trim(),
            email = email,
            pictureUrl = item.optString("pictureUrl").trim(),
            channelTitle = item.optString("channelTitle").trim(),
            channelId = item.optString("channelId").trim()
        )
    }.getOrNull()

    private fun loadVideos(key: String): List<VideoItem> = decodeVideos(preferences.getString(key, "[]").orEmpty())

    private fun saveVideos(key: String, videos: List<VideoItem>) {
        preferences.edit().putString(key, encodeVideos(videos).toString()).apply()
    }

    private fun encodeVideos(videos: List<VideoItem>): JSONArray {
        val array = JSONArray()
        videos.forEach { video ->
            array.put(
                JSONObject()
                    .put("id", video.id)
                    .put("title", video.title)
                    .put("channelTitle", video.channelTitle)
                    .put("thumbnailUrl", video.thumbnailUrl)
                    .put("channelId", video.channelId)
                    .put("channelThumbnailUrl", video.channelThumbnailUrl)
                    .put("publishedAt", video.publishedAt)
                    .put("description", video.description)
                    .put("isLive", video.isLive)
                    .put("mediaKind", video.mediaKind.name)
                    .put("source", video.source)
                    .put("resumePositionMs", video.resumePositionMs)
                    .put("durationMs", video.durationMs)
                    .put("downloadId", video.downloadId)
                    .put("watchedAtMs", video.watchedAtMs)
                    .put("viewCountText", video.viewCountText)
                    .put("isNew", video.isNew)
                    .put("mixPlaylistId", video.mixPlaylistId)
                    .put("isMix", video.isMix)
            )
        }
        return array
    }

    private fun decodeVideos(raw: String): List<VideoItem> = runCatching {
        val array = JSONArray(raw.ifBlank { "[]" })
        buildList {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                add(
                    VideoItem(
                        id = item.optString("id"),
                        title = item.optString("title", "Video"),
                        channelTitle = item.optString("channelTitle", ""),
                        thumbnailUrl = item.optString("thumbnailUrl", ""),
                        channelId = item.optString("channelId", ""),
                        channelThumbnailUrl = item.optString("channelThumbnailUrl", ""),
                        publishedAt = item.optString("publishedAt", ""),
                        description = item.optString("description", ""),
                        isLive = item.optBoolean("isLive", false),
                        mediaKind = runCatching {
                            MediaKind.valueOf(item.optString("mediaKind", MediaKind.YOUTUBE.name))
                        }.getOrDefault(MediaKind.YOUTUBE),
                        source = item.optString("source", item.optString("id")),
                        resumePositionMs = item.optLong("resumePositionMs", 0L),
                        durationMs = item.optLong("durationMs", 0L),
                        downloadId = item.optLong("downloadId", -1L),
                        watchedAtMs = item.optLong("watchedAtMs", 0L),
                        viewCountText = item.optString("viewCountText", ""),
                        isNew = item.optBoolean("isNew", false),
                        mixPlaylistId = item.optString("mixPlaylistId", ""),
                        isMix = item.optBoolean("isMix", false)
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    private fun encodeChannels(items: List<ChannelItem>): JSONArray {
        val array = JSONArray()
        items.forEach {
            array.put(
                JSONObject()
                    .put("id", it.id)
                    .put("title", it.title)
                    .put("thumbnailUrl", it.thumbnailUrl)
                    .put("description", it.description)
                    .put("bannerUrl", it.bannerUrl)
                    .put("handle", it.handle)
                    .put("subscriberCount", it.subscriberCount)
                    .put("videoCount", it.videoCount)
                    .put("isSubscribed", it.isSubscribed)
            )
        }
        return array
    }

    private fun decodeChannels(raw: String): List<ChannelItem> = runCatching {
        val array = JSONArray(raw.ifBlank { "[]" })
        buildList {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                add(
                    ChannelItem(
                        id = item.optString("id"),
                        title = item.optString("title"),
                        thumbnailUrl = item.optString("thumbnailUrl"),
                        description = item.optString("description"),
                        bannerUrl = item.optString("bannerUrl"),
                        handle = item.optString("handle"),
                        subscriberCount = item.optLong("subscriberCount", 0L),
                        videoCount = item.optLong("videoCount", 0L),
                        isSubscribed = item.optBoolean("isSubscribed", false)
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    private fun encodePlaylists(items: List<PlaylistItem>): JSONArray {
        val array = JSONArray()
        items.forEach {
            array.put(
                JSONObject()
                    .put("id", it.id)
                    .put("title", it.title)
                    .put("thumbnailUrl", it.thumbnailUrl)
                    .put("itemCount", it.itemCount)
            )
        }
        return array
    }

    private fun decodePlaylists(raw: String): List<PlaylistItem> = runCatching {
        val array = JSONArray(raw.ifBlank { "[]" })
        buildList {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                add(
                    PlaylistItem(
                        id = item.optString("id"),
                        title = item.optString("title"),
                        thumbnailUrl = item.optString("thumbnailUrl"),
                        itemCount = item.optInt("itemCount")
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    private fun encodeNotifications(items: List<NotificationItem>): JSONArray {
        val array = JSONArray()
        items.forEach {
            array.put(
                JSONObject()
                    .put("id", it.id)
                    .put("title", it.title)
                    .put("subtitle", it.subtitle)
                    .put("thumbnailUrl", it.thumbnailUrl)
                    .put("video", it.video?.let { video -> encodeVideos(listOf(video)).optJSONObject(0) })
            )
        }
        return array
    }

    private fun decodeNotifications(raw: String): List<NotificationItem> = runCatching {
        val array = JSONArray(raw.ifBlank { "[]" })
        buildList {
            for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                val videoJson = item.optJSONObject("video")
                val video = videoJson?.let { decodeVideos(JSONArray().put(it).toString()).firstOrNull() }
                add(
                    NotificationItem(
                        id = item.optString("id"),
                        title = item.optString("title"),
                        subtitle = item.optString("subtitle"),
                        thumbnailUrl = item.optString("thumbnailUrl"),
                        video = video
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    private fun historyStorageKey(): String {
        val email = decodeProfile(accountPreferences.getString(KEY_PROFILE, null))
            ?.email
            .orEmpty()
            .trim()
            .lowercase()
        if (email.isBlank()) return KEY_HISTORY
        return KEY_HISTORY_ACCOUNT_PREFIX + Integer.toHexString(email.hashCode())
    }

    private fun saveHistory(videos: List<VideoItem>) {
        saveVideos(historyStorageKey(), videos)
    }

    private fun saveStrings(key: String, values: List<String>) {
        val array = JSONArray()
        values.forEach { value -> array.put(value) }
        preferences.edit().putString(key, array.toString()).apply()
    }

    private fun decodeStrings(raw: String): List<String> = runCatching {
        val array = JSONArray(raw.ifBlank { "[]" })
        buildList<String> {
            for (index in 0 until array.length()) add(array.optString(index))
        }
    }.getOrDefault(emptyList())

    private companion object {
        const val KEY_HISTORY = "history"
        const val FEED_SCHEMA_VERSION = 4
        const val KEY_FEED_SCHEMA = "feed_schema"
        const val KEY_HISTORY_ACCOUNT_PREFIX = "history_account_"
        const val KEY_WATCH_LATER = "watch_later"
        const val KEY_DOWNLOADS = "downloads"
        const val KEY_SEARCH_HISTORY = "search_history"
        const val KEY_LOCAL_LIKES = "local_likes"
        const val KEY_LOCAL_DISLIKES = "local_dislikes"
        const val KEY_LOCAL_LIKED_VIDEOS = "local_liked_videos"
        const val KEY_AUTOPLAY = "autoplay"
        const val KEY_DATA_SAVER = "data_saver"
        const val KEY_NOTIFICATIONS = "notifications_enabled"
        const val KEY_CONNECTED_ACCOUNT = "connected_account"
        const val KEY_PROFILE = "profile"
        const val KEY_PERSONALIZED = "personalized"
        const val KEY_POPULAR = "popular"
        const val KEY_LIVE = "live"
        const val KEY_GAMING = "gaming"
        const val KEY_MUSIC = "music"
        const val KEY_SHORTS = "shorts"
        const val KEY_LIKED = "liked"
        const val KEY_UPLOADS = "uploads"
        const val KEY_SUBSCRIPTIONS = "subscriptions"
        const val KEY_PLAYLISTS = "playlists"
        const val KEY_REMOTE_NOTIFICATIONS = "remote_notifications"
        const val KEY_CHANNEL_AVATARS = "channel_avatars"
        const val KEY_LAST_SYNC = "last_sync"
        const val MAX_CHANNEL_AVATARS = 1_000
        const val MAX_HISTORY_ITEMS = 300
        const val KEY_YOUTUBE_SYNC_ENABLED = "youtube_sync_enabled"
        const val KEY_GEO_WATCH_LATER_PLAYLIST = "geo_watch_later_playlist"
        const val AUTH_PREFS_NAME = "geo_videos_account_v1"
    }
}
