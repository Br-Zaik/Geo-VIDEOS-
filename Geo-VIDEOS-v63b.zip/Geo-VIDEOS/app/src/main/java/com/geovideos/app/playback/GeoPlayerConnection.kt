package com.geovideos.app.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.geovideos.app.data.VideoItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch




data class PlaybackCoreState(
    val connecting: Boolean = true,
    val resolving: Boolean = false,
    val currentVideoId: String = "",
    val isPlaying: Boolean = false,
    val videoWidth: Int = 0,
    val videoHeight: Int = 0,
    val playbackState: Int = Player.STATE_IDLE,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val error: String? = null
)

data class PlaybackProgressState(
    val currentVideoId: String = "",
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val bufferedPercentage: Int = 0
)

data class PlaybackUiState(
    val connecting: Boolean = true,
    val resolving: Boolean = false,
    val currentVideoId: String = "",
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val bufferedPercentage: Int = 0,
    val videoWidth: Int = 0,
    val videoHeight: Int = 0,
    val playbackState: Int = Player.STATE_IDLE,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val error: String? = null
)

class GeoPlayerConnection private constructor(context: Context) {
    private val appContext = context.applicationContext
    private val playerPreferences = appContext.getSharedPreferences("geo_player_preferences", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val controllerFuture = MediaController.Builder(
        appContext,
        SessionToken(appContext, ComponentName(appContext, PlaybackService::class.java))
    ).buildAsync()

    private val _controller = MutableStateFlow<MediaController?>(null)
    val controller: StateFlow<MediaController?> = _controller.asStateFlow()

    private val _preferredQualityHeight = MutableStateFlow<Int?>(
        playerPreferences.getInt(KEY_PREFERRED_QUALITY, 0).takeIf { it > 0 }
    )
    val preferredQualityHeight: StateFlow<Int?> = _preferredQualityHeight.asStateFlow()

    /** Segundos que salta el doble toque (YouTube deja elegir 5–60 s). */
    private val _doubleTapSeekSeconds = MutableStateFlow(
        playerPreferences.getInt(KEY_DOUBLE_TAP_SECONDS, 10).coerceIn(5, 60)
    )
    val doubleTapSeekSeconds: StateFlow<Int> = _doubleTapSeekSeconds.asStateFlow()

    fun setDoubleTapSeekSeconds(seconds: Int) {
        val safe = seconds.coerceIn(5, 60)
        _doubleTapSeekSeconds.value = safe
        playerPreferences.edit().putInt(KEY_DOUBLE_TAP_SECONDS, safe).apply()
    }

    /** Al salir de la app con un video sonando, seguir en la ventana emergente (como Daylitube). */
    private val _autoFloatingOnLeave = MutableStateFlow(
        playerPreferences.getBoolean(KEY_AUTO_FLOATING, true)
    )
    val autoFloatingOnLeave: StateFlow<Boolean> = _autoFloatingOnLeave.asStateFlow()

    fun setAutoFloatingOnLeave(enabled: Boolean) {
        _autoFloatingOnLeave.value = enabled
        playerPreferences.edit().putBoolean(KEY_AUTO_FLOATING, enabled).apply()
    }

    internal suspend fun playbackExtras(video: VideoItem): PlaybackExtras = StreamResolver.extras(video)

    /** Cambia la pista de audio (original / doblada) sin perder la posición. */
    fun selectAudioTrack(video: VideoItem, trackId: String?, dataSaver: Boolean) {
        StreamResolver.setPreferredAudioTrack(video.id, trackId)
        val controllerNow = _controller.value
        val position = controllerNow?.currentPosition?.takeIf { it >= 0L } ?: video.resumePositionMs
        val shouldPlay = controllerNow?.playWhenReady ?: true
        val repeat = controllerNow?.repeatMode == Player.REPEAT_MODE_ONE
        openInternal(
            video = video.copy(resumePositionMs = position),
            autoplay = shouldPlay,
            dataSaver = dataSaver,
            repeat = repeat,
            preferredHeight = _preferredQualityHeight.value,
            forceReload = true,
            audioOnly = _audioOnlyMode.value,
            updateQualityPreference = false
        )
    }

    // El modo música pertenece únicamente a la reproducción actual. No se conserva
    // como preferencia global porque al abrir otro video o un Short debe volver el video.
    private val _audioOnlyMode = MutableStateFlow(false)
    val audioOnlyMode: StateFlow<Boolean> = _audioOnlyMode.asStateFlow()
    private var activeAudioOnly: Boolean = false

    private val _state = MutableStateFlow(PlaybackUiState())
    val state: StateFlow<PlaybackUiState> = _state.asStateFlow()

    val coreState: StateFlow<PlaybackCoreState> = _state
        .map { playback ->
            PlaybackCoreState(
                connecting = playback.connecting,
                resolving = playback.resolving,
                currentVideoId = playback.currentVideoId,
                isPlaying = playback.isPlaying,
                videoWidth = playback.videoWidth,
                videoHeight = playback.videoHeight,
                playbackState = playback.playbackState,
                repeatMode = playback.repeatMode,
                error = playback.error
            )
        }
        .distinctUntilChanged()
        .stateIn(scope, SharingStarted.Eagerly, PlaybackCoreState())

    val progressState: StateFlow<PlaybackProgressState> = _state
        .map { playback ->
            PlaybackProgressState(
                currentVideoId = playback.currentVideoId,
                positionMs = playback.positionMs,
                durationMs = playback.durationMs,
                bufferedPercentage = playback.bufferedPercentage
            )
        }
        .distinctUntilChanged()
        .stateIn(scope, SharingStarted.Eagerly, PlaybackProgressState())

    private val _endedEvents = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val endedEvents: SharedFlow<String> = _endedEvents.asSharedFlow()

    private val _mediaTransitionEvents = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val mediaTransitionEvents: SharedFlow<String> = _mediaTransitionEvents.asSharedFlow()

    private var currentVideo: VideoItem? = null
    private var resolveJob: Job? = null
    private var queueJob: Job? = null
    private var preloadJob: Job? = null
    private var pendingQueue: List<VideoItem> = emptyList()
    private var pendingQueueDataSaver: Boolean = false
    private var requestSerial: Long = 0L
    private var activeRepeatPlayback = false
    private var activeDataSaver = false
    private var playbackFallbackAttempt: Int = 0
    private val pendingControllerActions = ArrayList<(MediaController) -> Unit>()

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = updateFrom(player)

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            mediaItem?.mediaId?.takeIf { it.isNotBlank() }?.let { _mediaTransitionEvents.tryEmit(it) }
            _controller.value?.let(::updateFrom)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            val player = _controller.value ?: return
            if (playbackState == Player.STATE_ENDED && player.repeatMode != Player.REPEAT_MODE_ONE) {
                val mediaId = player.currentMediaItem?.mediaId.orEmpty()
                if (mediaId.isNotBlank()) _endedEvents.tryEmit(mediaId)
            }
            updateFrom(player)
        }

        override fun onPlayerError(error: PlaybackException) {
            val video = currentVideo
            val player = _controller.value
            // YouTube rechazó el enlace (403/410…): el siguiente intento va directo con tu sesión.
            if (video != null && (
                    error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ||
                        error.errorCode == PlaybackException.ERROR_CODE_IO_INVALID_HTTP_CONTENT_TYPE ||
                        error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED
                    )
            ) {
                StreamResolver.markLinkRejected(video.id)
            }
            if (
                video != null &&
                !activeAudioOnly &&
                playbackFallbackAttempt < MAX_PLAYBACK_FALLBACK_ATTEMPT
            ) {
                val nextAttempt = playbackFallbackAttempt + 1
                val resume = player?.currentPosition
                    ?.takeIf { it >= 0L }
                    ?: video.resumePositionMs
                val shouldPlay = player?.playWhenReady ?: true
                playbackFallbackAttempt = nextAttempt
                _state.update { it.copy(resolving = true, error = null) }
                openInternal(
                    video = video.copy(resumePositionMs = resume),
                    autoplay = shouldPlay,
                    dataSaver = activeDataSaver,
                    repeat = activeRepeatPlayback,
                    preferredHeight = null,
                    forceReload = true,
                    audioOnly = false,
                    forceProgressive = nextAttempt == 1,
                    updateQualityPreference = false,
                    fallbackAttempt = nextAttempt,
                    // Un error del player invalida la URL firmada actual: reextraer YouTube
                    // completamente antes de probar el siguiente formato.
                    forceFreshResolver = true
                )
                return
            }
            _state.update {
                it.copy(
                    resolving = false,
                    error = friendlyPlaybackError(error.localizedMessage)
                )
            }
        }
    }

    init {
        controllerFuture.addListener(
            {
                runCatching { controllerFuture.get() }
                    .onSuccess { mediaController ->
                        mediaController.addListener(listener)
                        _controller.value = mediaController
                        _state.update { it.copy(connecting = false) }
                        val queued = synchronized(pendingControllerActions) {
                            pendingControllerActions.toList().also { pendingControllerActions.clear() }
                        }
                        queued.forEach { it(mediaController) }
                        updateFrom(mediaController)
                    }
                    .onFailure { error ->
                        _state.update {
                            it.copy(
                                connecting = false,
                                resolving = false,
                                error = friendlyPlaybackError(error.message)
                            )
                        }
                    }
            },
            ContextCompat.getMainExecutor(appContext)
        )

        scope.launch {
            while (isActive) {
                _controller.value?.let(::updateFrom)
                // Keep the custom progress bar responsive while playing without waking the
                // UI every few milliseconds when playback is paused.
                delay(if (_controller.value?.isPlaying == true) 500L else 1_500L)
            }
        }
    }

    fun open(
        video: VideoItem,
        autoplay: Boolean,
        dataSaver: Boolean,
        repeat: Boolean = false
    ) {
        val controllerNow = _controller.value
        val retryingFailedVideo = _state.value.currentVideoId == video.id && _state.value.error != null
        val resumePosition = if (retryingFailedVideo) {
            controllerNow?.currentPosition?.takeIf { it >= 0L } ?: video.resumePositionMs
        } else {
            video.resumePositionMs
        }
        openInternal(
            video = video.copy(resumePositionMs = resumePosition),
            autoplay = autoplay,
            dataSaver = dataSaver,
            repeat = repeat,
            preferredHeight = _preferredQualityHeight.value,
            // El botón Reintentar no debe preparar otra vez el mismo MediaItem roto.
            forceReload = retryingFailedVideo,
            audioOnly = false,
            forceFreshResolver = retryingFailedVideo
        )
    }

    private fun openInternal(
        video: VideoItem,
        autoplay: Boolean,
        dataSaver: Boolean,
        repeat: Boolean,
        preferredHeight: Int?,
        forceReload: Boolean,
        audioOnly: Boolean,
        forceProgressive: Boolean = false,
        updateQualityPreference: Boolean = true,
        fallbackAttempt: Int = 0,
        forceFreshResolver: Boolean = false
    ) {
        // Si el usuario acaba de tocar un video, la reproduccion real tiene prioridad sobre
        // cualquier precarga especulativa que estuviera resolviendo otro elemento del feed.
        preloadJob?.cancel()
        val controllerNow = _controller.value
        if (
            !forceReload &&
            controllerNow?.currentMediaItem?.mediaId == video.id &&
            controllerNow.mediaItemCount > 0 &&
            activeAudioOnly == audioOnly
        ) {
            currentVideo = video
            controllerNow.repeatMode = if (repeat) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
            if (autoplay && controllerNow.playbackState == Player.STATE_IDLE) controllerNow.prepare()
            if (autoplay && controllerNow.playbackState == Player.STATE_ENDED) {
                controllerNow.seekTo(0L)
                controllerNow.play()
            }
            return
        }

        controllerNow?.pause()
        currentVideo = video
        activeAudioOnly = audioOnly
        activeRepeatPlayback = repeat
        activeDataSaver = dataSaver
        playbackFallbackAttempt = fallbackAttempt.coerceIn(0, MAX_PLAYBACK_FALLBACK_ATTEMPT)
        _audioOnlyMode.value = audioOnly
        if (updateQualityPreference) {
            _preferredQualityHeight.value = preferredHeight
            playerPreferences.edit().putInt(KEY_PREFERRED_QUALITY, preferredHeight ?: 0).apply()
        }
        resolveJob?.cancel()
        requestSerial += 1L
        val requestId = requestSerial
        _state.value = PlaybackUiState(
            connecting = controllerNow == null,
            resolving = true,
            currentVideoId = video.id,
            positionMs = video.resumePositionMs,
            durationMs = video.durationMs
        )

        resolveJob = scope.launch {
            try {
                val resolved = if (audioOnly) {
                    StreamResolver.resolveAudio(video)
                } else {
                    var attempt = fallbackAttempt.coerceIn(0, MAX_PLAYBACK_FALLBACK_ATTEMPT)
                    var resolvedMedia: ResolvedMedia? = null
                    var lastFailure: Throwable? = null
                    while (resolvedMedia == null && attempt <= MAX_PLAYBACK_FALLBACK_ATTEMPT) {
                        try {
                            resolvedMedia = StreamResolver.resolve(
                                video = video,
                                dataSaver = dataSaver,
                                preferredHeight = if (attempt == 0 && !forceProgressive) preferredHeight else null,
                                preferProgressive = forceProgressive || repeat || attempt == 1,
                                fallbackAttempt = attempt,
                                forceFresh = forceFreshResolver
                            )
                            playbackFallbackAttempt = attempt
                        } catch (failure: CancellationException) {
                            throw failure
                        } catch (failure: Exception) {
                            lastFailure = failure
                            attempt += 1
                            playbackFallbackAttempt = attempt.coerceAtMost(MAX_PLAYBACK_FALLBACK_ATTEMPT)
                        }
                    }
                    resolvedMedia ?: throw (lastFailure ?: IllegalStateException("No se pudo resolver el video."))
                }
                if (requestId != requestSerial || currentVideo?.id != video.id) return@launch
                withController { controller ->
                    if (requestId != requestSerial || currentVideo?.id != video.id) return@withController
                    val metadata = MediaMetadata.Builder()
                        .setTitle(video.title)
                        .setArtist(video.channelTitle)
                        .setArtworkUri(video.thumbnailUrl.takeIf { it.isNotBlank() }?.let(Uri::parse))
                        .build()
                    val trackBuilder = controller.trackSelectionParameters
                        .buildUpon()
                        .clearVideoSizeConstraints()
                    if (!audioOnly && !resolved.hasSeparateAudio) {
                        val exact = preferredHeight?.takeIf { playbackFallbackAttempt == 0 && it > 0 }
                        if (exact != null) {
                            trackBuilder
                                .setMinVideoSize(0, exact)
                                .setMaxVideoSize(Int.MAX_VALUE, exact)
                        } else if (dataSaver && resolved.mimeType == androidx.media3.common.MimeTypes.APPLICATION_M3U8) {
                            // HLS con la sesión: en Ahorro de datos no pasar de 360p.
                            trackBuilder.setMaxVideoSize(Int.MAX_VALUE, 360)
                        }
                    }
                    controller.setTrackSelectionParameters(trackBuilder.build())
                    controller.repeatMode = if (repeat) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF

                    if (resolved.hasSeparateAudio) {
                        PlaybackService.playResolved(
                            context = appContext,
                            videoId = video.id,
                            title = video.title,
                            artist = video.channelTitle,
                            artwork = video.thumbnailUrl,
                            resolved = resolved,
                            positionMs = video.resumePositionMs,
                            autoplay = autoplay,
                            repeat = repeat
                        )
                    } else {
                        val item = MediaItem.Builder()
                            .setMediaId(video.id)
                            .setUri(resolved.uri)
                            .setMimeType(resolved.mimeType)
                            .setMediaMetadata(metadata)
                            .build()
                        controller.setMediaItem(item, video.resumePositionMs.coerceAtLeast(0L))
                        controller.prepare()
                        controller.playWhenReady = autoplay
                    }
                    _state.update { it.copy(resolving = false, error = null) }
                    appendPendingQueue(video.id)
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                if (requestId != requestSerial || currentVideo?.id != video.id) return@launch
                _state.update {
                    it.copy(
                        resolving = false,
                        error = friendlyPlaybackError(describeError(error))
                    )
                }
            }
        }
    }

    fun updateQueue(current: VideoItem, candidates: List<VideoItem>, dataSaver: Boolean) {
        pendingQueue = candidates
            .asSequence()
            .filterNot { it.id == current.id }
            .filter { it.id.isNotBlank() }
            .distinctBy { it.id }
            // Resolving twenty YouTube streams up front wastes extractor/network time and can
            // compete with the video that is currently buffering. Four items are enough for
            // seamless Next/autoplay and the queue is rebuilt as playback advances.
            .take(4)
            .toList()
        pendingQueueDataSaver = dataSaver
        if (_controller.value?.currentMediaItem?.mediaId == current.id) {
            appendPendingQueue(current.id)
        }
    }

    private fun appendPendingQueue(currentId: String) {
        queueJob?.cancel()
        val upcoming = pendingQueue
        if (upcoming.isEmpty()) return
        queueJob = scope.launch {
            // No resolver el siguiente video mientras el actual todavia intenta arrancar.
            // En redes moviles esa competencia hacia que el primer frame tardara mas.
            var waitedMs = 0L
            while (waitedMs < 5_000L) {
                val controllerNow = _controller.value ?: return@launch
                if (controllerNow.currentMediaItem?.mediaId != currentId) return@launch
                if (controllerNow.playbackState == Player.STATE_READY) break
                delay(250L)
                waitedMs += 250L
            }
            val readyController = _controller.value ?: return@launch
            if (readyController.currentMediaItem?.mediaId != currentId ||
                readyController.playbackState != Player.STATE_READY
            ) return@launch

            for (video in upcoming) {
                val controllerNow = _controller.value ?: break
                val queuedIds = (0 until controllerNow.mediaItemCount)
                    .map { index -> controllerNow.getMediaItemAt(index).mediaId }
                    .toHashSet()
                if (video.id in queuedIds) continue
                val activeIds = queuedIds + controllerNow.currentMediaItem?.mediaId.orEmpty()
                if (currentId !in activeIds && controllerNow.currentMediaItem?.mediaId != currentId) break
                val resolved = runCatching {
                    if (_audioOnlyMode.value) {
                        StreamResolver.resolveAudio(video)
                    } else {
                        StreamResolver.resolve(
                            video = video,
                            dataSaver = pendingQueueDataSaver,
                            preferredHeight = _preferredQualityHeight.value,
                            preferProgressive = false
                        )
                    }
                }.getOrNull() ?: continue
                if (resolved.hasSeparateAudio) {
                    PlaybackService.appendResolved(
                        context = appContext,
                        videoId = video.id,
                        title = video.title,
                        artist = video.channelTitle,
                        artwork = video.thumbnailUrl,
                        resolved = resolved
                    )
                    delay(120L)
                } else {
                    val metadata = MediaMetadata.Builder()
                        .setTitle(video.title)
                        .setArtist(video.channelTitle)
                        .setArtworkUri(video.thumbnailUrl.takeIf { it.isNotBlank() }?.let(Uri::parse))
                        .build()
                    val item = MediaItem.Builder()
                        .setMediaId(video.id)
                        .setUri(resolved.uri)
                        .setMimeType(resolved.mimeType)
                        .setMediaMetadata(metadata)
                        .build()
                    withController { controller ->
                        val exists = (0 until controller.mediaItemCount)
                            .any { index -> controller.getMediaItemAt(index).mediaId == video.id }
                        if (!exists) controller.addMediaItem(item)
                    }
                }
            }
        }
    }

    internal suspend fun streamOptions(
        video: VideoItem,
        includeDownloadSizes: Boolean = true
    ): StreamOptions = StreamResolver.options(video, includeDownloadSizes)

    suspend fun isVerifiedShort(video: VideoItem): Boolean = StreamResolver.isVerifiedShort(video)

    fun selectQuality(video: VideoItem, height: Int?, dataSaver: Boolean) {
        val controllerNow = _controller.value
        val position = controllerNow?.currentPosition
            ?.takeIf { it >= 0L }
            ?: video.resumePositionMs
        val shouldPlay = controllerNow?.playWhenReady ?: true
        val repeat = controllerNow?.repeatMode == Player.REPEAT_MODE_ONE
        openInternal(
            video = video.copy(resumePositionMs = position),
            autoplay = shouldPlay,
            dataSaver = dataSaver,
            repeat = repeat,
            preferredHeight = height,
            forceReload = true,
            audioOnly = false
        )
    }


    fun setAudioOnly(video: VideoItem, enabled: Boolean, autoplay: Boolean, dataSaver: Boolean) {
        val controllerNow = _controller.value
        val position = controllerNow?.currentPosition
            ?.takeIf { it >= 0L }
            ?: video.resumePositionMs
        val shouldPlay = controllerNow?.playWhenReady ?: autoplay
        val repeat = controllerNow?.repeatMode == Player.REPEAT_MODE_ONE
        openInternal(
            video = video.copy(resumePositionMs = position),
            autoplay = shouldPlay,
            dataSaver = dataSaver,
            repeat = repeat,
            preferredHeight = _preferredQualityHeight.value,
            forceReload = true,
            audioOnly = enabled
        )
    }

    fun playNext() = withController { controller ->
        if (controller.hasNextMediaItem()) controller.seekToNextMediaItem()
    }

    fun playPrevious() = withController { controller ->
        if (controller.hasPreviousMediaItem()) controller.seekToPreviousMediaItem()
        else controller.seekTo(0L)
    }

    fun retryShort(video: VideoItem, dataSaver: Boolean) {
        val resume = _controller.value?.currentPosition?.takeIf { it >= 0L } ?: video.resumePositionMs
        openInternal(
            video = video.copy(resumePositionMs = resume),
            autoplay = true,
            dataSaver = dataSaver,
            repeat = true,
            preferredHeight = _preferredQualityHeight.value,
            forceReload = true,
            audioOnly = false,
            forceProgressive = true,
            updateQualityPreference = false,
            forceFreshResolver = true
        )
    }

    fun play() = withController { it.play() }
    fun pause() = withController { it.pause() }
    fun seekTo(positionMs: Long) = withController { it.seekTo(positionMs.coerceAtLeast(0L)) }
    fun setMuted(muted: Boolean) = withController { it.volume = if (muted) 0f else 1f }
    fun setSpeed(speed: Float) = withController { it.setPlaybackSpeed(speed.coerceIn(0.25f, 2f)) }
    fun setMaxVideoHeight(height: Int) = withController { controller ->
        val builder = controller.trackSelectionParameters
            .buildUpon()
            .clearVideoSizeConstraints()
        if (height > 0) {
            builder
                .setMinVideoSize(0, height)
                .setMaxVideoSize(Int.MAX_VALUE, height)
        }
        controller.setTrackSelectionParameters(builder.build())
    }
    fun preload(videos: List<VideoItem>, dataSaver: Boolean) {
        if (videos.isEmpty()) return
        // NewPipe extraction is blocking work internally, so cancelling and immediately
        // launching another speculative batch can still leave both requests competing. Keep
        // at most one small preload batch active at any moment.
        if (preloadJob?.isActive == true) return
        val preferredHeight = _preferredQualityHeight.value
        preloadJob = scope.launch {
            delay(120L)
            StreamResolver.preload(videos, dataSaver, preferredHeight)
        }
    }
    fun setRepeat(enabled: Boolean) = withController {
        it.repeatMode = if (enabled) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
    }

    fun setAutoplayEnabled(enabled: Boolean) {
        PlaybackService.setContinuousAutoplay(appContext, enabled)
    }

    fun stop() {
        requestSerial += 1L
        resolveJob?.cancel()
        queueJob?.cancel()
        preloadJob?.cancel()
        pendingQueue = emptyList()
        currentVideo = null
        activeAudioOnly = false
        activeRepeatPlayback = false
        activeDataSaver = false
        playbackFallbackAttempt = 0
        _audioOnlyMode.value = false
        // Keep the user's quality preference when closing or leaving Shorts.
        // The next video reuses it, matching DayliTube/YouTube behavior.
        withController {
            it.stop()
            it.clearMediaItems()
        }
        PlaybackService.stopPlayback(appContext)
        _state.value = PlaybackUiState(connecting = _controller.value == null)
    }

    @Volatile
    private var videoDisabledForBackground = false

    /**
     * Pantalla apagada o app en segundo plano: sigue sonando, pero sin decodificar la imagen
     * (ahorra batería y datos). Al volver, la imagen regresa sola. Con la ventana flotante
     * abierta no se toca nada porque ahí sí se ve el video.
     */
    fun setAppInBackground(background: Boolean) {
        appInBackground = background
        // Si la app está a la vista, la pantalla está encendida.
        if (!background) screenOff = false
        applyVideoVisibility()
    }

    /** Pantalla apagada con la ventana emergente abierta: solo audio, así ahorra batería. */
    fun setScreenOff(off: Boolean) {
        screenOff = off
        applyVideoVisibility()
    }

    /**
     * La ventana emergente se cerró. Se revisa un momento después si la imagen sigue haciendo
     * falta (si el usuario volvió a la app, sí; si quedó atrás, solo audio).
     */
    fun onFloatingWindowClosed() {
        screenOff = false
        scope.launch {
            delay(1_500L)
            applyVideoVisibility()
        }
    }

    @Volatile
    private var appInBackground = false

    @Volatile
    private var screenOff = false

    private fun applyVideoVisibility() = withController { controller ->
        val floating = FloatingPlayerService.isActiveOrStarting()
        val disable = screenOff || (appInBackground && !floating)
        if (disable == videoDisabledForBackground) return@withController
        if (disable && !controller.isPlaying) return@withController
        videoDisabledForBackground = disable
        controller.trackSelectionParameters = controller.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, disable)
            .build()
    }

    private fun withController(action: (MediaController) -> Unit) {
        val ready = _controller.value
        if (ready != null) {
            action(ready)
        } else {
            synchronized(pendingControllerActions) { pendingControllerActions.add(action) }
        }
    }

    /** Nombre y mensaje de la excepción y de sus causas (NewPipe envuelve el motivo real). */
    private fun describeError(error: Throwable): String {
        val parts = ArrayList<String>()
        var current: Throwable? = error
        var depth = 0
        while (current != null && depth < 5) {
            parts.add(current.javaClass.simpleName + " " + current.message.orEmpty())
            current = current.cause
            depth += 1
        }
        return parts.joinToString(" | ")
    }

    /** Motivo que YouTube escribió en playabilityStatus ("Got error UNPLAYABLE: \"…\""). */
    private fun youtubeReason(message: String): String =
        Regex("""Got error \w+: "(.*?)"""").find(message)?.groupValues?.getOrNull(1)
            ?.takeIf { it.isNotBlank() && it != "null" }
            .orEmpty()

    private fun friendlyPlaybackError(rawMessage: String?): String {
        val message = rawMessage.orEmpty()
        return when {
            message.contains("AgeRestricted", ignoreCase = true) ||
                message.contains("age", ignoreCase = true) && message.contains("restrict", ignoreCase = true) ||
                message.contains("inappropriate", ignoreCase = true) ->
                "YouTube pide confirmar la edad para este video. Ábrelo en YouTube."
            message.contains("SignInConfirmNotBot", ignoreCase = true) ||
                message.contains("not a bot", ignoreCase = true) ||
                message.contains("eres un bot", ignoreCase = true) ||
                message.contains("volver a cargar", ignoreCase = true) ||
                message.contains("page needs to be reloaded", ignoreCase = true) ->
                "YouTube rechazó esta conexión por ahora. Pulsa Reintentar o \"Ver en web\"."
            message.contains("members", ignoreCase = true) ||
                message.contains("PaidContent", ignoreCase = true) ||
                message.contains("Premium", ignoreCase = true) ->
                "Este video es solo para miembros o de pago. Ábrelo en YouTube."
            message.contains("PrivateContent", ignoreCase = true) || message.contains("private", ignoreCase = true) ->
                "Este video es privado."
            message.contains("GeographicRestriction", ignoreCase = true) ||
                message.contains("country", ignoreCase = true) ->
                "Este video no está disponible en tu país."
            message.contains("premiere", ignoreCase = true) ||
                message.contains("will begin", ignoreCase = true) ||
                message.contains("upcoming", ignoreCase = true) ->
                "Es un estreno o directo que todavía no empieza."
            message.contains("kids", ignoreCase = true) || message.contains("niños", ignoreCase = true) ->
                "Es un video \"para niños\": YouTube no lo entrega a apps externas. Ábrelo en YouTube."
            youtubeReason(message).isNotBlank() ->
                "YouTube dice: " + youtubeReason(message)
            message.contains("ContentNotAvailable", ignoreCase = true) ||
                message.contains("unavailable", ignoreCase = true) ||
                message.contains("not available", ignoreCase = true) ->
                "YouTube no entrega este video a apps externas ahora. Reintenta o ábrelo en YouTube."
            message.contains("403") ->
                "YouTube rechazó el enlace del video. Pulsa Reintentar."
            message.contains("unable to resolve host", ignoreCase = true) ||
                message.contains("no address associated with hostname", ignoreCase = true) ||
                message.contains("youtubei.googleapis.com", ignoreCase = true) ->
                "No se pudo conectar con el servicio de video. Revisa tu conexión y pulsa Reintentar."
            message.contains("timeout", ignoreCase = true) ->
                "La conexión tardó demasiado. Pulsa Reintentar."
            message.isBlank() -> "No se pudo reproducir el video. Pulsa Reintentar."
            else -> "No se pudo reproducir el video. Pulsa Reintentar."
        }
    }

    private fun updateFrom(player: Player) {
        _state.update {
            it.copy(
                connecting = false,
                currentVideoId = player.currentMediaItem?.mediaId.orEmpty().ifBlank { it.currentVideoId },
                isPlaying = player.isPlaying,
                positionMs = player.currentPosition.coerceAtLeast(0L),
                durationMs = player.duration.takeIf { duration -> duration > 0L } ?: it.durationMs,
                bufferedPercentage = player.bufferedPercentage.coerceIn(0, 100),
                videoWidth = player.videoSize.width.coerceAtLeast(0),
                videoHeight = player.videoSize.height.coerceAtLeast(0),
                playbackState = player.playbackState,
                repeatMode = player.repeatMode,
                // Mientras se prueba un stream nuevo, no volver a mostrar el error del
                // MediaItem anterior. El mensaje definitivo aparece solo al agotar fallbacks.
                error = if (it.resolving) null else player.playerError?.localizedMessage ?: it.error
            )
        }
    }

    private fun release() {
        resolveJob?.cancel()
        queueJob?.cancel()
        preloadJob?.cancel()
        _controller.value?.removeListener(listener)
        MediaController.releaseFuture(controllerFuture)
        scope.cancel()
    }

    companion object {
        private const val KEY_PREFERRED_QUALITY = "preferred_quality_height"
        private const val KEY_DOUBLE_TAP_SECONDS = "double_tap_seek_seconds"
        private const val KEY_AUTO_FLOATING = "auto_floating_on_leave"
        private const val MAX_PLAYBACK_FALLBACK_ATTEMPT = 3

        @Volatile
        private var instance: GeoPlayerConnection? = null

        fun get(context: Context): GeoPlayerConnection =
            instance ?: synchronized(this) {
                instance ?: GeoPlayerConnection(context).also { instance = it }
            }
    }
}
